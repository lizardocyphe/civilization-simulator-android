# Project Guidance

## User Preferences

- Mobile-first game experience with touch controls
- 4X format: explore, expand, exploit, exterminate
- Simulation spanning history to the modern day
- Real-world weather simulation
- Crisis and environmental disasters
- Real-time-strategy pacing with a pausable simulation clock
- Autonomous offline AI opponents with visible reasoning

## Accepted Requirements

- Mobile 4X civilization game spanning history to modern day
- Simulates politics, war, agriculture, industry, technology, information, real life, transportation, resources, strategy and economy
- Real-world weather simulation
- Crisis and environmental disasters

## Verified Commands

- **typecheck**: `pnpm typecheck`
- **fix**: `pnpm fix`
- **build**: `pnpm build`

## Learnings

- Backend commands from src/backend/: `mops check --fix` and `mops build`; root `pnpm bindgen` regenerates src/frontend/src/backend.d.ts.
- A Motoko mixin that needs shared mutable state takes it as a parameter; the actor declares the field type-only and passes the same binding to every include.
- A shared per-caller lookup helper must live in a plain lib module and be called qualified from every mixin; an unqualified call is M0057 and a mixin top-level func collides across includes with M0051.
- `label` is a reserved Motoko keyword and cannot be used as a record field name.
- An orphan backend module not imported by main.mo is not compiled by `mops check`.
- Backend ID aliases (GameId, TileId, SettlementId, BuildingId, UnitId, RivalId, TechId, CrisisId) must be re-exported from src/frontend/src/types.ts alongside the interfaces.
- Backend enums (Era, Terrain, FogState, DiplomaticStance, UserRole) are runtime values and must be re-exported with `export { ... } from '@/backend'`, never `export type`.
- TanStack Router code-based routes: createRootRoute + createRoute with getParentRoute, then createRouter({routeTree}); declare module '@tanstack/react-router' Register for typed Link `to` values.
- The simulation clock timer in src/frontend/src/hooks/useQueries.ts (useSimClock) calls endTurn on a setInterval keyed on [running, speed]; endTurn runs advanceSimulation → Ai.runTick, so one timer drives clock, AI, economy and trade together.
- invalidateGameState in src/frontend/src/hooks/useQueries.ts invalidates every domain query key, so a single endTurn refresh keeps all panels current as the clock runs.
- src/frontend/src/App.tsx must import the real page components for every route; inline placeholder components silently make a screen unreachable.
- OQL entities in src/backend/lib/oql.mo are manual with .sample(...) + .ownedBy("owner") + .controllerOrScoped(), scoping rows per caller.
- Backend commands from src/backend/: `mops check --fix` and `mops build`; root `pnpm bindgen` regenerates src/frontend/src/backend.d.ts. Frontend: `pnpm typecheck`, `pnpm fix`, `pnpm build`, `pnpm test`.
