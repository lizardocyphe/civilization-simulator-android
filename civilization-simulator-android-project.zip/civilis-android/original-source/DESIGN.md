# Design Brief

## Direction

CIVILIS — a dark cartographic command-table for a mobile 4X civilization game spanning Ancient to Information eras, now extended with an orbital space theatre, a world council, and a live economy simulation.

## Tone

Industrial/utilitarian meets aged-map cartography: deep ink-teal surfaces, hairline borders, monospace readouts — a strategist's field console, not a glossy mobile toy.

## Differentiation

The map is the interface: hex terrain lattice, contour texture, and a persistent resource dock that reads like an instrument panel — while the space theatre flips to a violet star field, so the same console spans dirt and orbit.

## Color Palette

| Token      | OKLCH       | Role                                          |
| ---------- | ----------- | --------------------------------------------- |
| background | 0.16 0.018 200 | Deep ink-teal map void                     |
| foreground | 0.93 0.012 190 | Primary text, near-white cool               |
| card       | 0.205 0.022 200 | Elevated panels, dock, popups              |
| primary    | 0.78 0.14 78   | Amber-gold — era, wealth, end-turn CTA       |
| accent     | 0.7 0.13 175   | Teal — research, tech, active selection      |
| muted      | 0.25 0.022 200 | Inactive tabs, secondary fills               |
| space      | 0.24 0.05 285  | Star map, fleet & colonization surfaces      |
| deep       | 0.12 0.035 275 | Orbital void backdrop (star-field base)      |
| council    | 0.34 0.045 295 | World council panels, proposals, votes       |
| inflation  | 0.66 0.18 38   | Rising price index, deficit, crisis          |
| deflation  | 0.68 0.11 235  | Falling price index, surplus, easing         |
| success    | 0.68 0.15 148  | Growth, food surplus, positive income        |
| destructive| 0.62 0.19 38   | Crisis, war, disaster, deficit               |

## Typography

- Display: Space Grotesk — headings, era labels, large resource numbers, settlement names
- Body: DM Sans — labels, descriptions, event text, buttons
- Mono: JetBrains Mono — turn counter, resource tickers, coordinates, income deltas
- Scale: hero `text-4xl font-bold tracking-tight`, h2 `text-2xl font-bold tracking-tight`, label `text-xs font-semibold tracking-widest uppercase`, body `text-sm`

## Elevation & Depth

Flat layered surfaces with hairline borders; depth via `shadow-panel` on the bottom dock, `shadow-elevated` on popups, and `shadow-subtle` on cards — no glow, no neon.

## Structural Zones

| Zone      | Background           | Border          | Notes                                          |
| --------- | -------------------- | --------------- | ---------------------------------------------- |
| Header    | bg-card              | border-b        | Era label, turn counter, weather chip          |
| Map       | bg-background + hex-grid | —           | Hex terrain canvas, fog-of-war edges, overlays |
| Space     | bg-deep + star-field | —               | Star systems, fleets, battle resolution        |
| Panels    | bg-card / bg-popover | border          | Tile inspector, city, tech, diplomacy sheets   |
| Economy   | bg-card              | border          | Inflation, price index, income, upkeep         |
| Council   | bg-council           | border          | Proposals, votes, binding resolutions          |
| Dock      | bg-secondary + shadow-panel | border-t | Resource counters + time control + END TURN    |
| Alerts    | bg-destructive/15    | border-destructive | Crisis cards with choice buttons            |

## Spacing & Rhythm

Mobile-first tight rhythm: 4/8/12/16px scale, `p-3` panel padding, `gap-2` in resource dock, `space-y-4` between event cards, full-bleed map with safe-area insets.

## Component Patterns

- Buttons: 6px radius, amber `bg-primary` for END TURN, outlined `border-border` for secondary; active state darkens, never bounces
- Cards: 6px radius, `bg-card` + hairline border + `shadow-subtle`; crisis cards tint `destructive/15`, council cards tint `council`
- Badges: pill or 4px radius, uppercase `text-xs tracking-widest`, tinted by resource/crisis/economy semantic color
- Time control: segmented speed bar (pause / 1x / 2x / 4x) in the dock, active segment amber

## Motion

- Entrance: `animate-rise-in` (350ms) for panels and event cards; `animate-fade-in` (250ms) for overlays
- Hover: `transition-smooth` on buttons/tiles; subtle brightness lift only
- Decorative: `animate-pulse-soft` on active crisis markers and the current-turn indicator; `animate-orbit` on star-system rings; `animate-signal-ping` on contested systems; `animate-ledger-tick` on resource deltas

## Constraints

- Dark mode is the primary and default experience; light mode is a secondary `.light` variant
- Touch targets ≥ 44px; no hover-only affordances
- Tokens only — no raw hex/rgb in components; Canvas/WebGL map may use literal colors
- No multiplayer, historical-accuracy, campaign, espionage, or leaderboard surfaces

## Signature Detail

A monospace "turn ledger" — resource values rendered tabular with signed per-turn deltas (e.g. `+3` green / `-2` red) — so the economy reads like a live instrument panel rather than static stats.
