import type { ReactNode } from "react";

/**
 * Shared shell for a screen body. Page tasks replace the `children` with the
 * real implementation while keeping the header rhythm consistent.
 */
export function ScreenShell({
  title,
  eyebrow,
  description,
  children,
}: {
  title: string;
  eyebrow: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <section className="mx-auto flex w-full max-w-3xl flex-col gap-4 px-3 py-4">
      <header className="space-y-1">
        <p className="font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-accent">
          {eyebrow}
        </p>
        <h1 className="font-display text-2xl font-bold tracking-tight text-foreground">
          {title}
        </h1>
        <p className="text-sm text-muted-foreground">{description}</p>
      </header>
      {children}
    </section>
  );
}
