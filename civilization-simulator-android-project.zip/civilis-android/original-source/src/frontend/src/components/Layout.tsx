import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  useEndTurn,
  useGame,
  useSimClock,
  useWeather,
} from "@/hooks/useQueries";
import {
  RESOURCE_ICONS,
  RESOURCE_LABELS,
  RESOURCE_ORDER,
  SPEED_LABELS,
  SPEED_ORDER,
  eraLabel,
  formatNumber,
  gameDateFromTurn,
  speedLabel,
  weatherGlyph,
} from "@/lib/game";
import { type ResourcePool, SimSpeed } from "@/types";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  CloudSun,
  Coins,
  Factory,
  FlaskConical,
  Gavel,
  Globe2,
  Landmark,
  LineChart,
  Map as MapIcon,
  Menu,
  Pause,
  Play,
  Rocket,
  ScrollText,
  Shield,
  Sparkles,
  Wheat,
  X,
} from "lucide-react";
import { type ReactNode, useState } from "react";

const NAV_ITEMS = [
  { to: "/map", label: "Map", icon: MapIcon, ocid: "nav.map" },
  {
    to: "/settlement",
    label: "Settlement",
    icon: Landmark,
    ocid: "nav.settlement",
  },
  {
    to: "/technology",
    label: "Technology",
    icon: FlaskConical,
    ocid: "nav.technology",
  },
  { to: "/diplomacy", label: "Diplomacy", icon: Shield, ocid: "nav.diplomacy" },
  { to: "/economy", label: "Economy", icon: LineChart, ocid: "nav.economy" },
  { to: "/trade", label: "Trade", icon: Globe2, ocid: "nav.trade" },
  { to: "/space", label: "Space", icon: Rocket, ocid: "nav.space" },
  { to: "/council", label: "Council", icon: Gavel, ocid: "nav.council" },
  { to: "/weather", label: "Weather", icon: CloudSun, ocid: "nav.weather" },
] as const;

const RESOURCE_ICON_COMPONENTS: Record<keyof ResourcePool, typeof Wheat> = {
  food: Wheat,
  production: Factory,
  science: FlaskConical,
  gold: Coins,
  culture: Sparkles,
  influence: ScrollText,
};

function ResourceDock({ resources }: { resources: ResourcePool }) {
  return (
    <div
      data-ocid="dock.resource_bar"
      className="flex items-stretch gap-1.5 overflow-x-auto"
    >
      {RESOURCE_ORDER.map((key) => {
        const Icon = RESOURCE_ICON_COMPONENTS[key];
        return (
          <div
            key={key}
            data-ocid={`dock.resource.${key}`}
            title={RESOURCE_LABELS[key]}
            className="flex min-w-[3.25rem] flex-1 flex-col items-center gap-0.5 rounded-md border border-border bg-background/60 px-1.5 py-1"
          >
            <span className="flex items-center gap-1 text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground">
              <Icon className="size-3" aria-hidden="true" />
              <span className="sr-only">{RESOURCE_LABELS[key]}</span>
              <span aria-hidden="true">{RESOURCE_ICONS[key]}</span>
            </span>
            <span className="font-mono text-sm font-semibold tabular-nums text-foreground">
              {formatNumber(resources[key])}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function TurnIndicator() {
  const { data: game } = useGame();
  const { data: weather } = useWeather();
  const turn = game?.turn ?? 0n;
  const era = game?.civilization.era;

  return (
    <div className="flex items-center gap-2">
      <div className="flex items-baseline gap-2">
        <span className="font-display text-xs font-semibold uppercase tracking-widest text-primary">
          {era ? eraLabel(era) : "No Era"}
        </span>
        <span className="text-muted-foreground/50" aria-hidden="true">
          |
        </span>
        <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Turn <span className="text-foreground">{formatNumber(turn)}</span>
          <span className="text-muted-foreground/60">
            {" "}
            · {gameDateFromTurn(turn)}
          </span>
        </span>
      </div>
      {weather && (
        <Badge
          variant="outline"
          data-ocid="header.weather_chip"
          className="gap-1 border-border bg-background/60 font-mono text-xs tabular-nums"
        >
          <span aria-hidden="true">{weatherGlyph(weather.condition)}</span>
          {Math.round(weather.temperatureC)}°C
        </Badge>
      )}
    </div>
  );
}

function TimeControlBar() {
  const { speed, setSpeed } = useSimClock();
  const paused = speed === SimSpeed.paused;

  return (
    <fieldset
      data-ocid="clock.panel"
      className="flex items-center gap-1 rounded-md border border-border bg-background/70 p-1"
    >
      <legend className="sr-only">Simulation clock</legend>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        data-ocid="clock.pause_button"
        aria-label={paused ? "Resume simulation" : "Pause simulation"}
        aria-pressed={paused}
        onClick={() => setSpeed(paused ? SimSpeed.x1 : SimSpeed.paused)}
        className={`size-9 rounded-sm ${
          paused ? "bg-primary/20 text-primary" : "text-foreground"
        }`}
      >
        {paused ? (
          <Play className="size-4" aria-hidden="true" />
        ) : (
          <Pause className="size-4" aria-hidden="true" />
        )}
      </Button>
      {SPEED_ORDER.filter((step) => step !== SimSpeed.paused).map((step) => {
        const active = speed === step;
        return (
          <Button
            key={step}
            type="button"
            variant="ghost"
            size="sm"
            data-ocid={`clock.speed.${step}`}
            aria-pressed={active}
            onClick={() => setSpeed(step)}
            className={`h-9 min-w-9 rounded-sm px-2 font-mono text-xs font-semibold tabular-nums transition-smooth ${
              active
                ? "bg-primary text-primary-foreground hover:bg-primary"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
          >
            {SPEED_LABELS[step]}
          </Button>
        );
      })}
      <span className="sr-only" aria-live="polite">
        Simulation {speedLabel(speed)}
      </span>
    </fieldset>
  );
}

function EndTurnButton() {
  const endTurn = useEndTurn();
  return (
    <Button
      type="button"
      data-ocid="dock.end_turn_button"
      onClick={() => endTurn.mutate()}
      disabled={endTurn.isPending}
      className="h-11 flex-1 rounded-md bg-primary font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground shadow-subtle transition-smooth hover:brightness-110"
    >
      {endTurn.isPending ? "Resolving…" : "End Turn"}
    </Button>
  );
}

function NavMenu() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({
    select: (state) => state.location.pathname,
  });

  return (
    <>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        data-ocid="nav.open_menu_button"
        aria-label="Open navigation menu"
        aria-expanded={open}
        onClick={() => setOpen(true)}
        className="size-11 text-foreground"
      >
        <Menu className="size-5" />
      </Button>
      {open && (
        <div
          data-ocid="nav.sheet"
          className="fixed inset-0 z-50 flex animate-fade-in flex-col bg-background/95 backdrop-blur-sm"
        >
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <span className="font-display text-sm font-semibold uppercase tracking-widest text-primary">
              Command Table
            </span>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              data-ocid="nav.close_button"
              aria-label="Close navigation menu"
              onClick={() => setOpen(false)}
              className="size-11"
            >
              <X className="size-5" />
            </Button>
          </div>
          <nav
            className="flex flex-col gap-1 overflow-y-auto p-3"
            aria-label="Game screens"
          >
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = pathname === item.to;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  data-ocid={item.ocid}
                  onClick={() => setOpen(false)}
                  className={`flex min-h-11 items-center gap-3 rounded-md border px-3 py-2 text-sm font-medium transition-smooth ${
                    active
                      ? "border-accent/60 bg-accent/15 text-accent"
                      : "border-transparent text-foreground hover:bg-secondary"
                  }`}
                >
                  <Icon className="size-4" aria-hidden="true" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
      )}
    </>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const { data: game } = useGame();
  const resources = game?.civilization.resources;

  return (
    <div className="flex min-h-dvh flex-col bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border bg-card shadow-subtle">
        <div className="flex items-center justify-between gap-2 px-3 py-2">
          <NavMenu />
          <TurnIndicator />
        </div>
        <div className="flex items-center justify-center border-t border-border/60 px-3 py-1.5">
          <TimeControlBar />
        </div>
      </header>

      <main className="flex-1 bg-background">{children}</main>

      <footer
        data-ocid="dock.panel"
        className="sticky bottom-0 z-40 border-t border-border bg-secondary shadow-panel"
      >
        <div className="flex flex-col gap-2 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2">
          {resources ? (
            <ResourceDock resources={resources} />
          ) : (
            <p
              data-ocid="dock.empty_state"
              className="py-2 text-center text-xs text-muted-foreground"
            >
              Start a game to populate your resource ledger.
            </p>
          )}
          <div className="flex items-center gap-2">
            <EndTurnButton />
            <Link
              to="/settlement"
              data-ocid="dock.city_button"
              className="flex h-11 items-center justify-center rounded-md border border-border px-4 font-display text-sm font-semibold uppercase tracking-widest text-foreground transition-smooth hover:bg-background/60"
            >
              City
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
