import {
  Era,
  PocketKind,
  ProposalKind,
  ProposalStatus,
  type ResourceBundle,
  type ResourcePool,
  SimSpeed,
  Terrain,
  TradeStatus,
} from "@/types";

/** Motoko `Time.now()` values are nanosecond bigints. */
export function timestampToDate(timestamp: bigint): Date | null {
  const date = new Date(Number(timestamp / 1_000_000n));
  return Number.isNaN(date.getTime()) ? null : date;
}

/** Compact relative time for the weather chip and save metadata. */
export function formatRelativeTime(timestamp: bigint): string {
  const date = timestampToDate(timestamp);
  if (!date) return "unknown";
  const seconds = Math.round((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

const ERA_LABELS: Record<Era, string> = {
  [Era.ancient]: "Ancient Era",
  [Era.industrial]: "Industrial Era",
  [Era.modern]: "Modern Era",
  [Era.information]: "Information Era",
};

export function eraLabel(era: Era): string {
  return ERA_LABELS[era] ?? "Unknown Era";
}

/** Ordered era progression used by the technology screen. */
export const ERA_ORDER: Era[] = [
  Era.ancient,
  Era.industrial,
  Era.modern,
  Era.information,
];

export function nextEra(era: Era): Era | null {
  const index = ERA_ORDER.indexOf(era);
  if (index < 0 || index >= ERA_ORDER.length - 1) return null;
  return ERA_ORDER[index + 1];
}

export const RESOURCE_ORDER: (keyof ResourcePool)[] = [
  "food",
  "production",
  "science",
  "gold",
  "culture",
  "influence",
];

export const RESOURCE_LABELS: Record<keyof ResourcePool, string> = {
  food: "Food",
  production: "Production",
  science: "Science",
  gold: "Gold",
  culture: "Culture",
  influence: "Influence",
};

export const RESOURCE_ICONS: Record<keyof ResourcePool, string> = {
  food: "🌾",
  production: "⚙️",
  science: "🔬",
  gold: "🪙",
  culture: "🎭",
  influence: "🕊️",
};

export function emptyResourcePool(): ResourcePool {
  return {
    food: 0n,
    production: 0n,
    science: 0n,
    gold: 0n,
    culture: 0n,
    influence: 0n,
  };
}

/** Signed per-turn delta rendered by the monospace turn ledger. */
export function formatDelta(value: bigint): string {
  if (value > 0n) return `+${value.toString()}`;
  return value.toString();
}

export function deltaTone(value: bigint): "positive" | "negative" | "neutral" {
  if (value > 0n) return "positive";
  if (value < 0n) return "negative";
  return "neutral";
}

export function formatNumber(value: bigint): string {
  return value.toString();
}

/** Human-readable weather condition with a matching glyph. */
export function weatherGlyph(condition: string): string {
  const key = condition.toLowerCase();
  if (key.includes("rain") || key.includes("drizzle")) return "🌧️";
  if (key.includes("snow") || key.includes("sleet")) return "🌨️";
  if (key.includes("storm") || key.includes("thunder")) return "⛈️";
  if (key.includes("cloud") || key.includes("overcast")) return "☁️";
  if (key.includes("fog") || key.includes("mist")) return "🌫️";
  if (key.includes("clear") || key.includes("sun")) return "☀️";
  return "🌤️";
}

/** Hex distance in axial coordinates, used for reveal radius and range checks. */
export function hexDistance(
  a: { q: bigint; r: bigint },
  b: { q: bigint; r: bigint },
): bigint {
  const dq = a.q - b.q;
  const dr = a.r - b.r;
  const ds = -dq - dr;
  const abs = (n: bigint) => (n < 0n ? -n : n);
  return (abs(dq) + abs(dr) + abs(ds)) / 2n;
}

/* ------------------------------------------------------------------ */
/* Terrain                                                             */
/* ------------------------------------------------------------------ */

export const TERRAIN_LABELS: Record<Terrain, string> = {
  [Terrain.ocean]: "Ocean",
  [Terrain.coast]: "Coast",
  [Terrain.reef]: "Reef",
  [Terrain.grassland]: "Grassland",
  [Terrain.plains]: "Plains",
  [Terrain.savanna]: "Savanna",
  [Terrain.desert]: "Desert",
  [Terrain.mesa]: "Mesa",
  [Terrain.hills]: "Hills",
  [Terrain.mountains]: "Mountains",
  [Terrain.forest]: "Forest",
  [Terrain.jungle]: "Jungle",
  [Terrain.wetlands]: "Wetlands",
  [Terrain.tundra]: "Tundra",
  [Terrain.ice]: "Ice",
  [Terrain.volcanic]: "Volcanic",
};

export function terrainLabel(terrain: Terrain): string {
  return TERRAIN_LABELS[terrain] ?? "Unknown";
}

/** Base resource yield a terrain type contributes when worked. */
export const TERRAIN_YIELDS: Record<Terrain, Partial<ResourcePool>> = {
  [Terrain.ocean]: { food: 1n, gold: 1n },
  [Terrain.coast]: { food: 2n, gold: 1n },
  [Terrain.reef]: { food: 2n, culture: 1n },
  [Terrain.grassland]: { food: 2n },
  [Terrain.plains]: { food: 1n, production: 1n },
  [Terrain.savanna]: { food: 1n, production: 1n },
  [Terrain.desert]: { gold: 1n },
  [Terrain.mesa]: { production: 1n, gold: 1n },
  [Terrain.hills]: { production: 2n },
  [Terrain.mountains]: { production: 1n, science: 1n },
  [Terrain.forest]: { production: 1n, food: 1n },
  [Terrain.jungle]: { food: 1n, science: 1n },
  [Terrain.wetlands]: { food: 2n, production: 1n },
  [Terrain.tundra]: { food: 1n },
  [Terrain.ice]: {},
  [Terrain.volcanic]: { production: 2n, science: 1n },
};

export function terrainYield(terrain: Terrain): Partial<ResourcePool> {
  return TERRAIN_YIELDS[terrain] ?? {};
}

/* ------------------------------------------------------------------ */
/* Resource pockets                                                    */
/* ------------------------------------------------------------------ */

export const POCKET_LABELS: Record<PocketKind, string> = {
  [PocketKind.food]: "Food Pocket",
  [PocketKind.production]: "Production Pocket",
  [PocketKind.gold]: "Gold Pocket",
  [PocketKind.science]: "Science Pocket",
  [PocketKind.culture]: "Culture Pocket",
  [PocketKind.influence]: "Influence Pocket",
};

export const POCKET_ICONS: Record<PocketKind, string> = {
  [PocketKind.food]: "🌾",
  [PocketKind.production]: "⚙️",
  [PocketKind.gold]: "🪙",
  [PocketKind.science]: "🔬",
  [PocketKind.culture]: "🎭",
  [PocketKind.influence]: "🕊️",
};

export function pocketLabel(kind: PocketKind): string {
  return POCKET_LABELS[kind] ?? "Resource Pocket";
}

export function pocketIcon(kind: PocketKind): string {
  return POCKET_ICONS[kind] ?? "◆";
}

/* ------------------------------------------------------------------ */
/* Economy                                                             */
/* ------------------------------------------------------------------ */

/** Signed percentage for an inflation rate, e.g. `+4.2%` / `-1.8%`. */
export function formatInflation(rate: number): string {
  const sign = rate > 0 ? "+" : "";
  return `${sign}${rate.toFixed(1)}%`;
}

export function inflationTone(
  rate: number,
): "inflation" | "deflation" | "neutral" {
  if (rate > 0.05) return "inflation";
  if (rate < -0.05) return "deflation";
  return "neutral";
}

/** Price level rendered with one decimal, e.g. `118.3`. */
export function formatPriceLevel(level: number): string {
  return level.toFixed(1);
}

/** Signed price-index change, e.g. `+1.8` / `-0.4`. */
export function formatPriceDelta(delta: number): string {
  const sign = delta > 0 ? "+" : "";
  return `${sign}${delta.toFixed(1)}`;
}

/* ------------------------------------------------------------------ */
/* Trade                                                               */
/* ------------------------------------------------------------------ */

export const TRADE_STATUS_LABELS: Record<TradeStatus, string> = {
  [TradeStatus.pending]: "Pending",
  [TradeStatus.accepted]: "Accepted",
  [TradeStatus.rejected]: "Rejected",
  [TradeStatus.countered]: "Countered",
  [TradeStatus.cancelled]: "Cancelled",
};

export function tradeStatusLabel(status: TradeStatus): string {
  return TRADE_STATUS_LABELS[status] ?? "Unknown";
}

export function tradeStatusTone(
  status: TradeStatus,
): "positive" | "negative" | "neutral" | "pending" {
  switch (status) {
    case TradeStatus.accepted:
      return "positive";
    case TradeStatus.rejected:
    case TradeStatus.cancelled:
      return "negative";
    case TradeStatus.countered:
      return "pending";
    default:
      return "neutral";
  }
}

/** Compact `food 20 · gold 10` summary of a resource bundle. */
export function formatBundle(bundle: ResourceBundle): string {
  const parts = RESOURCE_ORDER.filter((key) => bundle[key] > 0n).map(
    (key) => `${RESOURCE_LABELS[key]} ${bundle[key].toString()}`,
  );
  return parts.length > 0 ? parts.join(" · ") : "Nothing";
}

/* ------------------------------------------------------------------ */
/* Council                                                             */
/* ------------------------------------------------------------------ */

export const PROPOSAL_KIND_LABELS: Record<ProposalKind, string> = {
  [ProposalKind.tradePact]: "Trade Pact",
  [ProposalKind.jointSpaceProgram]: "Joint Space Program",
  [ProposalKind.territorialClaim]: "Territorial Claim",
  [ProposalKind.peace]: "Peace Accord",
  [ProposalKind.sanctions]: "Sanctions",
};

export function proposalKindLabel(kind: ProposalKind): string {
  return PROPOSAL_KIND_LABELS[kind] ?? "Proposal";
}

export const PROPOSAL_STATUS_LABELS: Record<ProposalStatus, string> = {
  [ProposalStatus.open]: "Open",
  [ProposalStatus.passed]: "Passed",
  [ProposalStatus.failed]: "Failed",
  [ProposalStatus.withdrawn]: "Withdrawn",
};

export function proposalStatusLabel(status: ProposalStatus): string {
  return PROPOSAL_STATUS_LABELS[status] ?? "Unknown";
}

export function proposalStatusTone(
  status: ProposalStatus,
): "positive" | "negative" | "neutral" | "pending" {
  switch (status) {
    case ProposalStatus.passed:
      return "positive";
    case ProposalStatus.failed:
    case ProposalStatus.withdrawn:
      return "negative";
    case ProposalStatus.open:
      return "pending";
    default:
      return "neutral";
  }
}

/* ------------------------------------------------------------------ */
/* Simulation clock                                                    */
/* ------------------------------------------------------------------ */

export const SPEED_LABELS: Record<SimSpeed, string> = {
  [SimSpeed.paused]: "Paused",
  [SimSpeed.x1]: "1×",
  [SimSpeed.x2]: "2×",
  [SimSpeed.x4]: "4×",
};

export function speedLabel(speed: SimSpeed): string {
  return SPEED_LABELS[speed] ?? "1×";
}

/** Ordered speed steps for the time-control bar. */
export const SPEED_ORDER: SimSpeed[] = [
  SimSpeed.paused,
  SimSpeed.x1,
  SimSpeed.x2,
  SimSpeed.x4,
];

/**
 * Format the in-game calendar date from a year offset. The simulation starts in
 * 4000 BCE and advances one year per tick, so year 0 is 1 CE.
 */
export function formatGameDate(year: bigint): string {
  const value = Number(year);
  if (!Number.isFinite(value)) return "—";
  if (value <= 0) return `${Math.abs(value) + 1} BCE`;
  return `${value} CE`;
}

/** In-game date derived from a turn number, one year per turn from 4000 BCE. */
export function gameDateFromTurn(turn: bigint): string {
  return formatGameDate(turn - 4000n);
}
