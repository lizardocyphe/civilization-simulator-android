import { AuthenticatedApp } from "@/components/InternetIdentity";
import { Layout } from "@/components/Layout";
import CouncilScreen from "@/pages/CouncilScreen";
import DiplomacyScreen from "@/pages/DiplomacyScreen";
import EconomyScreen from "@/pages/EconomyScreen";
import SettlementScreen from "@/pages/SettlementScreen";
import SpaceScreen from "@/pages/SpaceScreen";
import StartScreen from "@/pages/StartScreen";
import TechnologyScreen from "@/pages/TechnologyScreen";
import TradeScreen from "@/pages/TradeScreen";
import WeatherScreen from "@/pages/WeatherScreen";
import WorldMapScreen from "@/pages/WorldMapScreen";
import {
  Outlet,
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";

const rootRoute = createRootRoute({
  component: () => (
    <Layout>
      <Outlet />
    </Layout>
  ),
});

const startRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: StartScreen,
});

const mapRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/map",
  component: WorldMapScreen,
});

const settlementRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/settlement",
  component: SettlementScreen,
});

const technologyRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/technology",
  component: TechnologyScreen,
});

const diplomacyRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/diplomacy",
  component: DiplomacyScreen,
});

const economyRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/economy",
  component: EconomyScreen,
});

const tradeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/trade",
  component: TradeScreen,
});

const spaceRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/space",
  component: SpaceScreen,
});

const councilRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/council",
  component: CouncilScreen,
});

const weatherRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/weather",
  component: WeatherScreen,
});

const routeTree = rootRoute.addChildren([
  startRoute,
  mapRoute,
  settlementRoute,
  technologyRoute,
  diplomacyRoute,
  economyRoute,
  tradeRoute,
  spaceRoute,
  councilRoute,
  weatherRoute,
]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return (
    <AuthenticatedApp
      title="CIVILIS"
      description="Sign in with Internet Identity to command your civilization across the ages."
      className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-background px-6 text-center text-foreground"
      buttonClassName="rounded-md bg-primary px-5 py-3 font-display font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 disabled:opacity-60"
    >
      <RouterProvider router={router} />
    </AuthenticatedApp>
  );
}
