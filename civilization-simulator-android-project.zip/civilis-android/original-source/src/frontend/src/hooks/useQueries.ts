import { createActor } from "@/backend";
import { SimSpeed } from "@/types";
import type {
  AiDifficulty,
  CrisisId,
  DiplomaticStance,
  Era,
  GeoLocation,
  HexCoord,
  ProposalKind,
  ResourceBundle,
  RivalId,
  SettlementId,
  TechId,
  TileId,
  UnitId,
} from "@/types";
import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";

/** Query keys shared across the game shell so mutations can invalidate precisely. */
export const gameKeys = {
  game: ["game"] as const,
  map: ["map"] as const,
  settlements: ["settlements"] as const,
  units: ["units"] as const,
  rivals: ["rivals"] as const,
  technologies: ["technologies"] as const,
  milestones: ["milestones"] as const,
  weather: ["weather"] as const,
  crises: ["crises"] as const,
  aiActivity: ["aiActivity"] as const,
  aiDecision: ["aiDecision"] as const,
  aiDifficulty: ["aiDifficulty"] as const,
  economy: ["economy"] as const,
  economyHistory: ["economyHistory"] as const,
  economicPolicies: ["economicPolicies"] as const,
  tradeOffers: ["tradeOffers"] as const,
  tradeHistory: ["tradeHistory"] as const,
  tradeAgreements: ["tradeAgreements"] as const,
  systems: ["systems"] as const,
  fleets: ["fleets"] as const,
  proposals: ["proposals"] as const,
  resolutions: ["resolutions"] as const,
  discussions: ["discussions"] as const,
  simClock: ["simClock"] as const,
};

/** Invalidate every game-state query after a turn-advancing mutation. */
function invalidateGameState(queryClient: ReturnType<typeof useQueryClient>) {
  void queryClient.invalidateQueries({ queryKey: gameKeys.game });
  void queryClient.invalidateQueries({ queryKey: gameKeys.map });
  void queryClient.invalidateQueries({ queryKey: gameKeys.settlements });
  void queryClient.invalidateQueries({ queryKey: gameKeys.units });
  void queryClient.invalidateQueries({ queryKey: gameKeys.rivals });
  void queryClient.invalidateQueries({ queryKey: gameKeys.technologies });
  void queryClient.invalidateQueries({ queryKey: gameKeys.milestones });
  void queryClient.invalidateQueries({ queryKey: gameKeys.weather });
  void queryClient.invalidateQueries({ queryKey: gameKeys.crises });
  void queryClient.invalidateQueries({ queryKey: gameKeys.aiActivity });
  void queryClient.invalidateQueries({ queryKey: gameKeys.aiDecision });
  void queryClient.invalidateQueries({ queryKey: gameKeys.economy });
  void queryClient.invalidateQueries({ queryKey: gameKeys.economyHistory });
  void queryClient.invalidateQueries({ queryKey: gameKeys.tradeOffers });
  void queryClient.invalidateQueries({ queryKey: gameKeys.tradeHistory });
  void queryClient.invalidateQueries({ queryKey: gameKeys.tradeAgreements });
  void queryClient.invalidateQueries({ queryKey: gameKeys.systems });
  void queryClient.invalidateQueries({ queryKey: gameKeys.fleets });
  void queryClient.invalidateQueries({ queryKey: gameKeys.proposals });
  void queryClient.invalidateQueries({ queryKey: gameKeys.resolutions });
  void queryClient.invalidateQueries({ queryKey: gameKeys.discussions });
}

export function useGame() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.game,
    queryFn: async () => {
      if (!actor) return null;
      return actor.loadGame();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useStartGame() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ name, era }: { name: string; era: Era }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.startGame(name, era);
    },
    onSuccess: () => {
      invalidateGameState(queryClient);
    },
  });
}

export function useEndTurn() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.endTurn();
    },
    onSuccess: () => {
      invalidateGameState(queryClient);
    },
  });
}

export function useMap() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.map,
    queryFn: async () => {
      if (!actor) return null;
      return actor.getMap();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useRevealAround() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      coord,
      radius,
    }: { coord: HexCoord; radius: bigint }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.revealAround(coord, radius);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.map });
    },
  });
}

export function useSettlements() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.settlements,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listSettlements();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useFoundSettlement() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      name,
      position,
    }: { name: string; position: HexCoord }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.foundSettlement(name, position);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.settlements });
      void queryClient.invalidateQueries({ queryKey: gameKeys.map });
    },
  });
}

export function useAssignPopulation() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      settlementId,
      tileId,
    }: { settlementId: SettlementId; tileId: TileId }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.assignPopulation(settlementId, tileId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.settlements });
    },
  });
}

export function useConstructBuilding() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      settlementId,
      kind,
    }: { settlementId: SettlementId; kind: string }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.constructBuilding(settlementId, kind);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.settlements });
    },
  });
}

export function useUnits() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.units,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listUnits();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useRecruitUnit() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      kind,
      position,
    }: { kind: string; position: HexCoord }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.recruitUnit(kind, position);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.units });
    },
  });
}

export function useResolveCombat() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      attackerId,
      defenderId,
    }: { attackerId: UnitId; defenderId: UnitId }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.resolveCombat(attackerId, defenderId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.units });
      void queryClient.invalidateQueries({ queryKey: gameKeys.rivals });
    },
  });
}

export function useRivals() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.rivals,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listRivals();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSetDiplomacy() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      rivalId,
      stance,
    }: { rivalId: RivalId; stance: DiplomaticStance }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.setDiplomacy(rivalId, stance);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.rivals });
    },
  });
}

export function useTechnologies() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.technologies,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listTechnologies();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useResearchTechnology() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (techId: TechId) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.researchTechnology(techId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.technologies });
      void queryClient.invalidateQueries({ queryKey: gameKeys.game });
    },
  });
}

export function useMilestones() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.milestones,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listMilestones();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAdvanceEra() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.advanceEra();
    },
    onSuccess: () => {
      invalidateGameState(queryClient);
    },
  });
}

export function useChoosePolicy() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (policyId: bigint) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.choosePolicy(policyId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.game });
    },
  });
}

export function useWeather() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.weather,
    queryFn: async () => {
      if (!actor) return null;
      return actor.getWeather();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useWeatherEffects() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: [...gameKeys.weather, "effects"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getWeatherEffects();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSetLocation() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (location: GeoLocation) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.setLocation(location);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.weather });
    },
  });
}

export function useCrises() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.crises,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listCrises();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useApplyCrisisChoice() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      crisisId,
      choiceId,
    }: { crisisId: CrisisId; choiceId: bigint }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.applyCrisisChoice(crisisId, choiceId);
    },
    onSuccess: () => {
      invalidateGameState(queryClient);
    },
  });
}

/* ------------------------------------------------------------------ */
/* AI opponents                                                        */
/* ------------------------------------------------------------------ */

export function useAiActivity() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.aiActivity,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listAiActivity();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAiDecision() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.aiDecision,
    queryFn: async () => {
      if (!actor) return null;
      return actor.getAiDecision();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAiDifficulty() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.aiDifficulty,
    queryFn: async () => {
      if (!actor) return null;
      return actor.getAiDifficulty();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSetAiDifficulty() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (difficulty: AiDifficulty) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.setAiDifficulty(difficulty);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.aiDifficulty });
    },
  });
}

export function useRunAiTick() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.runAiTick();
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.aiActivity });
      void queryClient.invalidateQueries({ queryKey: gameKeys.aiDecision });
    },
  });
}

/* ------------------------------------------------------------------ */
/* Economy                                                             */
/* ------------------------------------------------------------------ */

export function useEconomy() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.economy,
    queryFn: async () => {
      if (!actor) return null;
      return actor.getEconomy();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useEconomyHistory() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.economyHistory,
    queryFn: async () => {
      if (!actor) return [];
      return actor.getEconomyHistory();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useEconomicPolicies() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.economicPolicies,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listEconomicPolicies();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAdvanceEconomy() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.advanceEconomy();
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.economy });
      void queryClient.invalidateQueries({ queryKey: gameKeys.economyHistory });
    },
  });
}

export function useApplyEconomicPolicy() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (policyId: bigint) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.applyEconomicPolicy(policyId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.economy });
      void queryClient.invalidateQueries({
        queryKey: gameKeys.economicPolicies,
      });
    },
  });
}

export function useScaledCost() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: ["scaledCost"],
    queryFn: async () => {
      if (!actor) return null;
      return actor.scaledCost(0n);
    },
    enabled: !!actor && !isFetching,
  });
}

/* ------------------------------------------------------------------ */
/* Trade                                                               */
/* ------------------------------------------------------------------ */

export function useTradeOffers() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.tradeOffers,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listTradeOffers();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useTradeHistory() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.tradeHistory,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listTradeHistory();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useTradeAgreements() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.tradeAgreements,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listTradeAgreements();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useOpenTradeOffer() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      partnerId,
      offered,
      requested,
      gold,
    }: {
      partnerId: RivalId;
      offered: ResourceBundle;
      requested: ResourceBundle;
      gold: bigint;
    }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.openTradeOffer(partnerId, offered, requested, gold);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.tradeOffers });
      void queryClient.invalidateQueries({ queryKey: gameKeys.tradeHistory });
    },
  });
}

export function useAcceptTradeCounter() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (offerId: bigint) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.acceptTradeCounter(offerId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.tradeOffers });
      void queryClient.invalidateQueries({ queryKey: gameKeys.tradeHistory });
    },
  });
}

export function useCancelTradeOffer() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (offerId: bigint) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.cancelTradeOffer(offerId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.tradeOffers });
    },
  });
}

export function useCreateTradeAgreement() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      partnerId,
      perTick,
      goldPerTick,
    }: {
      partnerId: RivalId;
      perTick: ResourceBundle;
      goldPerTick: bigint;
    }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.createTradeAgreement(partnerId, perTick, goldPerTick);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({
        queryKey: gameKeys.tradeAgreements,
      });
    },
  });
}

export function useCancelTradeAgreement() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (agreementId: bigint) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.cancelTradeAgreement(agreementId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({
        queryKey: gameKeys.tradeAgreements,
      });
    },
  });
}

/* ------------------------------------------------------------------ */
/* Space                                                               */
/* ------------------------------------------------------------------ */

export function useSystems() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.systems,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listSystems();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useFleets() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.fleets,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listFleets();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useLaunchMission() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (coord: HexCoord) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.launchMission(coord);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.systems });
    },
  });
}

export function useClaimSystem() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (systemId: bigint) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.claimSystem(systemId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.systems });
    },
  });
}

export function useColonizeSystem() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (systemId: bigint) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.colonizeSystem(systemId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.systems });
    },
  });
}

export function useBuildFleet() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      systemId,
      ships,
    }: { systemId: bigint; ships: bigint }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.buildFleet(systemId, ships);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.fleets });
    },
  });
}

export function useMoveFleet() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      fleetId,
      targetSystemId,
    }: { fleetId: bigint; targetSystemId: bigint }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.moveFleet(fleetId, targetSystemId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.fleets });
    },
  });
}

export function useResolveSpaceBattle() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      fleetId,
      targetSystemId,
    }: { fleetId: bigint; targetSystemId: bigint }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.resolveSpaceBattle(fleetId, targetSystemId);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.fleets });
      void queryClient.invalidateQueries({ queryKey: gameKeys.systems });
    },
  });
}

/* ------------------------------------------------------------------ */
/* World council                                                       */
/* ------------------------------------------------------------------ */

export function useProposals() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.proposals,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listProposals();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useResolutions() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.resolutions,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listResolutions();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useVotes(proposalId: bigint | null) {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: [
      ...gameKeys.proposals,
      "votes",
      proposalId?.toString() ?? "none",
    ],
    queryFn: async () => {
      if (!actor || proposalId === null) return [];
      return actor.listVotes(proposalId);
    },
    enabled: !!actor && !isFetching && proposalId !== null,
  });
}

export function useDiscussions() {
  const { actor, isFetching } = useActor(createActor);
  return useQuery({
    queryKey: gameKeys.discussions,
    queryFn: async () => {
      if (!actor) return [];
      return actor.listDiscussions();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useRaiseProposal() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      kind,
      description,
    }: { kind: ProposalKind; description: string }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.raiseProposal(kind, description);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.proposals });
    },
  });
}

export function useDiscussWithNation() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      rivalId,
      message,
    }: { rivalId: RivalId; message: string }) => {
      if (!actor) throw new Error("Backend is not ready");
      return actor.discussWithNation(rivalId, message);
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: gameKeys.discussions });
    },
  });
}

/* ------------------------------------------------------------------ */
/* Simulation clock                                                    */
/* ------------------------------------------------------------------ */

/**
 * Milliseconds between autonomous simulation ticks for each speed step. The
 * clock is paused at `SimSpeed.paused`, so it has no interval.
 */
const SPEED_INTERVAL_MS: Record<SimSpeed, number> = {
  [SimSpeed.paused]: 0,
  [SimSpeed.x1]: 5000,
  [SimSpeed.x2]: 2500,
  [SimSpeed.x4]: 1250,
};

/**
 * The simulation clock. While the clock is running, a timer advances the world
 * on the selected speed: each interval calls `endTurn`, which steps the
 * simulation clock and runs every coupled system (production, the offline AI
 * for each rival, the economy and standing trade agreements). Pausing clears
 * the timer so the world stops advancing until the player resumes or presses
 * End Turn. Returns the current tick, the active speed, its setter and whether
 * the clock is running.
 */
export function useSimClock() {
  const { data: game } = useGame();
  const endTurn = useEndTurn();
  const [speed, setSpeed] = useState<SimSpeed>(SimSpeed.paused);
  const tick = game?.turn ?? 0n;
  const running = speed !== SimSpeed.paused && !!game;

  // Keep the latest mutation in a ref so the interval effect does not restart
  // on every render while the clock is running.
  const advanceRef = useRef(endTurn.mutate);
  advanceRef.current = endTurn.mutate;

  useEffect(() => {
    if (!running) return;
    const intervalMs = SPEED_INTERVAL_MS[speed];
    if (intervalMs <= 0) return;
    const id = window.setInterval(() => {
      advanceRef.current();
    }, intervalMs);
    return () => window.clearInterval(id);
  }, [running, speed]);

  return { tick, speed, setSpeed, running };
}
