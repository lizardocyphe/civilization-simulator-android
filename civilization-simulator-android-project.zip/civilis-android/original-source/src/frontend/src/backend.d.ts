import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export type ActionResult = {
    __kind__: "ok";
    ok: null;
} | {
    __kind__: "err";
    err: string;
};
export interface AiActivity {
    action: AiActionKind;
    tick: bigint;
    reasoning: string;
    rival: RivalId;
}
export interface AiDecision {
    action: AiActionKind;
    tick: bigint;
    reasoning: string;
    score: bigint;
    considered: Array<string>;
    rival: RivalId;
}
export interface Building {
    id: BuildingId;
    kind: string;
    name: string;
    productionBonus: ResourcePool;
    level: bigint;
}
export type BuildingId = bigint;
export interface Cell {
    value: Value;
    name: string;
}
export interface Civilization {
    id: GameId;
    era: Era;
    resources: ResourcePool;
    name: string;
    stability: bigint;
    isPlayer: boolean;
    researchPoints: bigint;
    policies: Array<Policy>;
}
export interface CombatResult {
    attackerLosses: bigint;
    defenderLosses: bigint;
    summary: string;
    attackerWon: boolean;
}
export interface CrisisChoice {
    id: bigint;
    name: string;
    effect: CrisisEffect;
}
export interface CrisisEffect {
    resourceDelta: ResourcePool;
    stabilityDelta: bigint;
    summary: string;
}
export interface CrisisEvent {
    id: bigint;
    resolved: boolean;
    title: string;
    kind: string;
    description: string;
    choices: Array<CrisisChoice>;
}
export type CrisisId = bigint;
export interface CrisisOutcome {
    resourceDelta: ResourcePool;
    crisisId: bigint;
    choiceId: bigint;
    stabilityDelta: bigint;
    summary: string;
    severity: bigint;
}
export interface DiscussionMessage {
    nation: RivalId;
    text: string;
    tick: bigint;
    speaker: string;
}
export interface EconomicPolicy {
    id: bigint;
    name: string;
    description: string;
    interestRateDelta: number;
    taxRateDelta: number;
    spendingDelta: bigint;
}
export interface EconomyState {
    priceLevel: number;
    inflationRate: number;
    history: Array<EconomyTick>;
    upkeep: bigint;
    interestRate: number;
    income: bigint;
    spending: bigint;
    taxRate: number;
    moneySupply: bigint;
}
export interface EconomyTick {
    priceLevel: number;
    inflationRate: number;
    tick: bigint;
    upkeep: bigint;
    income: bigint;
    moneySupply: bigint;
}
export interface EraMilestone {
    era: Era;
    requiredBuildings: bigint;
    requiredTechs: Array<TechId>;
    requiredPopulation: bigint;
}
export type Error_ = {
    __kind__: "FrontendOriginsNotConfigured";
    FrontendOriginsNotConfigured: null;
} | {
    __kind__: "MixedSsoSources";
    MixedSsoSources: {
        otherKeys: Array<string>;
        ssoKeys: Array<string>;
    };
} | {
    __kind__: "Stale";
    Stale: {
        ageNs: bigint;
    };
} | {
    __kind__: "MalformedCandid";
    MalformedCandid: null;
} | {
    __kind__: "AmbiguousAttribute";
    AmbiguousAttribute: {
        field: string;
        sources: Array<string>;
    };
} | {
    __kind__: "NoAttributes";
    NoAttributes: null;
} | {
    __kind__: "UnknownNonce";
    UnknownNonce: null;
} | {
    __kind__: "UntrustedSsoSource";
    UntrustedSsoSource: {
        domain: string;
    };
} | {
    __kind__: "MissingField";
    MissingField: string;
} | {
    __kind__: "FrontendOriginMismatch";
    FrontendOriginMismatch: {
        got: string;
        expected: Array<string>;
    };
};
export interface Fleet {
    id: bigint;
    movement: bigint;
    owner: GameId;
    systemId: bigint;
    ships: bigint;
    strength: bigint;
}
export type GameId = bigint;
export interface GameState {
    id: GameId;
    createdAt: Timestamp;
    turn: bigint;
    updatedAt: Timestamp;
    civilization: Civilization;
}
export interface GeoLocation {
    latitude: number;
    name: string;
    longitude: number;
}
export interface HexCoord {
    q: bigint;
    r: bigint;
}
export interface HexMap {
    height: bigint;
    tiles: Array<Tile>;
    width: bigint;
}
export interface HttpHeader {
    value: string;
    name: string;
}
export interface HttpRequestResult {
    status: bigint;
    body: Uint8Array;
    headers: Array<HttpHeader>;
}
export interface Policy {
    id: bigint;
    name: string;
    description: string;
    effect: string;
}
export interface Proposal {
    id: bigint;
    status: ProposalStatus;
    votesAgainst: bigint;
    votesFor: bigint;
    kind: ProposalKind;
    description: string;
    sponsor: RivalId;
}
export interface Resolution {
    id: bigint;
    kind: ProposalKind;
    effect: string;
    passedTick: bigint;
    proposalId: bigint;
}
export interface ResourceBundle {
    production: bigint;
    food: bigint;
    gold: bigint;
    culture: bigint;
    influence: bigint;
    science: bigint;
}
export interface ResourceNode {
    kind: string;
    renewable: boolean;
    amount: bigint;
}
export interface ResourcePocket {
    kind: PocketKind;
    renewable: boolean;
    remaining: bigint;
    initial: bigint;
    renewalRate: bigint;
}
export interface ResourcePool {
    production: bigint;
    food: bigint;
    gold: bigint;
    culture: bigint;
    influence: bigint;
    science: bigint;
}
export interface Result {
    hasMore: boolean;
    rows: Array<Array<Cell>>;
}
export type Result__1 = {
    __kind__: "ok";
    ok: null;
} | {
    __kind__: "err";
    err: Error_;
};
export interface Rival {
    id: RivalId;
    era: Era;
    stance: DiplomaticStance;
    name: string;
    strength: bigint;
}
export type RivalId = bigint;
export interface Settlement {
    id: SettlementId;
    workedTiles: Array<TileId>;
    production: ResourcePool;
    owner: GameId;
    name: string;
    position: HexCoord;
    population: bigint;
    buildings: Array<Building>;
}
export type SettlementId = bigint;
export interface SpaceBattleResult {
    attackerLosses: bigint;
    defenderLosses: bigint;
    summary: string;
    attackerWon: boolean;
    capturedSystem?: bigint;
}
export interface StandingAgreement {
    id: bigint;
    active: boolean;
    perTick: ResourceBundle;
    startedTick: bigint;
    goldPerTick: bigint;
    partner: RivalId;
}
export interface StarSystem {
    id: bigint;
    resourceYield: ResourcePool;
    owner?: GameId;
    name: string;
    coord: HexCoord;
    claimed: boolean;
    planets: bigint;
    defense: bigint;
    discovered: boolean;
}
export type TechId = bigint;
export interface Technology {
    id: TechId;
    era: Era;
    prerequisites: Array<TechId>;
    cost: bigint;
    name: string;
    unlocked: boolean;
}
export interface Tile {
    id: TileId;
    fog: FogState;
    resource?: ResourceNode;
    terrain: Terrain;
    owner?: GameId;
    coord: HexCoord;
    pocket?: ResourcePocket;
}
export type TileId = bigint;
export type Timestamp = bigint;
export interface TradeHistoryEntry {
    requested: ResourceBundle;
    gold: bigint;
    tick: bigint;
    summary: string;
    offered: ResourceBundle;
    partner: RivalId;
}
export interface TradeOffer {
    id: bigint;
    status: TradeStatus;
    requested: ResourceBundle;
    gold: bigint;
    createdTick: bigint;
    offered: ResourceBundle;
    partner: RivalId;
}
export interface TransformationInput {
    context: Uint8Array;
    response: HttpRequestResult;
}
export interface TransformationOutput {
    status: bigint;
    body: Uint8Array;
    headers: Array<HttpHeader>;
}
export interface TurnSummary {
    stabilityDelta: bigint;
    turn: bigint;
    events: Array<string>;
    resourcesGained: ResourcePool;
}
export interface Unit {
    id: UnitId;
    movement: bigint;
    owner: GameId;
    kind: string;
    strength: bigint;
    position: HexCoord;
}
export type UnitId = bigint;
export type Value = {
    __kind__: "int";
    int: bigint;
} | {
    __kind__: "nat";
    nat: bigint;
} | {
    __kind__: "float";
    float: number;
} | {
    __kind__: "bool";
    bool: boolean;
} | {
    __kind__: "null";
    null: null;
} | {
    __kind__: "text";
    text: string;
};
export interface Vote {
    nation: RivalId;
    inFavour: boolean;
    reason: string;
}
export interface WeatherEffects {
    harvestMultiplier: number;
    movementMultiplier: number;
    summary: string;
    energyDemandMultiplier: number;
}
export interface WeatherState {
    precipitationMm: number;
    updatedAt: Timestamp;
    temperatureC: number;
    location?: GeoLocation;
    windKph: number;
    condition: string;
}
export enum AiActionKind {
    trade = "trade",
    recruit = "recruit",
    research = "research",
    idle = "idle",
    diplomacy = "diplomacy",
    space = "space",
    build = "build",
    expand = "expand",
    attack = "attack"
}
export enum AiDifficulty {
    aggressive = "aggressive",
    passive = "passive",
    balanced = "balanced"
}
export enum DiplomaticStance {
    war = "war",
    alliance = "alliance",
    peace = "peace",
    neutral = "neutral"
}
export enum Era {
    ancient = "ancient",
    information = "information",
    modern = "modern",
    industrial = "industrial"
}
export enum FogState {
    explored = "explored",
    visible = "visible",
    unexplored = "unexplored"
}
export enum PocketKind {
    production = "production",
    food = "food",
    gold = "gold",
    culture = "culture",
    influence = "influence",
    science = "science"
}
export enum ProposalKind {
    tradePact = "tradePact",
    jointSpaceProgram = "jointSpaceProgram",
    territorialClaim = "territorialClaim",
    peace = "peace",
    sanctions = "sanctions"
}
export enum ProposalStatus {
    open = "open",
    withdrawn = "withdrawn",
    failed = "failed",
    passed = "passed"
}
export enum Terrain {
    ice = "ice",
    tundra = "tundra",
    jungle = "jungle",
    hills = "hills",
    ocean = "ocean",
    plains = "plains",
    mesa = "mesa",
    coast = "coast",
    reef = "reef",
    desert = "desert",
    grassland = "grassland",
    mountains = "mountains",
    savanna = "savanna",
    wetlands = "wetlands",
    volcanic = "volcanic",
    forest = "forest"
}
export enum TradeStatus {
    cancelled = "cancelled",
    pending = "pending",
    countered = "countered",
    rejected = "rejected",
    accepted = "accepted"
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    /**
     * / Accept a countered offer, transferring the rival's revised terms.
     */
    acceptTradeCounter(offerId: bigint): Promise<ActionResult>;
    /**
     * / Advance the caller's economy one tick and return the new state.
     */
    advanceEconomy(): Promise<EconomyState>;
    /**
     * / Advance to the next era if the milestone is met.
     */
    advanceEra(): Promise<ActionResult>;
    /**
     * / Apply a crisis choice and return its visible consequences.
     */
    applyCrisisChoice(crisisId: CrisisId, choiceId: bigint): Promise<CrisisOutcome | null>;
    /**
     * / Apply an economic policy to the caller's economy.
     */
    applyEconomicPolicy(policyId: bigint): Promise<ActionResult>;
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    /**
     * / Assign a population unit to work a tile.
     */
    assignPopulation(settlementId: SettlementId, tileId: TileId): Promise<ActionResult>;
    /**
     * / Build a fleet at a star system the caller owns.
     */
    buildFleet(systemId: bigint, ships: bigint): Promise<ActionResult>;
    /**
     * / Cancel a standing agreement.
     */
    cancelTradeAgreement(agreementId: bigint): Promise<ActionResult>;
    /**
     * / Cancel a pending or countered trade offer.
     */
    cancelTradeOffer(offerId: bigint): Promise<ActionResult>;
    /**
     * / Choose a policy to adopt.
     */
    choosePolicy(policyId: bigint): Promise<ActionResult>;
    /**
     * / Claim a discovered star system for the caller's civilization.
     */
    claimSystem(systemId: bigint): Promise<ActionResult>;
    /**
     * / Colonize a claimed star system to increase its resource yield.
     */
    colonizeSystem(systemId: bigint): Promise<ActionResult>;
    /**
     * / Construct a building in a settlement.
     */
    constructBuilding(settlementId: SettlementId, kind: string): Promise<ActionResult>;
    /**
     * / Create a standing agreement that exchanges a bundle every simulation tick.
     */
    createTradeAgreement(partnerId: RivalId, perTick: ResourceBundle, goldPerTick: bigint): Promise<ActionResult>;
    /**
     * / Open a discussion with a rival and receive an AI-generated reply.
     * / Falls back to a deterministic rule-based reply if inference fails.
     */
    discussWithNation(rivalId: RivalId, message: string): Promise<DiscussionMessage>;
    /**
     * / End the current turn and return the turn summary.
     */
    endTurn(): Promise<TurnSummary>;
    execute(qJson: string): Promise<Result>;
    /**
     * / Found a new settlement at a coordinate.
     */
    foundSettlement(name: string, position: HexCoord): Promise<ActionResult>;
    /**
     * / The most recent AI decision the caller's rivals made, if any.
     */
    getAiDecision(): Promise<AiDecision | null>;
    /**
     * / The caller's current AI difficulty setting.
     */
    getAiDifficulty(): Promise<AiDifficulty>;
    /**
     * / Return the backend's behavioral API documentation as Markdown.
     */
    getApiDoc(): Promise<string>;
    getCallerUserRole(): Promise<UserRole>;
    /**
     * / Return the caller's current macro-economic state.
     */
    getEconomy(): Promise<EconomyState>;
    /**
     * / Return the caller's recorded per-tick economic history for trend display.
     */
    getEconomyHistory(): Promise<Array<EconomyTick>>;
    /**
     * / Return the current hex map.
     */
    getMap(): Promise<HexMap>;
    /**
     * / Return the current weather state.
     */
    getWeather(): Promise<WeatherState>;
    /**
     * / Derive in-game effects from the current weather reading.
     */
    getWeatherEffects(): Promise<WeatherEffects>;
    isCallerAdmin(): Promise<boolean>;
    /**
     * / Launch an exploration mission to a coordinate, discovering a star system.
     */
    launchMission(coord: HexCoord): Promise<ActionResult>;
    /**
     * / The caller's AI activity log, newest entries last.
     */
    listAiActivity(): Promise<Array<AiActivity>>;
    /**
     * / List the player's crisis events.
     */
    listCrises(): Promise<Array<CrisisEvent>>;
    /**
     * / The full discussion thread for the caller.
     */
    listDiscussions(): Promise<Array<DiscussionMessage>>;
    /**
     * / List the fiscal and monetary policies the player can adopt.
     */
    listEconomicPolicies(): Promise<Array<EconomicPolicy>>;
    /**
     * / List the caller's fleets.
     */
    listFleets(): Promise<Array<Fleet>>;
    /**
     * / List the era milestone requirements.
     */
    listMilestones(): Promise<Array<EraMilestone>>;
    /**
     * / List every proposal the caller has raised.
     */
    listProposals(): Promise<Array<Proposal>>;
    /**
     * / List every resolution that has passed.
     */
    listResolutions(): Promise<Array<Resolution>>;
    /**
     * / List the known rivals.
     */
    listRivals(): Promise<Array<Rival>>;
    /**
     * / List the caller's settlements.
     */
    listSettlements(): Promise<Array<Settlement>>;
    /**
     * / List the star systems the caller has charted.
     */
    listSystems(): Promise<Array<StarSystem>>;
    /**
     * / List all technologies and their unlock state.
     */
    listTechnologies(): Promise<Array<Technology>>;
    /**
     * / List the caller's standing agreements.
     */
    listTradeAgreements(): Promise<Array<StandingAgreement>>;
    /**
     * / List the caller's completed-trade history.
     */
    listTradeHistory(): Promise<Array<TradeHistoryEntry>>;
    /**
     * / List the caller's trade offers.
     */
    listTradeOffers(): Promise<Array<TradeOffer>>;
    /**
     * / List the caller's units.
     */
    listUnits(): Promise<Array<Unit>>;
    /**
     * / The votes cast on a proposal, with each rival's stated reason.
     */
    listVotes(proposalId: bigint): Promise<Array<Vote>>;
    /**
     * / Load the saved game for the caller.
     */
    loadGame(): Promise<GameState | null>;
    /**
     * / Move a fleet to another discovered star system within range.
     */
    moveFleet(fleetId: bigint, targetSystemId: bigint): Promise<ActionResult>;
    /**
     * / Open a trade offer with a known rival proposing an exchange of resources
     * / and gold. The rival evaluates it deterministically and the offer resolves
     * / to accepted, rejected or countered.
     */
    openTradeOffer(partnerId: RivalId, offered: ResourceBundle, requested: ResourceBundle, gold: bigint): Promise<ActionResult>;
    /**
     * / Raise a council proposal of any kind and put it to a vote.
     */
    raiseProposal(kind: ProposalKind, description: string): Promise<Proposal>;
    /**
     * / Recruit a new unit at a coordinate.
     */
    recruitUnit(kind: string, position: HexCoord): Promise<ActionResult>;
    /**
     * / Begin researching a technology.
     */
    researchTechnology(techId: TechId): Promise<ActionResult>;
    /**
     * / Resolve combat between two units.
     */
    resolveCombat(attackerId: UnitId, defenderId: UnitId): Promise<CombatResult>;
    /**
     * / Engage a hostile fleet or defended system and return the battle outcome.
     */
    resolveSpaceBattle(fleetId: bigint, targetSystemId: bigint): Promise<SpaceBattleResult>;
    /**
     * / Reveal tiles around a coordinate.
     */
    revealAround(coord: HexCoord, radius: bigint): Promise<void>;
    /**
     * / Run one AI evaluation for the caller's rivals on the current tick.
     * / Returns the activity entries recorded this tick.
     */
    runAiTick(): Promise<Array<AiActivity>>;
    /**
     * / Scale a base cost by the caller's current price level, so every cost the
     * / player sees reflects inflation or deflation.
     */
    scaledCost(baseCost: bigint): Promise<bigint>;
    schema(): Promise<string>;
    /**
     * / Set the caller's AI difficulty.
     */
    setAiDifficulty(difficulty: AiDifficulty): Promise<ActionResult>;
    /**
     * / Set the diplomatic stance toward a rival.
     */
    setDiplomacy(rivalId: RivalId, stance: DiplomaticStance): Promise<ActionResult>;
    /**
     * / Set the player's real-world location and fetch live weather for it.
     */
    setLocation(location: GeoLocation): Promise<ActionResult>;
    /**
     * / Spawn a crisis of the given kind, scaled by the player's civilization.
     */
    spawnCrisis(kind: string): Promise<bigint>;
    /**
     * / Start a new game with a civilization name and starting era.
     */
    startGame(name: string, era: Era): Promise<GameState>;
    /**
     * / Trade resources with a discovered rival.
     */
    trade(partnerId: RivalId, resource: string, amount: bigint): Promise<ActionResult>;
    /**
     * / HTTP outcall response-normalization callback required by the weather fetch.
     */
    transform(input: TransformationInput): Promise<TransformationOutput>;
}
