import { ScreenShell } from "@/components/ScreenShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  useAiActivity,
  useAiDifficulty,
  useRecruitUnit,
  useResolveCombat,
  useRivals,
  useSetAiDifficulty,
  useSetDiplomacy,
  useUnits,
} from "@/hooks/useQueries";
import { eraLabel, formatNumber } from "@/lib/game";
import {
  AiActionKind,
  AiDifficulty,
  type CombatResult,
  DiplomaticStance,
  type Rival,
  type RivalId,
  type Unit,
} from "@/types";
import {
  AlertTriangle,
  Brain,
  Crosshair,
  Loader2,
  RefreshCw,
  Shield,
  Swords,
  Users,
} from "lucide-react";
import { useState } from "react";

/* ------------------------------------------------------------------ */
/* Labels                                                              */
/* ------------------------------------------------------------------ */

const STANCE_LABELS: Record<DiplomaticStance, string> = {
  [DiplomaticStance.alliance]: "Alliance",
  [DiplomaticStance.peace]: "Peace",
  [DiplomaticStance.neutral]: "Neutral",
  [DiplomaticStance.war]: "War",
};

const STANCE_ORDER: DiplomaticStance[] = [
  DiplomaticStance.alliance,
  DiplomaticStance.peace,
  DiplomaticStance.neutral,
  DiplomaticStance.war,
];

const STANCE_TONE: Record<DiplomaticStance, string> = {
  [DiplomaticStance.alliance]:
    "border-success/50 bg-success/15 text-success hover:bg-success/25",
  [DiplomaticStance.peace]:
    "border-accent/50 bg-accent/15 text-accent hover:bg-accent/25",
  [DiplomaticStance.neutral]:
    "border-border bg-secondary text-muted-foreground hover:bg-secondary/70",
  [DiplomaticStance.war]:
    "border-destructive/50 bg-destructive/15 text-destructive hover:bg-destructive/25",
};

const DIFFICULTY_LABELS: Record<AiDifficulty, string> = {
  [AiDifficulty.passive]: "Passive",
  [AiDifficulty.balanced]: "Balanced",
  [AiDifficulty.aggressive]: "Aggressive",
};

const DIFFICULTY_ORDER: AiDifficulty[] = [
  AiDifficulty.passive,
  AiDifficulty.balanced,
  AiDifficulty.aggressive,
];

const ACTION_LABELS: Record<AiActionKind, string> = {
  [AiActionKind.trade]: "Trade",
  [AiActionKind.recruit]: "Recruit",
  [AiActionKind.research]: "Research",
  [AiActionKind.idle]: "Idle",
  [AiActionKind.diplomacy]: "Diplomacy",
  [AiActionKind.space]: "Space",
  [AiActionKind.build]: "Build",
  [AiActionKind.expand]: "Expand",
  [AiActionKind.attack]: "Attack",
};

const ACTION_TONE: Record<AiActionKind, string> = {
  [AiActionKind.attack]: "text-destructive",
  [AiActionKind.diplomacy]: "text-accent",
  [AiActionKind.trade]: "text-primary",
  [AiActionKind.research]: "text-chart-4",
  [AiActionKind.space]: "text-chart-4",
  [AiActionKind.recruit]: "text-warning",
  [AiActionKind.build]: "text-warning",
  [AiActionKind.expand]: "text-success",
  [AiActionKind.idle]: "text-muted-foreground",
};

const UNIT_KINDS = ["warrior", "archer", "cavalry", "siege"] as const;

function unitKindLabel(kind: string): string {
  return kind.charAt(0).toUpperCase() + kind.slice(1);
}

/* ------------------------------------------------------------------ */
/* Shared bits                                                         */
/* ------------------------------------------------------------------ */

function SectionCard({
  title,
  icon: Icon,
  action,
  children,
  ocid,
}: {
  title: string;
  icon: typeof Shield;
  action?: React.ReactNode;
  children: React.ReactNode;
  ocid: string;
}) {
  return (
    <section
      data-ocid={ocid}
      className="rounded-md border border-border bg-card shadow-subtle"
    >
      <header className="flex items-center justify-between gap-2 border-b border-border/70 px-3 py-2">
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          <Icon className="size-4 text-primary" aria-hidden="true" />
          {title}
        </h2>
        {action}
      </header>
      <div className="p-3">{children}</div>
    </section>
  );
}

function LoadingRows({ ocid }: { ocid: string }) {
  const ids = Array.from({ length: 3 }, (_, i) => `${ocid}-skeleton-${i}`);
  return (
    <div data-ocid={ocid} className="space-y-2" aria-busy="true">
      {ids.map((id) => (
        <div
          key={id}
          className="h-16 animate-pulse rounded-md border border-border bg-secondary/60"
        />
      ))}
      <span className="sr-only">Loading…</span>
    </div>
  );
}

function ErrorState({
  ocid,
  message,
  onRetry,
}: {
  ocid: string;
  message: string;
  onRetry: () => void;
}) {
  return (
    <div
      data-ocid={ocid}
      role="alert"
      className="flex flex-col items-start gap-2 rounded-md border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive"
    >
      <span className="flex items-center gap-2 font-medium">
        <AlertTriangle className="size-4" aria-hidden="true" />
        {message}
      </span>
      <Button
        type="button"
        variant="outline"
        size="sm"
        data-ocid={`${ocid}.retry_button`}
        onClick={onRetry}
        className="h-9 rounded-md border-destructive/50 text-destructive hover:bg-destructive/15"
      >
        <RefreshCw className="size-3.5" aria-hidden="true" />
        Retry
      </Button>
    </div>
  );
}

function EmptyState({
  ocid,
  icon: Icon,
  title,
  hint,
}: {
  ocid: string;
  icon: typeof Shield;
  title: string;
  hint: string;
}) {
  return (
    <div
      data-ocid={ocid}
      className="flex flex-col items-center gap-1 rounded-md border border-dashed border-border bg-background/40 px-4 py-6 text-center"
    >
      <Icon className="size-6 text-muted-foreground" aria-hidden="true" />
      <p className="font-display text-sm font-semibold text-foreground">
        {title}
      </p>
      <p className="max-w-xs text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Rivals                                                              */
/* ------------------------------------------------------------------ */

function RivalCard({
  rival,
  index,
  pending,
  onSetStance,
}: {
  rival: Rival;
  index: number;
  pending: boolean;
  onSetStance: (rivalId: RivalId, stance: DiplomaticStance) => void;
}) {
  return (
    <article
      data-ocid={`diplomacy.rival.item.${index + 1}`}
      className="rounded-md border border-border bg-background/50 p-3"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h3 className="truncate font-display text-base font-semibold text-foreground">
            {rival.name}
          </h3>
          <p className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
            {eraLabel(rival.era)}
          </p>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1">
          <Badge
            variant="outline"
            data-ocid={`diplomacy.rival.stance.${index + 1}`}
            className={`border font-mono text-[0.65rem] uppercase tracking-widest ${STANCE_TONE[rival.stance]}`}
          >
            {STANCE_LABELS[rival.stance]}
          </Badge>
          <span className="flex items-center gap-1 font-mono text-xs tabular-nums text-muted-foreground">
            <Swords className="size-3" aria-hidden="true" />
            {formatNumber(rival.strength)}
          </span>
        </div>
      </div>

      <fieldset className="mt-3">
        <legend className="mb-1.5 font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
          Diplomatic stance
        </legend>
        <div className="grid grid-cols-2 gap-1.5">
          {STANCE_ORDER.map((stance) => {
            const active = rival.stance === stance;
            return (
              <Button
                key={stance}
                type="button"
                variant="outline"
                size="sm"
                data-ocid={`diplomacy.rival.stance_button.${index + 1}.${stance}`}
                aria-pressed={active}
                disabled={pending || active}
                onClick={() => onSetStance(rival.id, stance)}
                className={`h-10 rounded-md border font-display text-xs font-semibold uppercase tracking-wider transition-smooth ${
                  active
                    ? STANCE_TONE[stance]
                    : "border-border bg-secondary/60 text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                {STANCE_LABELS[stance]}
              </Button>
            );
          })}
        </div>
      </fieldset>
    </article>
  );
}

function RivalsPanel() {
  const rivals = useRivals();
  const setDiplomacy = useSetDiplomacy();

  return (
    <SectionCard
      ocid="diplomacy.rivals.panel"
      title="Rival Nations"
      icon={Shield}
      action={
        <span className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
          {rivals.data ? `${rivals.data.length} known` : "—"}
        </span>
      }
    >
      {rivals.isLoading ? (
        <LoadingRows ocid="diplomacy.rivals.loading_state" />
      ) : rivals.isError ? (
        <ErrorState
          ocid="diplomacy.rivals.error_state"
          message="Could not load rival nations."
          onRetry={() => void rivals.refetch()}
        />
      ) : !rivals.data || rivals.data.length === 0 ? (
        <EmptyState
          ocid="diplomacy.rivals.empty_state"
          icon={Shield}
          title="No rivals encountered"
          hint="Explore the map to make contact with other civilizations."
        />
      ) : (
        <div className="space-y-2">
          {rivals.data.map((rival, index) => (
            <RivalCard
              key={rival.id.toString()}
              rival={rival}
              index={index}
              pending={setDiplomacy.isPending}
              onSetStance={(rivalId, stance) =>
                setDiplomacy.mutate({ rivalId, stance })
              }
            />
          ))}
          {setDiplomacy.isError && (
            <p
              data-ocid="diplomacy.rivals.mutation_error"
              role="alert"
              className="text-xs text-destructive"
            >
              Could not update stance. Try again.
            </p>
          )}
        </div>
      )}
    </SectionCard>
  );
}

/* ------------------------------------------------------------------ */
/* AI activity                                                         */
/* ------------------------------------------------------------------ */

function AiPanel() {
  const activity = useAiActivity();
  const difficulty = useAiDifficulty();
  const setDifficulty = useSetAiDifficulty();
  const rivals = useRivals();

  const rivalName = (id: RivalId): string =>
    rivals.data?.find((r) => r.id === id)?.name ?? `Nation ${id.toString()}`;

  const current = difficulty.data ?? AiDifficulty.balanced;

  return (
    <SectionCard
      ocid="diplomacy.ai.panel"
      title="Autonomous Opponents"
      icon={Brain}
    >
      <fieldset className="mb-3">
        <legend className="mb-1.5 font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
          AI difficulty
        </legend>
        <div className="grid grid-cols-3 gap-1.5">
          {DIFFICULTY_ORDER.map((level) => {
            const active = current === level;
            return (
              <Button
                key={level}
                type="button"
                variant="outline"
                size="sm"
                data-ocid={`diplomacy.ai.difficulty_button.${level}`}
                aria-pressed={active}
                disabled={setDifficulty.isPending || active}
                onClick={() => setDifficulty.mutate(level)}
                className={`h-10 rounded-md border font-display text-xs font-semibold uppercase tracking-wider transition-smooth ${
                  active
                    ? "border-primary/60 bg-primary/20 text-primary"
                    : "border-border bg-secondary/60 text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                {DIFFICULTY_LABELS[level]}
              </Button>
            );
          })}
        </div>
        {setDifficulty.isError && (
          <p
            data-ocid="diplomacy.ai.mutation_error"
            role="alert"
            className="mt-1.5 text-xs text-destructive"
          >
            Could not change AI difficulty. Try again.
          </p>
        )}
      </fieldset>

      <h3 className="mb-1.5 font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
        Activity log
      </h3>
      {activity.isLoading ? (
        <LoadingRows ocid="diplomacy.ai.loading_state" />
      ) : activity.isError ? (
        <ErrorState
          ocid="diplomacy.ai.error_state"
          message="Could not load AI activity."
          onRetry={() => void activity.refetch()}
        />
      ) : !activity.data || activity.data.length === 0 ? (
        <EmptyState
          ocid="diplomacy.ai.empty_state"
          icon={Brain}
          title="No AI activity yet"
          hint="Rival nations act as the simulation clock advances."
        />
      ) : (
        <ol data-ocid="diplomacy.ai.list" className="space-y-2">
          {activity.data.map((entry, index) => (
            <li
              key={`${entry.rival.toString()}-${entry.tick.toString()}-${index}`}
              data-ocid={`diplomacy.ai.item.${index + 1}`}
              className="rounded-md border border-border bg-background/50 p-2.5"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-sm font-medium text-foreground">
                  {rivalName(entry.rival)}
                </span>
                <span
                  className={`shrink-0 font-mono text-[0.65rem] font-semibold uppercase tracking-widest ${ACTION_TONE[entry.action]}`}
                >
                  {ACTION_LABELS[entry.action]}
                </span>
              </div>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                {entry.reasoning}
              </p>
              <p className="mt-1 font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground/70">
                Tick {formatNumber(entry.tick)}
              </p>
            </li>
          ))}
        </ol>
      )}
    </SectionCard>
  );
}

/* ------------------------------------------------------------------ */
/* Military                                                            */
/* ------------------------------------------------------------------ */

function MilitaryPanel() {
  const units = useUnits();
  const recruit = useRecruitUnit();
  const combat = useResolveCombat();

  const [kind, setKind] = useState<string>(UNIT_KINDS[0]);
  const [attackerId, setAttackerId] = useState<string>("");
  const [defenderId, setDefenderId] = useState<string>("");
  const [outcome, setOutcome] = useState<CombatResult | null>(null);

  const playerUnits: Unit[] = units.data ?? [];
  const rivalUnits: Unit[] = units.data ?? [];

  const handleRecruit = () => {
    recruit.mutate(
      { kind, position: { q: 0n, r: 0n } },
      { onSuccess: () => setKind(UNIT_KINDS[0]) },
    );
  };

  const handleResolve = () => {
    if (!attackerId || !defenderId) return;
    combat.mutate(
      { attackerId: BigInt(attackerId), defenderId: BigInt(defenderId) },
      { onSuccess: (result) => setOutcome(result) },
    );
  };

  return (
    <SectionCard
      ocid="diplomacy.military.panel"
      title="Military Command"
      icon={Crosshair}
    >
      {/* Recruit */}
      <div className="mb-4">
        <h3 className="mb-1.5 font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
          Recruit a unit
        </h3>
        <div className="grid grid-cols-2 gap-1.5">
          {UNIT_KINDS.map((unitKind) => {
            const active = kind === unitKind;
            return (
              <Button
                key={unitKind}
                type="button"
                variant="outline"
                size="sm"
                data-ocid={`diplomacy.military.kind_button.${unitKind}`}
                aria-pressed={active}
                onClick={() => setKind(unitKind)}
                className={`h-10 rounded-md border font-display text-xs font-semibold uppercase tracking-wider transition-smooth ${
                  active
                    ? "border-primary/60 bg-primary/20 text-primary"
                    : "border-border bg-secondary/60 text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                {unitKindLabel(unitKind)}
              </Button>
            );
          })}
        </div>
        <Button
          type="button"
          data-ocid="diplomacy.military.recruit_button"
          onClick={handleRecruit}
          disabled={recruit.isPending}
          className="mt-2 h-11 w-full rounded-md bg-primary font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110 disabled:opacity-60"
        >
          {recruit.isPending ? (
            <>
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              Recruiting…
            </>
          ) : (
            <>
              <Users className="size-4" aria-hidden="true" />
              Recruit {unitKindLabel(kind)}
            </>
          )}
        </Button>
        {recruit.isError && (
          <p
            data-ocid="diplomacy.military.recruit_error"
            role="alert"
            className="mt-1.5 text-xs text-destructive"
          >
            Recruitment failed. Check your resources and try again.
          </p>
        )}
      </div>

      {/* Combat */}
      <div className="border-t border-border/70 pt-3">
        <h3 className="mb-1.5 font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
          Resolve combat
        </h3>
        {units.isLoading ? (
          <LoadingRows ocid="diplomacy.military.loading_state" />
        ) : units.isError ? (
          <ErrorState
            ocid="diplomacy.military.error_state"
            message="Could not load your units."
            onRetry={() => void units.refetch()}
          />
        ) : playerUnits.length === 0 ? (
          <EmptyState
            ocid="diplomacy.military.empty_state"
            icon={Crosshair}
            title="No units in the field"
            hint="Recruit a unit above before engaging a rival."
          />
        ) : (
          <div className="space-y-2">
            <label className="block">
              <span className="mb-1 block font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
                Attacker
              </span>
              <select
                data-ocid="diplomacy.military.attacker_select"
                value={attackerId}
                onChange={(event) => setAttackerId(event.target.value)}
                className="h-11 w-full rounded-md border border-input bg-background px-2 text-sm text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
              >
                <option value="">Select a unit…</option>
                {playerUnits.map((unit) => (
                  <option key={unit.id.toString()} value={unit.id.toString()}>
                    {unitKindLabel(unit.kind)} · {formatNumber(unit.strength)}{" "}
                    str
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="mb-1 block font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
                Defender
              </span>
              <select
                data-ocid="diplomacy.military.defender_select"
                value={defenderId}
                onChange={(event) => setDefenderId(event.target.value)}
                className="h-11 w-full rounded-md border border-input bg-background px-2 text-sm text-foreground focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
              >
                <option value="">Select a target…</option>
                {rivalUnits.map((unit) => (
                  <option key={unit.id.toString()} value={unit.id.toString()}>
                    {unitKindLabel(unit.kind)} · {formatNumber(unit.strength)}{" "}
                    str
                  </option>
                ))}
              </select>
            </label>
            <Button
              type="button"
              data-ocid="diplomacy.military.resolve_button"
              onClick={handleResolve}
              disabled={combat.isPending || !attackerId || !defenderId}
              className="h-11 w-full rounded-md bg-destructive font-display text-sm font-semibold uppercase tracking-widest text-destructive-foreground transition-smooth hover:brightness-110 disabled:opacity-60"
            >
              {combat.isPending ? (
                <>
                  <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                  Resolving…
                </>
              ) : (
                <>
                  <Swords className="size-4" aria-hidden="true" />
                  Resolve Combat
                </>
              )}
            </Button>
            {combat.isError && (
              <p
                data-ocid="diplomacy.military.combat_error"
                role="alert"
                className="text-xs text-destructive"
              >
                Combat could not be resolved. Try again.
              </p>
            )}
          </div>
        )}

        {outcome && (
          <output
            data-ocid="diplomacy.military.outcome"
            className={`mt-3 block rounded-md border p-3 ${
              outcome.attackerWon
                ? "border-success/50 bg-success/10"
                : "border-destructive/50 bg-destructive/10"
            }`}
          >
            <p
              className={`font-display text-sm font-semibold uppercase tracking-widest ${
                outcome.attackerWon ? "text-success" : "text-destructive"
              }`}
            >
              {outcome.attackerWon ? "Victory" : "Defeat"}
            </p>
            <p className="mt-1 text-xs text-foreground">{outcome.summary}</p>
            <dl className="mt-2 grid grid-cols-2 gap-2 font-mono text-xs tabular-nums">
              <div className="rounded-sm border border-border bg-background/50 px-2 py-1">
                <dt className="text-[0.6rem] uppercase tracking-widest text-muted-foreground">
                  Your losses
                </dt>
                <dd className="text-foreground">
                  {formatNumber(outcome.attackerLosses)}
                </dd>
              </div>
              <div className="rounded-sm border border-border bg-background/50 px-2 py-1">
                <dt className="text-[0.6rem] uppercase tracking-widest text-muted-foreground">
                  Enemy losses
                </dt>
                <dd className="text-foreground">
                  {formatNumber(outcome.defenderLosses)}
                </dd>
              </div>
            </dl>
          </output>
        )}
      </div>
    </SectionCard>
  );
}

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function DiplomacyScreen() {
  return (
    <ScreenShell
      eyebrow="Exterminate"
      title="Diplomacy & Military"
      description="Set stances toward rivals, recruit units, and resolve combat."
    >
      <div data-ocid="diplomacy.page" className="flex flex-col gap-4">
        <RivalsPanel />
        <AiPanel />
        <MilitaryPanel />
      </div>
    </ScreenShell>
  );
}
