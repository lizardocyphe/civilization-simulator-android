import { ScreenShell } from "@/components/ScreenShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useConstructBuilding,
  useEconomy,
  useGame,
  useMap,
  useSettlements,
} from "@/hooks/useQueries";
import {
  RESOURCE_ICONS,
  RESOURCE_LABELS,
  RESOURCE_ORDER,
  formatNumber,
  formatPriceLevel,
  terrainLabel,
} from "@/lib/game";
import type { ResourcePool, Settlement, Tile } from "@/types";
import { AlertTriangle, Hammer, MapPin, Users } from "lucide-react";
import { useMemo, useState } from "react";

/** Building catalog mirroring the backend `buildingCost` / `buildingBonus`. */
const BUILDING_CATALOG = [
  {
    kind: "Granary",
    baseCost: 10n,
    bonus: { food: 2n },
    blurb: "Stores surplus grain, feeding a growing population.",
  },
  {
    kind: "Workshop",
    baseCost: 15n,
    bonus: { production: 3n },
    blurb: "Turns raw materials into tools and finished goods.",
  },
  {
    kind: "Market",
    baseCost: 20n,
    bonus: { gold: 3n },
    blurb: "A trading hub that fills the treasury each turn.",
  },
  {
    kind: "Library",
    baseCost: 25n,
    bonus: { science: 3n },
    blurb: "Preserves knowledge and accelerates research.",
  },
] as const;

type BuildingKind = (typeof BUILDING_CATALOG)[number]["kind"];

/** Scale a base cost by the current price level, matching backend `scaledCost`. */
function scaledCost(baseCost: bigint, priceLevel: number): bigint {
  const scaled = Number(baseCost) * priceLevel;
  if (!Number.isFinite(scaled) || scaled <= 0) return 0n;
  return BigInt(Math.floor(scaled));
}

function PoolChips({
  pool,
  emptyLabel,
}: {
  pool: ResourcePool;
  emptyLabel: string;
}) {
  const entries = RESOURCE_ORDER.filter((key) => pool[key] > 0n);
  if (entries.length === 0) {
    return <span className="text-xs text-muted-foreground">{emptyLabel}</span>;
  }
  return (
    <div className="flex flex-wrap gap-1.5">
      {entries.map((key) => (
        <span
          key={key}
          className="inline-flex items-center gap-1 rounded-sm border border-border bg-background/60 px-1.5 py-0.5 font-mono text-xs tabular-nums text-foreground"
        >
          <span aria-hidden="true">{RESOURCE_ICONS[key]}</span>
          <span className="sr-only">{RESOURCE_LABELS[key]}</span>
          <span aria-hidden="true">+{formatNumber(pool[key])}</span>
        </span>
      ))}
    </div>
  );
}

function SettlementListItem({
  settlement,
  selected,
  onSelect,
}: {
  settlement: Settlement;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      data-ocid={`settlement.item.${settlement.id}`}
      aria-pressed={selected}
      onClick={onSelect}
      className={`flex min-h-14 w-full items-center justify-between gap-3 rounded-md border px-3 py-2 text-left transition-smooth ${
        selected
          ? "border-accent/60 bg-accent/15"
          : "border-border bg-card hover:bg-secondary"
      }`}
    >
      <span className="flex min-w-0 flex-col">
        <span className="truncate font-display text-sm font-semibold text-foreground">
          {settlement.name}
        </span>
        <span className="flex items-center gap-1 font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
          <MapPin className="size-3" aria-hidden="true" />
          {settlement.position.q.toString()}, {settlement.position.r.toString()}
        </span>
      </span>
      <span className="flex shrink-0 items-center gap-1 font-mono text-sm tabular-nums text-foreground">
        <Users className="size-3.5 text-muted-foreground" aria-hidden="true" />
        {formatNumber(settlement.population)}
      </span>
    </button>
  );
}

function WorkedTiles({
  settlement,
  tilesById,
}: {
  settlement: Settlement;
  tilesById: Map<string, Tile>;
}) {
  const worked = settlement.workedTiles
    .map((id) => tilesById.get(id.toString()))
    .filter((tile): tile is Tile => tile !== undefined);

  const freePopulation =
    settlement.population - BigInt(settlement.workedTiles.length);

  return (
    <section
      data-ocid="settlement.worked_tiles"
      className="rounded-md border border-border bg-card p-3 shadow-subtle"
    >
      <div className="mb-2 flex items-center justify-between gap-2">
        <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          Worked Tiles
        </h2>
        <Badge
          variant="outline"
          className="border-border bg-background/60 font-mono text-xs tabular-nums"
        >
          {settlement.workedTiles.length}/{formatNumber(settlement.population)}{" "}
          assigned
        </Badge>
      </div>

      {worked.length === 0 ? (
        <p
          data-ocid="settlement.worked_tiles.empty_state"
          className="rounded-sm border border-dashed border-border px-3 py-4 text-center text-xs text-muted-foreground"
        >
          No tiles are being worked yet. Assign population from the map to
          harvest resources.
        </p>
      ) : (
        <ul className="flex flex-col gap-1.5">
          {worked.map((tile) => (
            <li
              key={tile.id.toString()}
              data-ocid={`settlement.worked_tile.${tile.id}`}
              className="flex items-center justify-between gap-2 rounded-sm border border-border bg-background/50 px-2.5 py-2"
            >
              <span className="flex min-w-0 flex-col">
                <span className="truncate text-sm font-medium text-foreground">
                  {terrainLabel(tile.terrain)}
                </span>
                <span className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
                  {tile.coord.q.toString()}, {tile.coord.r.toString()}
                </span>
              </span>
              <PoolChips pool={tileYieldPool(tile)} emptyLabel="No yield" />
            </li>
          ))}
        </ul>
      )}

      <p className="mt-2 text-xs text-muted-foreground">
        {freePopulation > 0n
          ? `${formatNumber(freePopulation)} population available to assign.`
          : "All population is assigned to tiles."}
      </p>
      <p
        data-ocid="settlement.assign.hint"
        className="mt-1 text-xs text-muted-foreground"
      >
        Assign population from the map screen by selecting an owned tile.
      </p>
    </section>
  );
}

/** Local terrain yield table mirroring the backend `tileYield` base values. */
function tileYieldPool(tile: Tile): ResourcePool {
  const empty: ResourcePool = {
    food: 0n,
    production: 0n,
    science: 0n,
    gold: 0n,
    culture: 0n,
    influence: 0n,
  };
  const base: Partial<ResourcePool> = TERRAIN_BASE_YIELDS[tile.terrain] ?? {};
  const pool: ResourcePool = { ...empty, ...base };
  if (tile.resource) {
    const key = tile.resource.kind as keyof ResourcePool;
    if (key in pool) {
      pool[key] = pool[key] + tile.resource.amount;
    }
  }
  return pool;
}

const TERRAIN_BASE_YIELDS: Record<string, Partial<ResourcePool>> = {
  grassland: { food: 3n },
  plains: { food: 2n, production: 1n },
  forest: { food: 1n, production: 2n },
  hills: { production: 3n },
  mountains: { production: 2n, gold: 1n },
  desert: { gold: 2n },
  coast: { food: 2n, gold: 1n },
  ocean: { food: 1n, gold: 1n },
  reef: { food: 2n, culture: 1n },
  savanna: { food: 1n, production: 1n },
  mesa: { production: 1n, gold: 1n },
  jungle: { food: 1n, science: 1n },
  wetlands: { food: 2n, production: 1n },
  tundra: { food: 1n },
  ice: {},
  volcanic: { production: 2n, science: 1n },
};

function BuildingPanel({
  settlement,
  priceLevel,
  production,
  constructPending,
  onConstruct,
}: {
  settlement: Settlement;
  priceLevel: number;
  production: bigint;
  constructPending: boolean;
  onConstruct: (kind: BuildingKind) => void;
}) {
  const builtCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const building of settlement.buildings) {
      counts.set(building.kind, (counts.get(building.kind) ?? 0) + 1);
    }
    return counts;
  }, [settlement.buildings]);

  return (
    <section
      data-ocid="settlement.buildings"
      className="rounded-md border border-border bg-card p-3 shadow-subtle"
    >
      <div className="mb-2 flex items-center justify-between gap-2">
        <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          Buildings
        </h2>
        <Badge
          variant="outline"
          className="border-border bg-background/60 font-mono text-xs tabular-nums"
        >
          {settlement.buildings.length} built
        </Badge>
      </div>

      {settlement.buildings.length === 0 ? (
        <p
          data-ocid="settlement.buildings.empty_state"
          className="mb-3 rounded-sm border border-dashed border-border px-3 py-3 text-center text-xs text-muted-foreground"
        >
          No buildings yet. Construct one below to boost this settlement's
          output.
        </p>
      ) : (
        <ul className="mb-3 flex flex-col gap-1.5">
          {settlement.buildings.map((building) => (
            <li
              key={building.id.toString()}
              data-ocid={`settlement.building.${building.id}`}
              className="flex items-center justify-between gap-2 rounded-sm border border-border bg-background/50 px-2.5 py-2"
            >
              <span className="flex min-w-0 items-center gap-2">
                <Hammer
                  className="size-3.5 shrink-0 text-muted-foreground"
                  aria-hidden="true"
                />
                <span className="truncate text-sm font-medium text-foreground">
                  {building.name}
                </span>
                <span className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
                  Lv {formatNumber(building.level)}
                </span>
              </span>
              <PoolChips
                pool={building.productionBonus}
                emptyLabel="No bonus"
              />
            </li>
          ))}
        </ul>
      )}

      <h3 className="mb-1.5 font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
        Construct
      </h3>
      <ul className="flex flex-col gap-2">
        {BUILDING_CATALOG.map((entry) => {
          const cost = scaledCost(entry.baseCost, priceLevel);
          const affordable = production >= cost;
          const built = builtCounts.get(entry.kind) ?? 0;
          return (
            <li
              key={entry.kind}
              data-ocid={`settlement.build_option.${entry.kind.toLowerCase()}`}
              className="rounded-sm border border-border bg-background/50 p-2.5"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
                    {entry.kind}
                    {built > 0 && (
                      <span className="font-mono text-[0.65rem] font-normal uppercase tracking-widest text-muted-foreground">
                        ×{built}
                      </span>
                    )}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {entry.blurb}
                  </p>
                  <div className="mt-1.5">
                    <PoolChips
                      pool={{ ...EMPTY_POOL, ...entry.bonus }}
                      emptyLabel="No bonus"
                    />
                  </div>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1.5">
                  <span className="font-mono text-sm font-semibold tabular-nums text-foreground">
                    {formatNumber(cost)}
                    <span className="ml-1 text-[0.65rem] font-normal uppercase tracking-widest text-muted-foreground">
                      prod
                    </span>
                  </span>
                  <Button
                    type="button"
                    size="sm"
                    data-ocid={`settlement.construct_button.${entry.kind.toLowerCase()}`}
                    disabled={!affordable || constructPending}
                    onClick={() => onConstruct(entry.kind)}
                    className="h-11 min-w-24 rounded-md bg-primary font-display text-xs font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110 disabled:opacity-50"
                  >
                    Build
                  </Button>
                </div>
              </div>
              {!affordable && (
                <p
                  data-ocid={`settlement.construct_error.${entry.kind.toLowerCase()}`}
                  className="mt-1.5 flex items-center gap-1 text-xs text-destructive"
                >
                  <AlertTriangle className="size-3" aria-hidden="true" />
                  Needs {formatNumber(cost - production)} more production.
                </p>
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
}

const EMPTY_POOL: ResourcePool = {
  food: 0n,
  production: 0n,
  science: 0n,
  gold: 0n,
  culture: 0n,
  influence: 0n,
};

function SettlementDetail({
  settlement,
  tilesById,
  priceLevel,
  production,
}: {
  settlement: Settlement;
  tilesById: Map<string, Tile>;
  priceLevel: number;
  production: bigint;
}) {
  const constructBuilding = useConstructBuilding();
  const [feedback, setFeedback] = useState<{
    tone: "error" | "success";
    message: string;
  } | null>(null);

  const handleConstruct = (kind: BuildingKind) => {
    setFeedback(null);
    constructBuilding.mutate(
      { settlementId: settlement.id, kind },
      {
        onSuccess: (result) => {
          if (result.__kind__ === "err") {
            setFeedback({ tone: "error", message: result.err });
          } else {
            setFeedback({
              tone: "success",
              message: `${kind} constructed in ${settlement.name}.`,
            });
          }
        },
        onError: (error) => {
          setFeedback({
            tone: "error",
            message:
              error instanceof Error
                ? error.message
                : "Construction could not be completed.",
          });
        },
      },
    );
  };

  return (
    <div className="flex flex-col gap-3">
      <section
        data-ocid="settlement.summary"
        className="rounded-md border border-border bg-card p-3 shadow-subtle"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="truncate font-display text-lg font-bold text-foreground">
              {settlement.name}
            </h2>
            <p className="flex items-center gap-1 font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
              <MapPin className="size-3" aria-hidden="true" />
              {settlement.position.q.toString()},{" "}
              {settlement.position.r.toString()}
            </p>
          </div>
          <div className="flex shrink-0 flex-col items-end">
            <span className="flex items-center gap-1 font-mono text-lg font-semibold tabular-nums text-foreground">
              <Users
                className="size-4 text-muted-foreground"
                aria-hidden="true"
              />
              {formatNumber(settlement.population)}
            </span>
            <span className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
              population
            </span>
          </div>
        </div>

        <div className="mt-3 border-t border-border/60 pt-3">
          <p className="mb-1.5 font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
            Per-turn production
          </p>
          <PoolChips
            pool={settlement.production}
            emptyLabel="No production yet"
          />
          <p className="mt-2 font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
            Price level {formatPriceLevel(priceLevel)} · costs scale with
            inflation
          </p>
        </div>
      </section>

      {feedback && (
        <output
          data-ocid={
            feedback.tone === "error"
              ? "settlement.error_state"
              : "settlement.success_state"
          }
          className={`flex items-center gap-1.5 rounded-md border px-3 py-2 text-sm ${
            feedback.tone === "error"
              ? "border-destructive/50 bg-destructive/10 text-destructive"
              : "border-success/50 bg-success/10 text-success"
          }`}
        >
          {feedback.tone === "error" && (
            <AlertTriangle className="size-4 shrink-0" aria-hidden="true" />
          )}
          {feedback.message}
        </output>
      )}

      <WorkedTiles settlement={settlement} tilesById={tilesById} />

      <BuildingPanel
        settlement={settlement}
        priceLevel={priceLevel}
        production={production}
        constructPending={constructBuilding.isPending}
        onConstruct={handleConstruct}
      />
    </div>
  );
}

function LoadingState() {
  const ids = Array.from({ length: 3 }, (_, i) => `settlement-skeleton-${i}`);
  return (
    <div data-ocid="settlement.loading_state" className="flex flex-col gap-3">
      {ids.map((id) => (
        <Skeleton key={id} className="h-16 w-full rounded-md" />
      ))}
    </div>
  );
}

export default function SettlementScreen() {
  const settlementsQuery = useSettlements();
  const mapQuery = useMap();
  const economyQuery = useEconomy();
  const gameQuery = useGame();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const settlements = settlementsQuery.data ?? [];
  const priceLevel = economyQuery.data?.priceLevel ?? 1;
  const production = gameQuery.data?.civilization.resources.production ?? 0n;

  const tilesById = useMemo(() => {
    const map = new Map<string, Tile>();
    for (const tile of mapQuery.data?.tiles ?? []) {
      map.set(tile.id.toString(), tile);
    }
    return map;
  }, [mapQuery.data]);

  const selected = useMemo(() => {
    if (settlements.length === 0) return null;
    const match = settlements.find((s) => s.id.toString() === selectedId);
    return match ?? settlements[0];
  }, [settlements, selectedId]);

  const isLoading = settlementsQuery.isLoading || mapQuery.isLoading;
  const isError = settlementsQuery.isError || mapQuery.isError;

  return (
    <ScreenShell
      eyebrow="Expand"
      title="Settlements"
      description="Manage population, worked tiles, and building construction across your cities."
    >
      {isLoading ? (
        <LoadingState />
      ) : isError ? (
        <div
          data-ocid="settlement.error_state"
          className="flex flex-col items-center gap-3 rounded-md border border-destructive/50 bg-destructive/10 px-4 py-6 text-center"
        >
          <AlertTriangle
            className="size-6 text-destructive"
            aria-hidden="true"
          />
          <p className="text-sm text-destructive">
            Your settlements could not be loaded.
          </p>
          <Button
            type="button"
            data-ocid="settlement.retry_button"
            onClick={() => {
              void settlementsQuery.refetch();
              void mapQuery.refetch();
            }}
            className="h-11 rounded-md bg-primary px-4 font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground"
          >
            Retry
          </Button>
        </div>
      ) : settlements.length === 0 ? (
        <div
          data-ocid="settlement.empty_state"
          className="flex flex-col items-center gap-2 rounded-md border border-dashed border-border bg-card px-4 py-8 text-center"
        >
          <MapPin className="size-6 text-muted-foreground" aria-hidden="true" />
          <p className="font-display text-sm font-semibold text-foreground">
            No settlements yet
          </p>
          <p className="max-w-xs text-xs text-muted-foreground">
            Found your first settlement from the map screen to begin expanding
            your civilization.
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          <section
            data-ocid="settlement.list"
            className="flex flex-col gap-2"
            aria-label="Your settlements"
          >
            <h2 className="font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
              Your Settlements
            </h2>
            {settlements.map((settlement) => (
              <SettlementListItem
                key={settlement.id.toString()}
                settlement={settlement}
                selected={selected?.id === settlement.id}
                onSelect={() => setSelectedId(settlement.id.toString())}
              />
            ))}
          </section>

          {selected && (
            <SettlementDetail
              settlement={selected}
              tilesById={tilesById}
              priceLevel={priceLevel}
              production={production}
            />
          )}
        </div>
      )}
    </ScreenShell>
  );
}
