import { ScreenShell } from "@/components/ScreenShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  useDiscussWithNation,
  useDiscussions,
  useProposals,
  useRaiseProposal,
  useResolutions,
  useRivals,
  useVotes,
} from "@/hooks/useQueries";
import {
  formatNumber,
  proposalKindLabel,
  proposalStatusLabel,
  proposalStatusTone,
} from "@/lib/game";
import {
  type DiscussionMessage,
  type Proposal,
  ProposalKind,
  type Rival,
  type RivalId,
  type Vote,
} from "@/types";
import {
  AlertTriangle,
  Check,
  ChevronDown,
  Gavel,
  Loader2,
  MessageSquare,
  RefreshCw,
  Send,
  ThumbsDown,
  ThumbsUp,
} from "lucide-react";
import { type FormEvent, useState } from "react";

const PROPOSAL_KINDS: ProposalKind[] = [
  ProposalKind.tradePact,
  ProposalKind.peace,
  ProposalKind.sanctions,
  ProposalKind.territorialClaim,
  ProposalKind.jointSpaceProgram,
];

const TONE_CLASSES: Record<ReturnType<typeof proposalStatusTone>, string> = {
  positive: "border-success/50 bg-success/15 text-success",
  negative: "border-destructive/50 bg-destructive/15 text-destructive",
  pending: "border-primary/50 bg-primary/15 text-primary",
  neutral: "border-border bg-secondary text-muted-foreground",
};

function StatusBadge({ status }: { status: Proposal["status"] }) {
  return (
    <Badge
      variant="outline"
      className={`font-mono text-[0.65rem] uppercase tracking-widest ${TONE_CLASSES[proposalStatusTone(status)]}`}
    >
      {proposalStatusLabel(status)}
    </Badge>
  );
}

function rivalName(rivals: Rival[], id: RivalId): string {
  return rivals.find((rival) => rival.id === id)?.name ?? `Nation ${id}`;
}

function VoteRow({ vote, rivals }: { vote: Vote; rivals: Rival[] }) {
  return (
    <li className="flex items-start gap-2 rounded-sm border border-border/70 bg-background/50 px-2.5 py-2">
      <span
        className={`mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full ${
          vote.inFavour
            ? "bg-success/20 text-success"
            : "bg-destructive/20 text-destructive"
        }`}
        aria-hidden="true"
      >
        {vote.inFavour ? (
          <ThumbsUp className="size-3" />
        ) : (
          <ThumbsDown className="size-3" />
        )}
      </span>
      <div className="min-w-0 flex-1">
        <p className="flex items-center gap-2 text-sm font-medium text-foreground">
          <span className="truncate">{rivalName(rivals, vote.nation)}</span>
          <span
            className={`font-mono text-[0.6rem] uppercase tracking-widest ${
              vote.inFavour ? "text-success" : "text-destructive"
            }`}
          >
            {vote.inFavour ? "For" : "Against"}
          </span>
        </p>
        <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
          {vote.reason}
        </p>
      </div>
    </li>
  );
}

function ProposalCard({
  proposal,
  rivals,
}: {
  proposal: Proposal;
  rivals: Rival[];
}) {
  const [open, setOpen] = useState(false);
  const votes = useVotes(open ? proposal.id : null);
  const total = proposal.votesFor + proposal.votesAgainst;
  const forPct = total > 0n ? Number((proposal.votesFor * 100n) / total) : 0;

  return (
    <li
      data-ocid={`council.proposal.${proposal.id}`}
      className="rounded-md border border-border bg-card shadow-subtle"
    >
      <div className="flex flex-col gap-2 p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="font-display text-sm font-semibold text-foreground">
              {proposalKindLabel(proposal.kind)}
            </p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Sponsored by {rivalName(rivals, proposal.sponsor)}
            </p>
          </div>
          <StatusBadge status={proposal.status} />
        </div>

        <p className="text-sm leading-relaxed text-foreground/90">
          {proposal.description}
        </p>

        <div className="space-y-1">
          <div className="flex items-center justify-between font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
            <span className="text-success">
              {formatNumber(proposal.votesFor)} for
            </span>
            <span className="text-destructive">
              {formatNumber(proposal.votesAgainst)} against
            </span>
          </div>
          <div
            className="flex h-2 overflow-hidden rounded-full bg-destructive/25"
            role="img"
            aria-label={`${forPct}% of votes in favour`}
          >
            <div
              className="h-full bg-success transition-smooth"
              style={{ width: `${forPct}%` }}
            />
          </div>
        </div>

        <Button
          type="button"
          variant="ghost"
          data-ocid={`council.toggle_votes_button.${proposal.id}`}
          aria-expanded={open}
          onClick={() => setOpen((value) => !value)}
          className="h-10 justify-between rounded-sm px-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          {open ? "Hide votes" : "Show votes"}
          <ChevronDown
            className={`size-4 transition-smooth ${open ? "rotate-180" : ""}`}
            aria-hidden="true"
          />
        </Button>
      </div>

      {open && (
        <div className="border-t border-border/70 px-3 py-2">
          {votes.isLoading ? (
            <p
              data-ocid={`council.votes_loading.${proposal.id}`}
              className="flex items-center gap-2 py-2 text-xs text-muted-foreground"
            >
              <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />
              Tallying votes…
            </p>
          ) : votes.isError ? (
            <p
              data-ocid={`council.votes_error.${proposal.id}`}
              className="py-2 text-xs text-destructive"
            >
              Could not load votes for this proposal.
            </p>
          ) : (votes.data?.length ?? 0) === 0 ? (
            <p
              data-ocid={`council.votes_empty.${proposal.id}`}
              className="py-2 text-xs text-muted-foreground"
            >
              No nations have cast a vote yet.
            </p>
          ) : (
            <ul className="flex flex-col gap-1.5">
              {votes.data?.map((vote) => (
                <VoteRow
                  key={`${proposal.id}-${vote.nation}`}
                  vote={vote}
                  rivals={rivals}
                />
              ))}
            </ul>
          )}
        </div>
      )}
    </li>
  );
}

function ProposalComposer() {
  const [kind, setKind] = useState<ProposalKind>(ProposalKind.tradePact);
  const [description, setDescription] = useState("");
  const raise = useRaiseProposal();

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const text = description.trim();
    if (text.length === 0) return;
    setDescription("");
    raise.mutate(
      { kind, description: text },
      {
        onError: () =>
          setDescription((current) => (current === "" ? text : current)),
      },
    );
  }

  return (
    <form
      data-ocid="council.proposal_form"
      onSubmit={handleSubmit}
      className="flex flex-col gap-3 rounded-md border border-border bg-card p-3 shadow-subtle"
    >
      <div className="flex items-center gap-2">
        <Gavel className="size-4 text-primary" aria-hidden="true" />
        <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          Raise a Proposal
        </h2>
      </div>

      <div className="flex flex-col gap-1.5">
        <label
          htmlFor="council-kind"
          className="font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground"
        >
          Proposal kind
        </label>
        <select
          id="council-kind"
          data-ocid="council.kind_select"
          value={kind}
          onChange={(event) => setKind(event.target.value as ProposalKind)}
          className="h-11 w-full rounded-sm border border-input bg-background px-3 text-sm text-foreground transition-smooth focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
        >
          {PROPOSAL_KINDS.map((option) => (
            <option key={option} value={option}>
              {proposalKindLabel(option)}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1.5">
        <label
          htmlFor="council-description"
          className="font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground"
        >
          Description
        </label>
        <Textarea
          id="council-description"
          data-ocid="council.description_textarea"
          value={description}
          onChange={(event) => setDescription(event.target.value)}
          placeholder="State the terms you want the council to consider…"
          rows={3}
          className="min-h-20 rounded-sm border-input bg-background text-sm"
        />
      </div>

      {raise.isError && (
        <p
          data-ocid="council.proposal_error"
          className="flex items-center gap-2 text-xs text-destructive"
        >
          <AlertTriangle className="size-3.5" aria-hidden="true" />
          The proposal could not be raised. Check your connection and try again.
        </p>
      )}

      <Button
        type="submit"
        data-ocid="council.raise_button"
        disabled={raise.isPending || description.trim().length === 0}
        className="h-11 rounded-md bg-primary font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110 disabled:opacity-60"
      >
        {raise.isPending ? (
          <>
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            Raising…
          </>
        ) : (
          "Raise Proposal"
        )}
      </Button>
    </form>
  );
}

function ResolutionsPanel() {
  const resolutions = useResolutions();

  return (
    <section
      data-ocid="council.resolutions_panel"
      className="flex flex-col gap-2"
    >
      <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
        Passed Resolutions
      </h2>

      {resolutions.isLoading ? (
        <div
          data-ocid="council.resolutions_loading"
          className="flex flex-col gap-2"
        >
          {Array.from({ length: 2 }, (_, i) => `resolution-skeleton-${i}`).map(
            (id) => (
              <div
                key={id}
                className="h-16 animate-pulse rounded-md border border-border bg-card"
              />
            ),
          )}
        </div>
      ) : resolutions.isError ? (
        <p
          data-ocid="council.resolutions_error"
          className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive"
        >
          Resolutions could not be loaded.
        </p>
      ) : (resolutions.data?.length ?? 0) === 0 ? (
        <p
          data-ocid="council.resolutions_empty"
          className="rounded-md border border-border bg-card p-4 text-sm text-muted-foreground shadow-subtle"
        >
          No resolutions have passed yet. Raise a proposal and win the vote to
          shape the world.
        </p>
      ) : (
        <ul className="flex flex-col gap-2">
          {resolutions.data?.map((resolution) => (
            <li
              key={resolution.id}
              data-ocid={`council.resolution.${resolution.id}`}
              className="rounded-md border border-border bg-card p-3 shadow-subtle"
            >
              <div className="flex items-center justify-between gap-2">
                <p className="flex items-center gap-2 font-display text-sm font-semibold text-foreground">
                  <Check className="size-4 text-success" aria-hidden="true" />
                  {proposalKindLabel(resolution.kind)}
                </p>
                <span className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
                  Tick {formatNumber(resolution.passedTick)}
                </span>
              </div>
              <p className="mt-1 text-sm leading-relaxed text-foreground/90">
                {resolution.effect}
              </p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function DiscussionPanel({ rivals }: { rivals: Rival[] }) {
  const discussions = useDiscussions();
  const discuss = useDiscussWithNation();
  const [rivalId, setRivalId] = useState<RivalId | null>(null);
  const [message, setMessage] = useState("");
  const [reply, setReply] = useState<DiscussionMessage | null>(null);

  const activeRivalId = rivalId ?? rivals[0]?.id ?? null;

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const text = message.trim();
    if (text.length === 0 || activeRivalId === null) return;
    setMessage("");
    setReply(null);
    discuss.mutate(
      { rivalId: activeRivalId, message: text },
      {
        onSuccess: (response) => setReply(response),
        onError: () =>
          setMessage((current) => (current === "" ? text : current)),
      },
    );
  }

  return (
    <section
      data-ocid="council.discussion_panel"
      className="flex flex-col gap-3 rounded-md border border-border bg-card p-3 shadow-subtle"
    >
      <div className="flex items-center gap-2">
        <MessageSquare className="size-4 text-accent" aria-hidden="true" />
        <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          Open a Discussion
        </h2>
      </div>

      {rivals.length === 0 ? (
        <p
          data-ocid="council.discussion_empty"
          className="text-sm text-muted-foreground"
        >
          No rival nations are known yet, so there is no one to negotiate with.
        </p>
      ) : (
        <>
          <div className="flex flex-col gap-1.5">
            <label
              htmlFor="council-rival"
              className="font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground"
            >
              Nation
            </label>
            <select
              id="council-rival"
              data-ocid="council.rival_select"
              value={activeRivalId !== null ? activeRivalId.toString() : ""}
              onChange={(event) => {
                setRivalId(BigInt(event.target.value));
                setReply(null);
              }}
              className="h-11 w-full rounded-sm border border-input bg-background px-3 text-sm text-foreground transition-smooth focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
            >
              {rivals.map((rival) => (
                <option key={rival.id} value={rival.id.toString()}>
                  {rival.name}
                </option>
              ))}
            </select>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-2">
            <label
              htmlFor="council-message"
              className="font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground"
            >
              Your position
            </label>
            <Textarea
              id="council-message"
              data-ocid="council.message_textarea"
              value={message}
              onChange={(event) => setMessage(event.target.value)}
              placeholder="Make your case to the council…"
              rows={3}
              className="min-h-20 rounded-sm border-input bg-background text-sm"
            />
            <Button
              type="submit"
              data-ocid="council.send_button"
              disabled={discuss.isPending || message.trim().length === 0}
              className="h-11 rounded-md bg-accent font-display text-sm font-semibold uppercase tracking-widest text-accent-foreground transition-smooth hover:brightness-110 disabled:opacity-60"
            >
              {discuss.isPending ? (
                <>
                  <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                  Awaiting reply…
                </>
              ) : (
                <>
                  <Send className="size-4" aria-hidden="true" />
                  Send Message
                </>
              )}
            </Button>
          </form>

          {discuss.isPending && (
            <p
              data-ocid="council.reply_pending"
              className="flex items-center gap-2 rounded-sm border border-border bg-background/60 px-3 py-2 text-xs text-muted-foreground"
            >
              <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />
              The nation is drafting its response…
            </p>
          )}

          {discuss.isError && (
            <div
              data-ocid="council.reply_error"
              className="flex flex-col gap-2 rounded-sm border border-destructive/40 bg-destructive/10 px-3 py-2"
            >
              <p className="flex items-center gap-2 text-xs text-destructive">
                <AlertTriangle className="size-3.5" aria-hidden="true" />
                The reply failed to arrive.
              </p>
              <Button
                type="button"
                variant="outline"
                data-ocid="council.reply_retry_button"
                onClick={() => {
                  const text = message.trim();
                  if (text.length === 0 || activeRivalId === null) return;
                  setMessage("");
                  discuss.mutate(
                    { rivalId: activeRivalId, message: text },
                    {
                      onSuccess: (response) => setReply(response),
                      onError: () =>
                        setMessage((current) =>
                          current === "" ? text : current,
                        ),
                    },
                  );
                }}
                disabled={message.trim().length === 0}
                className="h-10 self-start rounded-sm border-border px-3 text-xs font-semibold uppercase tracking-widest"
              >
                <RefreshCw className="size-3.5" aria-hidden="true" />
                Retry
              </Button>
            </div>
          )}

          {reply && (
            <div
              data-ocid="council.reply"
              className="rounded-sm border border-accent/40 bg-accent/10 px-3 py-2"
            >
              <p className="font-mono text-[0.6rem] uppercase tracking-widest text-accent">
                {reply.speaker} · {rivalName(rivals, reply.nation)}
              </p>
              <p className="mt-1 text-sm leading-relaxed text-foreground">
                {reply.text}
              </p>
            </div>
          )}

          <div className="flex flex-col gap-1.5 border-t border-border/70 pt-2">
            <p className="font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
              Recent exchanges
            </p>
            {discussions.isLoading ? (
              <p
                data-ocid="council.discussions_loading"
                className="flex items-center gap-2 text-xs text-muted-foreground"
              >
                <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />
                Loading transcript…
              </p>
            ) : discussions.isError ? (
              <p
                data-ocid="council.discussions_error"
                className="text-xs text-destructive"
              >
                The discussion transcript could not be loaded.
              </p>
            ) : (discussions.data?.length ?? 0) === 0 ? (
              <p
                data-ocid="council.discussions_empty"
                className="text-xs text-muted-foreground"
              >
                No messages exchanged yet.
              </p>
            ) : (
              <ul className="flex max-h-56 flex-col gap-1.5 overflow-y-auto">
                {discussions.data?.slice(-6).map((entry, index) => (
                  <li
                    key={`${entry.nation}-${entry.tick}-${index}`}
                    className="rounded-sm border border-border/70 bg-background/50 px-2.5 py-1.5"
                  >
                    <p className="font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
                      {entry.speaker} · {rivalName(rivals, entry.nation)}
                    </p>
                    <p className="text-xs leading-relaxed text-foreground/90">
                      {entry.text}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </>
      )}
    </section>
  );
}

export default function CouncilScreen() {
  const proposals = useProposals();
  const rivals = useRivals();
  const rivalList = rivals.data ?? [];

  return (
    <ScreenShell
      eyebrow="Exterminate"
      title="World Council"
      description="Raise proposals, watch the vote, and read the resolutions that shape the world."
    >
      <div className="flex flex-col gap-4">
        <ProposalComposer />

        <section
          data-ocid="council.proposals_panel"
          className="flex flex-col gap-2"
        >
          <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
            Open Proposals
          </h2>

          {proposals.isLoading ? (
            <div
              data-ocid="council.proposals_loading"
              className="flex flex-col gap-2"
            >
              {Array.from(
                { length: 3 },
                (_, i) => `proposal-skeleton-${i}`,
              ).map((id) => (
                <div
                  key={id}
                  className="h-28 animate-pulse rounded-md border border-border bg-card"
                />
              ))}
            </div>
          ) : proposals.isError ? (
            <p
              data-ocid="council.proposals_error"
              className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive"
            >
              Proposals could not be loaded. Try again in a moment.
            </p>
          ) : (proposals.data?.length ?? 0) === 0 ? (
            <p
              data-ocid="council.proposals_empty"
              className="rounded-md border border-border bg-card p-4 text-sm text-muted-foreground shadow-subtle"
            >
              The floor is quiet. Raise the first proposal above to open debate.
            </p>
          ) : (
            <ul className="flex flex-col gap-2">
              {proposals.data?.map((proposal) => (
                <ProposalCard
                  key={proposal.id}
                  proposal={proposal}
                  rivals={rivalList}
                />
              ))}
            </ul>
          )}
        </section>

        <ResolutionsPanel />

        <DiscussionPanel rivals={rivalList} />
      </div>
    </ScreenShell>
  );
}
