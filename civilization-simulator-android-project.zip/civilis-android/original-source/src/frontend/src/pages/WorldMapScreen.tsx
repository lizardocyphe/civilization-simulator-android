import { ScreenShell } from "@/components/ScreenShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  useFoundSettlement,
  useMap,
  useRevealAround,
  useSettlements,
  useUnits,
} from "@/hooks/useQueries";
import {
  RESOURCE_ICONS,
  RESOURCE_LABELS,
  RESOURCE_ORDER,
  formatNumber,
  pocketIcon,
  pocketLabel,
  terrainLabel,
  terrainYield,
} from "@/lib/game";
import {
  FogState,
  type HexCoord,
  type ResourcePool,
  type Settlement,
  type Tile,
  type Unit,
} from "@/types";
import {
  AlertTriangle,
  Compass,
  Eye,
  Flag,
  Loader2,
  MapPin,
} from "lucide-react";
import { useMemo, useState } from "react";

/* ------------------------------------------------------------------ */
/* Hex geometry — flat-top hexes in axial coordinates                  */
/* ------------------------------------------------------------------ */

const HEX_SIZE = 30;
const HEX_WIDTH = HEX_SIZE * 2;
const HEX_HEIGHT = Math.sqrt(3) * HEX_SIZE;
const COL_STEP = HEX_WIDTH * 0.75;
const ROW_STEP = HEX_HEIGHT;

function hexCenter(coord: HexCoord): { x: number; y: number } {
  const q = Number(coord.q);
  const r = Number(coord.r);
  return {
    x: HEX_SIZE + q * COL_STEP,
    y: HEX_SIZE + (r + q / 2) * ROW_STEP,
  };
}

function hexPoints(cx: number, cy: number): string {
  const points: string[] = [];
  for (let i = 0; i < 6; i += 1) {
    const angle = (Math.PI / 180) * (60 * i);
    points.push(
      `${(cx + HEX_SIZE * Math.cos(angle)).toFixed(2)},${(
        cy + HEX_SIZE * Math.sin(angle)
      ).toFixed(2)}`,
    );
  }
  return points.join(" ");
}

/* ------------------------------------------------------------------ */
/* Terrain palette — semantic tokens, no raw palette classes           */
/* ------------------------------------------------------------------ */

const TERRAIN_FILL: Record<string, string> = {
  ocean: "oklch(0.42 0.09 235)",
  coast: "oklch(0.55 0.09 220)",
  reef: "oklch(0.6 0.11 195)",
  grassland: "oklch(0.62 0.13 140)",
  plains: "oklch(0.68 0.12 120)",
  savanna: "oklch(0.72 0.12 95)",
  desert: "oklch(0.78 0.11 85)",
  mesa: "oklch(0.68 0.1 60)",
  hills: "oklch(0.6 0.08 90)",
  mountains: "oklch(0.55 0.03 250)",
  forest: "oklch(0.5 0.11 150)",
  jungle: "oklch(0.48 0.13 155)",
  wetlands: "oklch(0.56 0.09 175)",
  tundra: "oklch(0.72 0.03 200)",
  ice: "oklch(0.88 0.02 220)",
  volcanic: "oklch(0.45 0.13 35)",
};

function terrainFill(terrain: Tile["terrain"]): string {
  return TERRAIN_FILL[terrain] ?? "oklch(0.5 0.02 200)";
}

/* ------------------------------------------------------------------ */
/* Small presentational pieces                                         */
/* ------------------------------------------------------------------ */

function YieldRow({ yields }: { yields: Partial<ResourcePool> }) {
  const entries = RESOURCE_ORDER.filter((key) => (yields[key] ?? 0n) > 0n);
  if (entries.length === 0) {
    return <span className="text-xs text-muted-foreground">No yield</span>;
  }
  return (
    <div className="flex flex-wrap gap-1.5">
      {entries.map((key) => (
        <span
          key={key}
          className="inline-flex items-center gap-1 rounded-sm border border-border bg-background/60 px-1.5 py-0.5 font-mono text-xs tabular-nums text-foreground"
        >
          <span aria-hidden="true">{RESOURCE_ICONS[key]}</span>
          <span className="sr-only">{RESOURCE_LABELS[key]}</span>
          {formatNumber(yields[key] ?? 0n)}
        </span>
      ))}
    </div>
  );
}

function StatCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-sm border border-border bg-background/50 px-2 py-1.5">
      <p className="font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
        {label}
      </p>
      <p className="font-mono text-sm font-semibold tabular-nums text-foreground">
        {value}
      </p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Screen                                                              */
/* ------------------------------------------------------------------ */

export default function WorldMapScreen() {
  const mapQuery = useMap();
  const unitsQuery = useUnits();
  const settlementsQuery = useSettlements();
  const revealAround = useRevealAround();
  const foundSettlement = useFoundSettlement();

  const [selected, setSelected] = useState<HexCoord | null>(null);
  const [selectedUnitId, setSelectedUnitId] = useState<bigint | null>(null);
  const [feedback, setFeedback] = useState<{
    tone: "success" | "error";
    message: string;
  } | null>(null);

  const map = mapQuery.data ?? null;
  const units = unitsQuery.data ?? [];
  const settlements = settlementsQuery.data ?? [];

  const tiles = map?.tiles ?? [];

  const selectedTile = useMemo(() => {
    if (!selected) return null;
    return (
      tiles.find(
        (tile) => tile.coord.q === selected.q && tile.coord.r === selected.r,
      ) ?? null
    );
  }, [tiles, selected]);

  const selectedUnit = useMemo(
    () => units.find((unit) => unit.id === selectedUnitId) ?? null,
    [units, selectedUnitId],
  );

  const playerPosition = useMemo<HexCoord | null>(() => {
    const playerSettlement = settlements.find((s) => s.owner === 1n);
    if (playerSettlement) return playerSettlement.position;
    const playerUnit = units.find((u) => u.owner === 1n);
    if (playerUnit) return playerUnit.position;
    return null;
  }, [settlements, units]);

  const bounds = useMemo(() => {
    if (tiles.length === 0) return { width: 0, height: 0 };
    let maxX = 0;
    let maxY = 0;
    for (const tile of tiles) {
      const { x, y } = hexCenter(tile.coord);
      maxX = Math.max(maxX, x + HEX_SIZE);
      maxY = Math.max(maxY, y + HEX_SIZE);
    }
    return { width: maxX, height: maxY };
  }, [tiles]);

  const unitsByTile = useMemo(() => {
    const index = new Map<string, Unit[]>();
    for (const unit of units) {
      const key = `${unit.position.q},${unit.position.r}`;
      const list = index.get(key);
      if (list) list.push(unit);
      else index.set(key, [unit]);
    }
    return index;
  }, [units]);

  const settlementsByTile = useMemo(() => {
    const index = new Map<string, Settlement>();
    for (const settlement of settlements) {
      index.set(
        `${settlement.position.q},${settlement.position.r}`,
        settlement,
      );
    }
    return index;
  }, [settlements]);

  function handleSelectTile(tile: Tile) {
    setSelected(tile.coord);
    setFeedback(null);
  }

  function handleReveal() {
    if (!playerPosition) {
      setFeedback({
        tone: "error",
        message: "No position to reveal from — found a settlement first.",
      });
      return;
    }
    revealAround.mutate(
      { coord: playerPosition, radius: 2n },
      {
        onSuccess: () =>
          setFeedback({
            tone: "success",
            message: "Scouts revealed the terrain around your position.",
          }),
        onError: () =>
          setFeedback({
            tone: "error",
            message: "Reveal failed. The terrain could not be surveyed.",
          }),
      },
    );
  }

  function handleFoundSettlement() {
    if (!selectedTile) {
      setFeedback({
        tone: "error",
        message: "Select a tile on the map before founding a settlement.",
      });
      return;
    }
    if (selectedTile.fog === FogState.unexplored) {
      setFeedback({
        tone: "error",
        message: "That tile is still under fog — reveal it before settling.",
      });
      return;
    }
    if (selectedTile.terrain === "ocean" || selectedTile.terrain === "coast") {
      setFeedback({
        tone: "error",
        message: "Settlements cannot be founded on water.",
      });
      return;
    }
    if (
      settlementsByTile.has(`${selectedTile.coord.q},${selectedTile.coord.r}`)
    ) {
      setFeedback({
        tone: "error",
        message: "A settlement already stands on that tile.",
      });
      return;
    }
    foundSettlement.mutate(
      {
        name: `Outpost ${settlements.length + 1}`,
        position: selectedTile.coord,
      },
      {
        onSuccess: () =>
          setFeedback({
            tone: "success",
            message: "Settlement founded. Your borders expand.",
          }),
        onError: () =>
          setFeedback({
            tone: "error",
            message: "Founding failed. The tile may be claimed or invalid.",
          }),
      },
    );
  }

  const isLoading = mapQuery.isLoading || unitsQuery.isLoading;
  const isError = mapQuery.isError || unitsQuery.isError;

  return (
    <ScreenShell
      eyebrow="Explore"
      title="World Map"
      description="Survey the hex terrain, reveal fog of war, and select tiles to inspect."
    >
      {isLoading && (
        <div
          data-ocid="map.loading_state"
          className="flex min-h-[40vh] flex-col items-center justify-center gap-3 rounded-md border border-border bg-card text-muted-foreground shadow-subtle"
        >
          <Loader2 className="size-6 animate-spin" aria-hidden="true" />
          <p className="text-sm">Surveying the world…</p>
        </div>
      )}

      {isError && !isLoading && (
        <div
          data-ocid="map.error_state"
          className="flex min-h-[40vh] flex-col items-center justify-center gap-3 rounded-md border border-destructive/50 bg-card p-6 text-center shadow-subtle"
        >
          <AlertTriangle
            className="size-6 text-destructive"
            aria-hidden="true"
          />
          <p className="text-sm text-foreground">
            The world map could not be loaded.
          </p>
          <Button
            type="button"
            variant="outline"
            data-ocid="map.retry_button"
            onClick={() => void mapQuery.refetch()}
            className="h-11 rounded-md"
          >
            Retry
          </Button>
        </div>
      )}

      {!isLoading && !isError && tiles.length === 0 && (
        <div
          data-ocid="map.empty_state"
          className="flex min-h-[40vh] flex-col items-center justify-center gap-3 rounded-md border border-border bg-card p-6 text-center shadow-subtle"
        >
          <Compass
            className="size-6 text-muted-foreground"
            aria-hidden="true"
          />
          <p className="text-sm text-foreground">
            No world has been generated.
          </p>
          <p className="text-xs text-muted-foreground">
            Start a game to generate the hex terrain.
          </p>
        </div>
      )}

      {!isLoading && !isError && tiles.length > 0 && (
        <>
          <div
            data-ocid="map.canvas"
            className="map-grid overflow-x-auto rounded-md border border-border bg-card p-2 shadow-subtle"
          >
            <svg
              role="img"
              aria-label="Hex world map"
              viewBox={`0 0 ${bounds.width} ${bounds.height}`}
              className="mx-auto block h-auto w-full min-w-[320px] max-w-[640px]"
            >
              {tiles.map((tile) => {
                const { x, y } = hexCenter(tile.coord);
                const key = `${tile.coord.q},${tile.coord.r}`;
                const isSelected =
                  selected?.q === tile.coord.q && selected?.r === tile.coord.r;
                const unexplored = tile.fog === FogState.unexplored;
                const tileUnits = unitsByTile.get(key) ?? [];
                const settlement = settlementsByTile.get(key);
                const fill = unexplored
                  ? "oklch(0.22 0.01 200)"
                  : terrainFill(tile.terrain);
                return (
                  <g key={key}>
                    <polygon
                      points={hexPoints(x, y)}
                      fill={fill}
                      stroke={
                        isSelected
                          ? "oklch(0.78 0.14 78)"
                          : "oklch(0.31 0.024 200)"
                      }
                      strokeWidth={isSelected ? 3 : 1}
                      opacity={unexplored ? 0.85 : 1}
                    />
                    {tile.owner !== undefined && !unexplored && (
                      <polygon
                        points={hexPoints(x, y)}
                        fill="none"
                        stroke="oklch(0.7 0.13 175)"
                        strokeWidth={2}
                        strokeDasharray="4 3"
                      />
                    )}
                    {tile.pocket && !unexplored && (
                      <text x={x} y={y - 4} textAnchor="middle" fontSize="13">
                        {pocketIcon(tile.pocket.kind)}
                      </text>
                    )}
                    {settlement && !unexplored && (
                      <text x={x} y={y + 12} textAnchor="middle" fontSize="13">
                        🏛️
                      </text>
                    )}
                    {tileUnits.length > 0 && !unexplored && (
                      <text x={x} y={y + 12} textAnchor="middle" fontSize="12">
                        ⚔️
                      </text>
                    )}
                    <polygon
                      points={hexPoints(x, y)}
                      fill="transparent"
                      className="cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary"
                      // biome-ignore lint/a11y/useSemanticElements: SVG polygon cannot be a <button>; role + tabIndex + key handler provide the equivalent interaction
                      role="button"
                      tabIndex={0}
                      aria-label={`${terrainLabel(tile.terrain)} tile at ${tile.coord.q}, ${tile.coord.r}`}
                      onClick={() => handleSelectTile(tile)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter" || event.key === " ") {
                          event.preventDefault();
                          handleSelectTile(tile);
                        }
                      }}
                    >
                      <title>{`${terrainLabel(tile.terrain)} (${tile.coord.q}, ${tile.coord.r})`}</title>
                    </polygon>
                  </g>
                );
              })}
            </svg>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              data-ocid="map.reveal_button"
              onClick={handleReveal}
              disabled={revealAround.isPending}
              className="h-11 flex-1 rounded-md bg-primary font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110"
            >
              <Eye className="size-4" aria-hidden="true" />
              {revealAround.isPending ? "Revealing…" : "Reveal Around"}
            </Button>
            <Button
              type="button"
              variant="outline"
              data-ocid="map.found_button"
              onClick={handleFoundSettlement}
              disabled={foundSettlement.isPending}
              className="h-11 flex-1 rounded-md font-display text-sm font-semibold uppercase tracking-widest"
            >
              <Flag className="size-4" aria-hidden="true" />
              {foundSettlement.isPending ? "Founding…" : "Found Settlement"}
            </Button>
          </div>

          {feedback && (
            <output
              data-ocid={
                feedback.tone === "success"
                  ? "map.success_state"
                  : "map.error_state"
              }
              className={`block rounded-md border px-3 py-2 text-sm ${
                feedback.tone === "success"
                  ? "border-success/50 bg-success/10 text-foreground"
                  : "border-destructive/50 bg-destructive/10 text-foreground"
              }`}
            >
              {feedback.message}
            </output>
          )}

          {/* Selected tile inspector */}
          <section
            data-ocid="map.tile_panel"
            className="rounded-md border border-border bg-card p-3 shadow-subtle"
          >
            <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-accent">
              Tile Inspector
            </h2>
            {selectedTile ? (
              <div className="mt-2 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-display text-lg font-bold text-foreground">
                    {terrainLabel(selectedTile.terrain)}
                  </p>
                  <Badge
                    variant="outline"
                    className="font-mono text-xs tabular-nums"
                  >
                    ({selectedTile.coord.q.toString()},{" "}
                    {selectedTile.coord.r.toString()})
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <StatCell
                    label="Fog"
                    value={
                      selectedTile.fog === FogState.visible
                        ? "Visible"
                        : selectedTile.fog === FogState.explored
                          ? "Explored"
                          : "Unexplored"
                    }
                  />
                  <StatCell
                    label="Owner"
                    value={
                      selectedTile.owner !== undefined
                        ? `Nation ${selectedTile.owner.toString()}`
                        : "Unclaimed"
                    }
                  />
                </div>
                <div>
                  <p className="font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground">
                    Yields
                  </p>
                  <div className="mt-1">
                    <YieldRow yields={terrainYield(selectedTile.terrain)} />
                  </div>
                </div>
                {selectedTile.pocket ? (
                  <div className="rounded-sm border border-accent/40 bg-accent/10 p-2">
                    <p className="flex items-center gap-1.5 font-display text-sm font-semibold text-foreground">
                      <span aria-hidden="true">
                        {pocketIcon(selectedTile.pocket.kind)}
                      </span>
                      {pocketLabel(selectedTile.pocket.kind)}
                    </p>
                    <div className="mt-2 grid grid-cols-3 gap-2">
                      <StatCell
                        label="Remaining"
                        value={formatNumber(selectedTile.pocket.remaining)}
                      />
                      <StatCell
                        label="Initial"
                        value={formatNumber(selectedTile.pocket.initial)}
                      />
                      <StatCell
                        label="Renewal"
                        value={
                          selectedTile.pocket.renewable
                            ? `+${formatNumber(selectedTile.pocket.renewalRate)}`
                            : "None"
                        }
                      />
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground">
                    No resource pocket on this tile.
                  </p>
                )}
              </div>
            ) : (
              <p
                data-ocid="map.tile_panel.empty_state"
                className="mt-2 text-sm text-muted-foreground"
              >
                Tap a hex to inspect its terrain, resources and ownership.
              </p>
            )}
          </section>

          {/* Units */}
          <section
            data-ocid="map.units_panel"
            className="rounded-md border border-border bg-card p-3 shadow-subtle"
          >
            <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-accent">
              Your Units
            </h2>
            {units.length === 0 ? (
              <p
                data-ocid="map.units_panel.empty_state"
                className="mt-2 text-sm text-muted-foreground"
              >
                No units in the field. Recruit forces to explore and defend.
              </p>
            ) : (
              <ul className="mt-2 space-y-1.5">
                {units.map((unit, index) => {
                  const active = unit.id === selectedUnitId;
                  return (
                    <li key={unit.id.toString()}>
                      <button
                        type="button"
                        data-ocid={`map.unit.${index + 1}`}
                        aria-pressed={active}
                        onClick={() => setSelectedUnitId(unit.id)}
                        className={`flex w-full items-center justify-between gap-2 rounded-md border px-3 py-2 text-left transition-smooth ${
                          active
                            ? "border-accent/60 bg-accent/15"
                            : "border-border bg-background/50 hover:bg-secondary"
                        }`}
                      >
                        <span className="flex min-w-0 items-center gap-2">
                          <MapPin
                            className="size-4 shrink-0 text-muted-foreground"
                            aria-hidden="true"
                          />
                          <span className="truncate font-display text-sm font-semibold text-foreground">
                            {unit.kind}
                          </span>
                        </span>
                        <span className="shrink-0 font-mono text-xs tabular-nums text-muted-foreground">
                          STR {formatNumber(unit.strength)} · (
                          {unit.position.q.toString()},{" "}
                          {unit.position.r.toString()})
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
            {selectedUnit && (
              <div
                data-ocid="map.unit_detail"
                className="mt-3 grid grid-cols-3 gap-2"
              >
                <StatCell label="Kind" value={selectedUnit.kind} />
                <StatCell
                  label="Strength"
                  value={formatNumber(selectedUnit.strength)}
                />
                <StatCell
                  label="Movement"
                  value={formatNumber(selectedUnit.movement)}
                />
              </div>
            )}
          </section>

          {playerPosition && (
            <p className="text-center font-mono text-xs text-muted-foreground">
              Home position ({playerPosition.q.toString()},{" "}
              {playerPosition.r.toString()}) ·{" "}
              {settlements.length > 0
                ? `${settlements.length} settlement${settlements.length === 1 ? "" : "s"}`
                : "no settlements yet"}
            </p>
          )}
        </>
      )}
    </ScreenShell>
  );
}
