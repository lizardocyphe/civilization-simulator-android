import { ScreenShell } from "@/components/ScreenShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Slider } from "@/components/ui/slider";
import {
  useAdvanceEconomy,
  useApplyEconomicPolicy,
  useEconomicPolicies,
  useEconomy,
  useEconomyHistory,
  useScaledCost,
} from "@/hooks/useQueries";
import {
  formatInflation,
  formatNumber,
  formatPriceDelta,
  formatPriceLevel,
  inflationTone,
} from "@/lib/game";
import type { EconomicPolicy, EconomyState, EconomyTick } from "@/types";
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  Banknote,
  Coins,
  Landmark,
  Minus,
  RefreshCw,
  Scale,
  TrendingUp,
  Wallet,
} from "lucide-react";
import { useMemo, useState } from "react";

/* ------------------------------------------------------------------ */
/* Formatting helpers                                                  */
/* ------------------------------------------------------------------ */

/** Signed treasury flow, e.g. `+120` / `-45`. */
function formatFlow(value: bigint): string {
  if (value > 0n) return `+${formatNumber(value)}`;
  return formatNumber(value);
}

function flowTone(value: bigint): "positive" | "negative" | "neutral" {
  if (value > 0n) return "positive";
  if (value < 0n) return "negative";
  return "neutral";
}

const TONE_TEXT: Record<"positive" | "negative" | "neutral", string> = {
  positive: "text-success",
  negative: "text-destructive",
  neutral: "text-muted-foreground",
};

/** Inflation/deflation tone mapped to the economy palette tokens. */
function inflationTextClass(rate: number): string {
  const tone = inflationTone(rate);
  if (tone === "inflation") return "text-inflation";
  if (tone === "deflation") return "text-deflation";
  return "text-muted-foreground";
}

function inflationBadgeClass(rate: number): string {
  const tone = inflationTone(rate);
  if (tone === "inflation")
    return "border-inflation/50 bg-inflation/15 text-inflation";
  if (tone === "deflation")
    return "border-deflation/50 bg-deflation/15 text-deflation";
  return "border-border bg-secondary text-muted-foreground";
}

function inflationLabel(rate: number): string {
  const tone = inflationTone(rate);
  if (tone === "inflation") return "Inflation";
  if (tone === "deflation") return "Deflation";
  return "Stable";
}

/* ------------------------------------------------------------------ */
/* Indicator tiles                                                     */
/* ------------------------------------------------------------------ */

interface Indicator {
  key: string;
  label: string;
  value: string;
  hint: string;
  icon: typeof Coins;
  valueClass: string;
}

function buildIndicators(economy: EconomyState): Indicator[] {
  const net = economy.income - economy.upkeep;
  return [
    {
      key: "inflation",
      label: "Inflation Rate",
      value: formatInflation(economy.inflationRate),
      hint: inflationLabel(economy.inflationRate),
      icon: TrendingUp,
      valueClass: inflationTextClass(economy.inflationRate),
    },
    {
      key: "price",
      label: "Price Index",
      value: formatPriceLevel(economy.priceLevel),
      hint: "Base 100.0",
      icon: Scale,
      valueClass: "text-foreground",
    },
    {
      key: "money",
      label: "Money Supply",
      value: formatNumber(economy.moneySupply),
      hint: "Total minted",
      icon: Banknote,
      valueClass: "text-foreground",
    },
    {
      key: "income",
      label: "Income",
      value: formatFlow(economy.income),
      hint: "Per tick",
      icon: Coins,
      valueClass: TONE_TEXT[flowTone(economy.income)],
    },
    {
      key: "upkeep",
      label: "Upkeep",
      value: formatFlow(-economy.upkeep),
      hint: "Per tick",
      icon: Landmark,
      valueClass: TONE_TEXT[flowTone(-economy.upkeep)],
    },
    {
      key: "net",
      label: "Net Treasury",
      value: formatFlow(net),
      hint: net >= 0n ? "Surplus" : "Deficit",
      icon: Wallet,
      valueClass: TONE_TEXT[flowTone(net)],
    },
  ];
}

function IndicatorTile({ indicator }: { indicator: Indicator }) {
  const Icon = indicator.icon;
  return (
    <div
      data-ocid={`economy.indicator.${indicator.key}`}
      className="flex flex-col gap-1 rounded-md border border-border bg-background/60 p-3"
    >
      <span className="flex items-center gap-1.5 text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground">
        <Icon className="size-3.5" aria-hidden="true" />
        {indicator.label}
      </span>
      <span
        className={`font-mono text-xl font-semibold tabular-nums ${indicator.valueClass}`}
      >
        {indicator.value}
      </span>
      <span className="text-[0.65rem] text-muted-foreground">
        {indicator.hint}
      </span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Trend sparkline                                                     */
/* ------------------------------------------------------------------ */

function TrendChart({ history }: { history: EconomyTick[] }) {
  const points = useMemo(() => history.slice(-24), [history]);

  const geometry = useMemo(() => {
    if (points.length < 2) return null;
    const width = 300;
    const height = 96;
    const pad = 6;
    const levels = points.map((tick) => tick.priceLevel);
    const min = Math.min(...levels);
    const max = Math.max(...levels);
    const span = max - min || 1;
    const stepX = (width - pad * 2) / (points.length - 1);
    const coords = points.map((tick, index) => {
      const x = pad + index * stepX;
      const y = pad + (height - pad * 2) * (1 - (tick.priceLevel - min) / span);
      return { x, y };
    });
    const line = coords
      .map((point, index) => `${index === 0 ? "M" : "L"}${point.x},${point.y}`)
      .join(" ");
    const area = `${line} L${coords[coords.length - 1].x},${height - pad} L${
      coords[0].x
    },${height - pad} Z`;
    return { width, height, line, area, coords };
  }, [points]);

  if (!geometry) {
    return (
      <p
        data-ocid="economy.trend.empty_state"
        className="py-6 text-center text-xs text-muted-foreground"
      >
        Advance the economy to plot a price trend.
      </p>
    );
  }

  const first = points[0];
  const last = points[points.length - 1];
  const delta = last.priceLevel - first.priceLevel;

  return (
    <div data-ocid="economy.trend.chart" className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
          Price index · last {points.length} ticks
        </span>
        <span
          className={`flex items-center gap-1 font-mono text-xs font-semibold tabular-nums ${inflationTextClass(
            delta,
          )}`}
        >
          {delta > 0 ? (
            <ArrowUpRight className="size-3.5" aria-hidden="true" />
          ) : delta < 0 ? (
            <ArrowDownRight className="size-3.5" aria-hidden="true" />
          ) : (
            <Minus className="size-3.5" aria-hidden="true" />
          )}
          {formatPriceDelta(delta)}
        </span>
      </div>
      <svg
        viewBox={`0 0 ${geometry.width} ${geometry.height}`}
        role="img"
        aria-label={`Price index trend across ${points.length} ticks, from ${formatPriceLevel(
          first.priceLevel,
        )} to ${formatPriceLevel(last.priceLevel)}`}
        className="h-24 w-full"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id="economy-trend-fill" x1="0" y1="0" x2="0" y2="1">
            <stop
              offset="0%"
              stopColor="oklch(var(--accent))"
              stopOpacity="0.35"
            />
            <stop
              offset="100%"
              stopColor="oklch(var(--accent))"
              stopOpacity="0"
            />
          </linearGradient>
        </defs>
        <path d={geometry.area} fill="url(#economy-trend-fill)" />
        <path
          d={geometry.line}
          fill="none"
          stroke="oklch(var(--accent))"
          strokeWidth="2"
          strokeLinejoin="round"
          strokeLinecap="round"
        />
        <circle
          cx={geometry.coords[geometry.coords.length - 1].x}
          cy={geometry.coords[geometry.coords.length - 1].y}
          r="3"
          fill="oklch(var(--accent))"
        />
      </svg>
      <div className="flex items-center justify-between font-mono text-[0.65rem] tabular-nums text-muted-foreground">
        <span>Tick {formatNumber(first.tick)}</span>
        <span>Tick {formatNumber(last.tick)}</span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Real cost panel                                                     */
/* ------------------------------------------------------------------ */

function RealCostPanel({
  economy,
  baseCost,
}: {
  economy: EconomyState;
  baseCost: bigint | null | undefined;
}) {
  const base = baseCost ?? 100n;
  const scaled = (base * BigInt(Math.round(economy.priceLevel))) / 100n;
  const premium = scaled - base;

  const rows = [
    { key: "building", label: "Building", base },
    { key: "unit", label: "Unit", base: base * 2n },
    { key: "upkeep", label: "Upkeep / tick", base: economy.upkeep },
  ];

  return (
    <Card
      data-ocid="economy.real_cost.panel"
      className="gap-3 rounded-lg border-border bg-card py-4 shadow-none"
    >
      <CardHeader className="px-4">
        <CardTitle className="flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          <Scale className="size-4 text-accent" aria-hidden="true" />
          Real Cost of Purchases
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          At a price index of {formatPriceLevel(economy.priceLevel)}, nominal
          costs scale with inflation.
        </p>
      </CardHeader>
      <CardContent className="flex flex-col gap-2 px-4">
        {rows.map((row) => {
          const rowScaled =
            (row.base * BigInt(Math.round(economy.priceLevel))) / 100n;
          const rowPremium = rowScaled - row.base;
          return (
            <div
              key={row.key}
              data-ocid={`economy.real_cost.${row.key}`}
              className="flex items-center justify-between gap-3 rounded-md border border-border bg-background/60 px-3 py-2"
            >
              <span className="text-sm text-foreground">{row.label}</span>
              <span className="flex items-baseline gap-2 font-mono text-sm tabular-nums">
                <span className="text-muted-foreground line-through">
                  {formatNumber(row.base)}
                </span>
                <span className="font-semibold text-foreground">
                  {formatNumber(rowScaled)}
                </span>
                <span className={`text-xs ${TONE_TEXT[flowTone(rowPremium)]}`}>
                  {formatFlow(rowPremium)}
                </span>
              </span>
            </div>
          );
        })}
        <p className="text-[0.65rem] text-muted-foreground">
          A {formatInflation(economy.inflationRate)} inflation rate adds{" "}
          {formatNumber(premium)} to a {formatNumber(base)} base purchase.
        </p>
      </CardContent>
    </Card>
  );
}

/* ------------------------------------------------------------------ */
/* Policy levers                                                       */
/* ------------------------------------------------------------------ */

interface Lever {
  key: "taxRate" | "interestRate" | "spending";
  label: string;
  min: number;
  max: number;
  step: number;
  format: (value: number) => string;
  hint: string;
}

const LEVERS: Lever[] = [
  {
    key: "taxRate",
    label: "Tax Rate",
    min: 0,
    max: 60,
    step: 1,
    format: (value) => `${value}%`,
    hint: "Higher taxes fund the treasury but cool growth.",
  },
  {
    key: "interestRate",
    label: "Interest Rate",
    min: 0,
    max: 20,
    step: 0.5,
    format: (value) => `${value.toFixed(1)}%`,
    hint: "Raising rates tames inflation and slows expansion.",
  },
  {
    key: "spending",
    label: "Spending",
    min: 0,
    max: 500,
    step: 10,
    format: (value) => formatNumber(BigInt(Math.round(value))),
    hint: "Public spending lifts growth and price pressure.",
  },
];

function PolicyLever({
  lever,
  value,
  onChange,
}: {
  lever: Lever;
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <div
      data-ocid={`economy.lever.${lever.key}`}
      className="flex flex-col gap-2 rounded-md border border-border bg-background/60 p-3"
    >
      <div className="flex items-center justify-between gap-2">
        <label
          htmlFor={`economy-lever-${lever.key}`}
          className="text-sm font-medium text-foreground"
        >
          {lever.label}
        </label>
        <span className="font-mono text-sm font-semibold tabular-nums text-primary">
          {lever.format(value)}
        </span>
      </div>
      <Slider
        id={`economy-lever-${lever.key}`}
        data-ocid={`economy.lever.${lever.key}.slider`}
        aria-label={lever.label}
        min={lever.min}
        max={lever.max}
        step={lever.step}
        value={[value]}
        onValueChange={(next) => onChange(next[0] ?? value)}
        className="py-2"
      />
      <p className="text-[0.65rem] text-muted-foreground">{lever.hint}</p>
    </div>
  );
}

function PolicyCard({
  policy,
  onApply,
  pending,
}: {
  policy: EconomicPolicy;
  onApply: (id: bigint) => void;
  pending: boolean;
}) {
  const effects = [
    policy.taxRateDelta !== 0 && {
      key: "tax",
      label: "Tax",
      value: `${policy.taxRateDelta > 0 ? "+" : ""}${policy.taxRateDelta}%`,
    },
    policy.interestRateDelta !== 0 && {
      key: "interest",
      label: "Interest",
      value: `${policy.interestRateDelta > 0 ? "+" : ""}${policy.interestRateDelta}%`,
    },
    policy.spendingDelta !== 0n && {
      key: "spending",
      label: "Spending",
      value: formatFlow(policy.spendingDelta),
    },
  ].filter(Boolean) as { key: string; label: string; value: string }[];

  return (
    <div
      data-ocid={`economy.policy.${policy.id.toString()}`}
      className="flex flex-col gap-2 rounded-md border border-border bg-background/60 p-3"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="font-display text-sm font-semibold text-foreground">
            {policy.name}
          </p>
          <p className="text-xs text-muted-foreground">{policy.description}</p>
        </div>
      </div>
      {effects.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {effects.map((effect) => (
            <Badge
              key={effect.key}
              variant="outline"
              className="border-border bg-secondary font-mono text-[0.65rem] tabular-nums text-muted-foreground"
            >
              {effect.label} {effect.value}
            </Badge>
          ))}
        </div>
      )}
      <Button
        type="button"
        data-ocid={`economy.policy.${policy.id.toString()}.apply_button`}
        onClick={() => onApply(policy.id)}
        disabled={pending}
        className="h-11 rounded-md bg-primary font-display text-xs font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110"
      >
        {pending ? "Applying…" : "Apply Policy"}
      </Button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* States                                                              */
/* ------------------------------------------------------------------ */

function EconomySkeleton() {
  const ids = Array.from(
    { length: 6 },
    (_, index) => `economy-skeleton-${index}`,
  );
  return (
    <div
      data-ocid="economy.loading_state"
      className="grid grid-cols-2 gap-2 sm:grid-cols-3"
    >
      {ids.map((id) => (
        <Skeleton key={id} className="h-24 rounded-md" />
      ))}
    </div>
  );
}

function EconomyEmpty() {
  return (
    <div
      data-ocid="economy.empty_state"
      className="flex flex-col items-center gap-3 rounded-md border border-dashed border-border bg-card p-6 text-center"
    >
      <Landmark className="size-8 text-muted-foreground" aria-hidden="true" />
      <div className="space-y-1">
        <p className="font-display text-sm font-semibold text-foreground">
          No economy running yet
        </p>
        <p className="text-xs text-muted-foreground">
          Start a game to open your treasury, then advance the economy to track
          inflation and prices.
        </p>
      </div>
    </div>
  );
}

function EconomyError({ onRetry }: { onRetry: () => void }) {
  return (
    <div
      data-ocid="economy.error_state"
      className="flex flex-col items-center gap-3 rounded-md border border-destructive/40 bg-destructive/10 p-6 text-center"
    >
      <AlertTriangle className="size-8 text-destructive" aria-hidden="true" />
      <div className="space-y-1">
        <p className="font-display text-sm font-semibold text-foreground">
          Could not load the economy
        </p>
        <p className="text-xs text-muted-foreground">
          The treasury feed is unavailable. Check your connection and try again.
        </p>
      </div>
      <Button
        type="button"
        variant="outline"
        data-ocid="economy.retry_button"
        onClick={onRetry}
        className="h-11 rounded-md border-border px-4 font-display text-xs font-semibold uppercase tracking-widest"
      >
        <RefreshCw className="size-4" aria-hidden="true" />
        Retry
      </Button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Screen                                                              */
/* ------------------------------------------------------------------ */

export default function EconomyScreen() {
  const economyQuery = useEconomy();
  const historyQuery = useEconomyHistory();
  const policiesQuery = useEconomicPolicies();
  const scaledCostQuery = useScaledCost();
  const applyPolicy = useApplyEconomicPolicy();
  const advanceEconomy = useAdvanceEconomy();

  const economy = economyQuery.data ?? null;
  const history = historyQuery.data ?? [];
  const policies = policiesQuery.data ?? [];

  const [draft, setDraft] = useState({
    taxRate: 20,
    interestRate: 5,
    spending: 100,
  });

  const isLoading =
    economyQuery.isLoading || historyQuery.isLoading || policiesQuery.isLoading;
  const isError = economyQuery.isError || historyQuery.isError;

  const net = economy ? economy.income - economy.upkeep : 0n;

  return (
    <ScreenShell
      eyebrow="Exploit"
      title="Economy"
      description="Track inflation, the price index, treasury flows and adopt fiscal and monetary policy."
    >
      <div className="flex flex-col gap-4">
        {isLoading && <EconomySkeleton />}

        {!isLoading && isError && (
          <EconomyError
            onRetry={() => {
              void economyQuery.refetch();
              void historyQuery.refetch();
            }}
          />
        )}

        {!isLoading && !isError && !economy && <EconomyEmpty />}

        {!isLoading && !isError && economy && (
          <>
            {/* Headline status */}
            <div className="flex flex-wrap items-center gap-2">
              <Badge
                variant="outline"
                data-ocid="economy.status_badge"
                className={`font-mono text-xs tabular-nums ${inflationBadgeClass(
                  economy.inflationRate,
                )}`}
              >
                {inflationLabel(economy.inflationRate)}{" "}
                {formatInflation(economy.inflationRate)}
              </Badge>
              <Badge
                variant="outline"
                className="border-border bg-secondary font-mono text-xs tabular-nums text-muted-foreground"
              >
                Tax {economy.taxRate.toFixed(0)}% · Interest{" "}
                {economy.interestRate.toFixed(1)}%
              </Badge>
              <Badge
                variant="outline"
                className={`border-border bg-secondary font-mono text-xs tabular-nums ${TONE_TEXT[flowTone(net)]}`}
              >
                Net {formatFlow(net)} / tick
              </Badge>
            </div>

            {/* Indicators */}
            <section
              data-ocid="economy.indicators.section"
              aria-label="Economic indicators"
              className="grid grid-cols-2 gap-2 sm:grid-cols-3"
            >
              {buildIndicators(economy).map((indicator) => (
                <IndicatorTile key={indicator.key} indicator={indicator} />
              ))}
            </section>

            {/* Trend */}
            <Card
              data-ocid="economy.trend.panel"
              className="gap-3 rounded-lg border-border bg-card py-4 shadow-none"
            >
              <CardHeader className="px-4">
                <CardTitle className="flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-widest text-foreground">
                  <TrendingUp
                    className="size-4 text-accent"
                    aria-hidden="true"
                  />
                  Price Trend
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4">
                <TrendChart history={history} />
              </CardContent>
            </Card>

            {/* Real cost */}
            <RealCostPanel economy={economy} baseCost={scaledCostQuery.data} />

            {/* Policy levers */}
            <Card
              data-ocid="economy.levers.panel"
              className="gap-3 rounded-lg border-border bg-card py-4 shadow-none"
            >
              <CardHeader className="px-4">
                <CardTitle className="flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-widest text-foreground">
                  <Scale className="size-4 text-accent" aria-hidden="true" />
                  Policy Levers
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                  Set your fiscal and monetary stance, then apply a policy to
                  commit the trade-off between growth, inflation and stability.
                </p>
              </CardHeader>
              <CardContent className="flex flex-col gap-3 px-4">
                {LEVERS.map((lever) => (
                  <PolicyLever
                    key={lever.key}
                    lever={lever}
                    value={draft[lever.key]}
                    onChange={(value) =>
                      setDraft((current) => ({
                        ...current,
                        [lever.key]: value,
                      }))
                    }
                  />
                ))}
                <div className="flex flex-col gap-2 rounded-md border border-border bg-background/60 p-3">
                  <p className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
                    Projected trade-off
                  </p>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                      <p className="font-mono text-sm font-semibold tabular-nums text-success">
                        {formatFlow(
                          BigInt(Math.round(draft.taxRate * 4)) -
                            BigInt(Math.round(draft.spending)),
                        )}
                      </p>
                      <p className="text-[0.6rem] uppercase tracking-widest text-muted-foreground">
                        Net
                      </p>
                    </div>
                    <div>
                      <p className="font-mono text-sm font-semibold tabular-nums text-inflation">
                        {formatInflation(
                          economy.inflationRate +
                            draft.spending / 100 -
                            draft.interestRate / 10,
                        )}
                      </p>
                      <p className="text-[0.6rem] uppercase tracking-widest text-muted-foreground">
                        Inflation
                      </p>
                    </div>
                    <div>
                      <p className="font-mono text-sm font-semibold tabular-nums text-accent">
                        {formatNumber(
                          BigInt(
                            Math.round(draft.taxRate + draft.spending / 5),
                          ),
                        )}
                      </p>
                      <p className="text-[0.6rem] uppercase tracking-widest text-muted-foreground">
                        Stability
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Policies */}
            <section
              data-ocid="economy.policies.section"
              aria-label="Economic policies"
              className="flex flex-col gap-2"
            >
              <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
                Available Policies
              </h2>
              {policies.length === 0 ? (
                <p
                  data-ocid="economy.policies.empty_state"
                  className="rounded-md border border-dashed border-border bg-card p-4 text-center text-xs text-muted-foreground"
                >
                  No policies are available yet. Advance the economy to unlock
                  fiscal and monetary options.
                </p>
              ) : (
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {policies.map((policy) => (
                    <PolicyCard
                      key={policy.id.toString()}
                      policy={policy}
                      onApply={(id) => applyPolicy.mutate(id)}
                      pending={
                        applyPolicy.isPending &&
                        applyPolicy.variables === policy.id
                      }
                    />
                  ))}
                </div>
              )}
            </section>

            {/* Advance economy */}
            <Button
              type="button"
              data-ocid="economy.advance_button"
              onClick={() => advanceEconomy.mutate()}
              disabled={advanceEconomy.isPending}
              className="h-12 w-full rounded-md bg-primary font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground shadow-subtle transition-smooth hover:brightness-110"
            >
              {advanceEconomy.isPending
                ? "Advancing economy…"
                : "Advance Economy"}
            </Button>
          </>
        )}
      </div>
    </ScreenShell>
  );
}
