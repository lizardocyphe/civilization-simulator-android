import { ScreenShell } from "@/components/ScreenShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  useBuildFleet,
  useClaimSystem,
  useColonizeSystem,
  useFleets,
  useGame,
  useLaunchMission,
  useMoveFleet,
  useResolveSpaceBattle,
  useSystems,
  useTechnologies,
} from "@/hooks/useQueries";
import {
  RESOURCE_ICONS,
  RESOURCE_LABELS,
  RESOURCE_ORDER,
  formatNumber,
} from "@/lib/game";
import type {
  Fleet,
  ResourcePool,
  SpaceBattleResult,
  StarSystem,
} from "@/types";
import { Era } from "@/types";
import {
  AlertTriangle,
  Crosshair,
  Flag,
  Loader2,
  Orbit,
  Rocket,
  Satellite,
  Shield,
  Swords,
  Telescope,
} from "lucide-react";
import { type FormEvent, useMemo, useState } from "react";

/** The technology catalog id that unlocks the space program. */
const SPACEFLIGHT_TECH_ID = 16n;

/** Whether the civilization has satisfied the backend spaceflight gate. */
function hasSpaceflight(era: Era | undefined, unlockedTechIds: Set<string>) {
  const eraOk = era === Era.modern || era === Era.information;
  return eraOk && unlockedTechIds.has(SPACEFLIGHT_TECH_ID.toString());
}

function yieldSummary(pool: ResourcePool): string {
  const parts = RESOURCE_ORDER.filter((key) => pool[key] > 0n).map(
    (key) => `${RESOURCE_ICONS[key]} ${formatNumber(pool[key])}`,
  );
  return parts.length > 0 ? parts.join("  ") : "Barren";
}

function SystemStateBadge({ system }: { system: StarSystem }) {
  if (system.claimed) {
    return (
      <Badge
        variant="outline"
        className="gap-1 border-accent/60 bg-accent/15 font-mono text-[0.65rem] uppercase tracking-wider text-accent"
      >
        <Flag className="size-3" aria-hidden="true" />
        Claimed
      </Badge>
    );
  }
  if (system.discovered) {
    return (
      <Badge
        variant="outline"
        className="gap-1 border-border bg-background/60 font-mono text-[0.65rem] uppercase tracking-wider text-muted-foreground"
      >
        <Telescope className="size-3" aria-hidden="true" />
        Charted
      </Badge>
    );
  }
  return (
    <Badge
      variant="outline"
      className="gap-1 border-border bg-background/60 font-mono text-[0.65rem] uppercase tracking-wider text-muted-foreground"
    >
      <Orbit className="size-3" aria-hidden="true" />
      Uncharted
    </Badge>
  );
}

function SystemCard({
  system,
  index,
  busy,
  onClaim,
  onColonize,
}: {
  system: StarSystem;
  index: number;
  busy: boolean;
  onClaim: (id: bigint) => void;
  onColonize: (id: bigint) => void;
}) {
  const owned = system.claimed && system.owner !== undefined;
  return (
    <Card
      data-ocid={`space.system.${index}`}
      className="gap-3 rounded-lg border-border bg-card py-4 shadow-none"
    >
      <CardHeader className="gap-1 px-4">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="flex items-center gap-2 font-display text-base font-semibold text-foreground">
            <Satellite className="size-4 text-accent" aria-hidden="true" />
            <span className="min-w-0 truncate">{system.name}</span>
          </CardTitle>
          <SystemStateBadge system={system} />
        </div>
        <p className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
          Q {formatNumber(system.coord.q)} · R {formatNumber(system.coord.r)}
        </p>
      </CardHeader>
      <CardContent className="space-y-3 px-4">
        <dl className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-md border border-border bg-background/60 px-2 py-1.5">
            <dt className="text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground">
              Planets
            </dt>
            <dd className="font-mono text-sm font-semibold tabular-nums text-foreground">
              {formatNumber(system.planets)}
            </dd>
          </div>
          <div className="rounded-md border border-border bg-background/60 px-2 py-1.5">
            <dt className="text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground">
              Defense
            </dt>
            <dd className="flex items-center justify-center gap-1 font-mono text-sm font-semibold tabular-nums text-foreground">
              <Shield
                className="size-3 text-muted-foreground"
                aria-hidden="true"
              />
              {formatNumber(system.defense)}
            </dd>
          </div>
          <div className="rounded-md border border-border bg-background/60 px-2 py-1.5">
            <dt className="text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground">
              Owner
            </dt>
            <dd className="font-mono text-sm font-semibold tabular-nums text-foreground">
              {owned ? "You" : "—"}
            </dd>
          </div>
        </dl>
        <div className="space-y-1">
          <p className="text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground">
            Resource yield
          </p>
          <p className="font-mono text-xs tabular-nums text-foreground">
            {yieldSummary(system.resourceYield)}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            type="button"
            variant="outline"
            data-ocid={`space.claim_button.${index}`}
            disabled={busy || system.claimed || !system.discovered}
            onClick={() => onClaim(system.id)}
            className="h-11 flex-1 rounded-md border-border font-display text-xs font-semibold uppercase tracking-widest"
          >
            <Flag className="size-4" aria-hidden="true" />
            Claim
          </Button>
          <Button
            type="button"
            variant="outline"
            data-ocid={`space.colonize_button.${index}`}
            disabled={busy || !owned}
            onClick={() => onColonize(system.id)}
            className="h-11 flex-1 rounded-md border-border font-display text-xs font-semibold uppercase tracking-widest"
          >
            <Orbit className="size-4" aria-hidden="true" />
            Colonize
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function FleetCard({
  fleet,
  index,
  systems,
  busy,
  onMove,
  onBattle,
}: {
  fleet: Fleet;
  index: number;
  systems: StarSystem[];
  busy: boolean;
  onMove: (fleetId: bigint, targetSystemId: bigint) => void;
  onBattle: (fleetId: bigint, targetSystemId: bigint) => void;
}) {
  const [target, setTarget] = useState<string>("");
  const here = systems.find((s) => s.id === fleet.systemId);
  const targets = systems.filter(
    (s) => s.discovered && s.id !== fleet.systemId,
  );
  const selected = target === "" ? null : BigInt(target);

  return (
    <Card
      data-ocid={`space.fleet.${index}`}
      className="gap-3 rounded-lg border-border bg-card py-4 shadow-none"
    >
      <CardHeader className="gap-1 px-4">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="flex items-center gap-2 font-display text-base font-semibold text-foreground">
            <Rocket className="size-4 text-primary" aria-hidden="true" />
            Fleet {formatNumber(fleet.id)}
          </CardTitle>
          <Badge
            variant="outline"
            className="border-border bg-background/60 font-mono text-[0.65rem] uppercase tracking-wider text-muted-foreground"
          >
            {formatNumber(fleet.ships)} ships
          </Badge>
        </div>
        <p className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
          At {here ? here.name : "unknown"} · Strength{" "}
          {formatNumber(fleet.strength)} · Range {formatNumber(fleet.movement)}
        </p>
      </CardHeader>
      <CardContent className="space-y-3 px-4">
        {targets.length === 0 ? (
          <p className="text-xs text-muted-foreground">
            Chart another star system to give this fleet a destination.
          </p>
        ) : (
          <>
            <div className="space-y-1">
              <Label
                htmlFor={`fleet-target-${index}`}
                className="text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground"
              >
                Destination
              </Label>
              <select
                id={`fleet-target-${index}`}
                data-ocid={`space.fleet_target.${index}`}
                value={target}
                onChange={(event) => setTarget(event.target.value)}
                className="h-11 w-full rounded-md border border-input bg-background px-3 font-mono text-sm text-foreground outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]"
              >
                <option value="">Select a system…</option>
                {targets.map((s) => (
                  <option key={s.id.toString()} value={s.id.toString()}>
                    {s.name}
                    {s.claimed ? " (claimed)" : ""}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                variant="outline"
                data-ocid={`space.move_button.${index}`}
                disabled={busy || selected === null}
                onClick={() => selected !== null && onMove(fleet.id, selected)}
                className="h-11 flex-1 rounded-md border-border font-display text-xs font-semibold uppercase tracking-widest"
              >
                <Crosshair className="size-4" aria-hidden="true" />
                Move
              </Button>
              <Button
                type="button"
                data-ocid={`space.battle_button.${index}`}
                disabled={busy || selected === null}
                onClick={() =>
                  selected !== null && onBattle(fleet.id, selected)
                }
                className="h-11 flex-1 rounded-md bg-destructive font-display text-xs font-semibold uppercase tracking-widest text-destructive-foreground transition-smooth hover:brightness-110"
              >
                <Swords className="size-4" aria-hidden="true" />
                Engage
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

function BattleOutcome({ result }: { result: SpaceBattleResult }) {
  return (
    <div
      data-ocid="space.battle_result"
      className={`space-y-2 rounded-md border p-3 ${
        result.attackerWon
          ? "border-success/60 bg-success/10"
          : "border-destructive/60 bg-destructive/10"
      }`}
    >
      <p className="flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-widest text-foreground">
        {result.attackerWon ? (
          <Swords className="size-4 text-success" aria-hidden="true" />
        ) : (
          <AlertTriangle
            className="size-4 text-destructive"
            aria-hidden="true"
          />
        )}
        {result.attackerWon ? "Victory" : "Repelled"}
      </p>
      <p className="text-sm text-foreground">{result.summary}</p>
      <dl className="grid grid-cols-2 gap-2 font-mono text-xs tabular-nums text-muted-foreground">
        <div>
          <dt className="uppercase tracking-widest">Your losses</dt>
          <dd className="text-foreground">
            {formatNumber(result.attackerLosses)}
          </dd>
        </div>
        <div>
          <dt className="uppercase tracking-widest">Enemy losses</dt>
          <dd className="text-foreground">
            {formatNumber(result.defenderLosses)}
          </dd>
        </div>
      </dl>
      {result.capturedSystem !== undefined && (
        <p className="font-mono text-xs uppercase tracking-widest text-success">
          System captured
        </p>
      )}
    </div>
  );
}

function GateNotice({
  era,
  techUnlocked,
}: {
  era: Era | undefined;
  techUnlocked: boolean;
}) {
  const eraOk = era === Era.modern || era === Era.information;
  return (
    <Card
      data-ocid="space.gate_notice"
      className="gap-3 rounded-lg border-warning/50 bg-card py-5 shadow-none"
    >
      <CardHeader className="gap-2 px-4">
        <CardTitle className="flex items-center gap-2 font-display text-base font-semibold text-foreground">
          <AlertTriangle className="size-5 text-warning" aria-hidden="true" />
          Space program locked
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 px-4 text-sm text-muted-foreground">
        <p>
          Orbital missions require a civilization that has reached the modern
          age and mastered the Spaceflight technology. Complete both
          requirements to open the space theatre.
        </p>
        <ul className="space-y-2">
          <li className="flex items-center gap-2">
            <span
              aria-hidden="true"
              className={`size-2 rounded-full ${
                eraOk ? "bg-success" : "bg-destructive"
              }`}
            />
            <span className="text-foreground">
              Reach the Modern or Information era
            </span>
            <span className="ml-auto font-mono text-xs uppercase tracking-widest text-muted-foreground">
              {eraOk ? "Met" : "Pending"}
            </span>
          </li>
          <li className="flex items-center gap-2">
            <span
              aria-hidden="true"
              className={`size-2 rounded-full ${
                techUnlocked ? "bg-success" : "bg-destructive"
              }`}
            />
            <span className="text-foreground">
              Research the Spaceflight technology
            </span>
            <span className="ml-auto font-mono text-xs uppercase tracking-widest text-muted-foreground">
              {techUnlocked ? "Met" : "Pending"}
            </span>
          </li>
        </ul>
      </CardContent>
    </Card>
  );
}

export default function SpaceScreen() {
  const { data: game, isLoading: gameLoading } = useGame();
  const { data: technologies } = useTechnologies();
  const systemsQuery = useSystems();
  const fleetsQuery = useFleets();

  const launchMission = useLaunchMission();
  const claimSystem = useClaimSystem();
  const colonizeSystem = useColonizeSystem();
  const buildFleet = useBuildFleet();
  const moveFleet = useMoveFleet();
  const resolveBattle = useResolveSpaceBattle();

  const [coordQ, setCoordQ] = useState("");
  const [coordR, setCoordR] = useState("");
  const [ships, setShips] = useState("1");
  const [buildSystemId, setBuildSystemId] = useState("");
  const [battleResult, setBattleResult] = useState<SpaceBattleResult | null>(
    null,
  );
  const [actionError, setActionError] = useState<string | null>(null);

  const unlockedTechIds = useMemo(
    () =>
      new Set(
        (technologies ?? [])
          .filter((tech) => tech.unlocked)
          .map((tech) => tech.id.toString()),
      ),
    [technologies],
  );

  const era = game?.civilization.era;
  const gateOpen = hasSpaceflight(era, unlockedTechIds);

  const systems = systemsQuery.data ?? [];
  const fleets = fleetsQuery.data ?? [];
  const ownedSystems = systems.filter(
    (s) => s.claimed && s.owner !== undefined,
  );

  const busy =
    launchMission.isPending ||
    claimSystem.isPending ||
    colonizeSystem.isPending ||
    buildFleet.isPending ||
    moveFleet.isPending ||
    resolveBattle.isPending;

  function runAction(
    action: { mutate: (arg: never, opts: never) => void },
    arg: unknown,
    fallback: string,
  ) {
    setActionError(null);
    setBattleResult(null);
    (
      action as {
        mutate: (
          value: unknown,
          options: { onError: (error: unknown) => void },
        ) => void;
      }
    ).mutate(arg, {
      onError: (error: unknown) => {
        setActionError(error instanceof Error ? error.message : fallback);
      },
    });
  }

  function handleLaunch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const q = coordQ.trim();
    const r = coordR.trim();
    if (q === "" || r === "") {
      setActionError("Enter both a Q and R coordinate to launch a mission.");
      return;
    }
    let qValue: bigint;
    let rValue: bigint;
    try {
      qValue = BigInt(q);
      rValue = BigInt(r);
    } catch {
      setActionError("Coordinates must be whole numbers.");
      return;
    }
    runAction(launchMission, { q: qValue, r: rValue }, "Mission launch failed");
  }

  function handleBuild(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (buildSystemId === "") {
      setActionError("Select a system you own to build a fleet.");
      return;
    }
    let shipCount: bigint;
    try {
      shipCount = BigInt(ships.trim() === "" ? "0" : ships.trim());
    } catch {
      setActionError("Ship count must be a whole number.");
      return;
    }
    if (shipCount <= 0n) {
      setActionError("A fleet needs at least one ship.");
      return;
    }
    runAction(
      buildFleet,
      { systemId: BigInt(buildSystemId), ships: shipCount },
      "Fleet construction failed",
    );
  }

  function handleBattle(fleetId: bigint, targetSystemId: bigint) {
    setActionError(null);
    setBattleResult(null);
    resolveBattle.mutate(
      { fleetId, targetSystemId },
      {
        onSuccess: (result) => setBattleResult(result),
        onError: (error) =>
          setActionError(
            error instanceof Error ? error.message : "Battle resolution failed",
          ),
      },
    );
  }

  const loading =
    gameLoading || systemsQuery.isLoading || fleetsQuery.isLoading;
  const queryError = systemsQuery.isError || fleetsQuery.isError;

  return (
    <ScreenShell
      eyebrow="Explore"
      title="Space Program"
      description="Chart star systems, claim and colonize worlds, and command your fleets."
    >
      <div className="space-y-4">
        {actionError && (
          <div
            data-ocid="space.error_state"
            role="alert"
            className="flex items-start gap-2 rounded-md border border-destructive/60 bg-destructive/10 p-3 text-sm text-foreground"
          >
            <AlertTriangle
              className="mt-0.5 size-4 shrink-0 text-destructive"
              aria-hidden="true"
            />
            <span>{actionError}</span>
          </div>
        )}

        {loading ? (
          <div
            data-ocid="space.loading_state"
            className="flex items-center justify-center gap-2 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground"
          >
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            Scanning the orbital theatre…
          </div>
        ) : queryError ? (
          <div
            data-ocid="space.error_state"
            className="rounded-md border border-destructive/60 bg-destructive/10 p-4 text-sm text-foreground"
          >
            <p className="font-semibold">Could not reach the space program.</p>
            <Button
              type="button"
              variant="outline"
              data-ocid="space.retry_button"
              onClick={() => {
                void systemsQuery.refetch();
                void fleetsQuery.refetch();
              }}
              className="mt-3 h-11 rounded-md border-border font-display text-xs font-semibold uppercase tracking-widest"
            >
              Retry
            </Button>
          </div>
        ) : !gateOpen ? (
          <GateNotice era={era} techUnlocked={unlockedTechIds.has("16")} />
        ) : (
          <>
            <Card className="gap-3 rounded-lg border-border bg-card py-4 shadow-none">
              <CardHeader className="gap-1 px-4">
                <CardTitle className="flex items-center gap-2 font-display text-base font-semibold text-foreground">
                  <Telescope
                    className="size-4 text-accent"
                    aria-hidden="true"
                  />
                  Launch exploration mission
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                  Send a probe to a hex coordinate to chart the star system
                  there.
                </p>
              </CardHeader>
              <CardContent className="px-4">
                <form
                  onSubmit={handleLaunch}
                  className="flex flex-wrap items-end gap-2"
                >
                  <div className="min-w-[5rem] flex-1 space-y-1">
                    <Label
                      htmlFor="mission-q"
                      className="text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground"
                    >
                      Q
                    </Label>
                    <Input
                      id="mission-q"
                      data-ocid="space.mission_q_input"
                      inputMode="numeric"
                      value={coordQ}
                      onChange={(event) => setCoordQ(event.target.value)}
                      placeholder="0"
                      className="h-11 font-mono"
                    />
                  </div>
                  <div className="min-w-[5rem] flex-1 space-y-1">
                    <Label
                      htmlFor="mission-r"
                      className="text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground"
                    >
                      R
                    </Label>
                    <Input
                      id="mission-r"
                      data-ocid="space.mission_r_input"
                      inputMode="numeric"
                      value={coordR}
                      onChange={(event) => setCoordR(event.target.value)}
                      placeholder="0"
                      className="h-11 font-mono"
                    />
                  </div>
                  <Button
                    type="submit"
                    data-ocid="space.launch_button"
                    disabled={busy}
                    className="h-11 rounded-md bg-primary font-display text-xs font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110"
                  >
                    <Rocket className="size-4" aria-hidden="true" />
                    {launchMission.isPending ? "Launching…" : "Launch"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <section className="space-y-2" aria-label="Star systems">
              <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                Star systems
              </h2>
              {systems.length === 0 ? (
                <div
                  data-ocid="space.systems_empty_state"
                  className="rounded-md border border-dashed border-border bg-card p-6 text-center text-sm text-muted-foreground"
                >
                  No systems charted yet. Launch a mission to begin your survey.
                </div>
              ) : (
                <div className="grid gap-3 sm:grid-cols-2">
                  {systems.map((system, index) => (
                    <SystemCard
                      key={system.id.toString()}
                      system={system}
                      index={index + 1}
                      busy={busy}
                      onClaim={(id) =>
                        runAction(claimSystem, id, "Claim failed")
                      }
                      onColonize={(id) =>
                        runAction(colonizeSystem, id, "Colonization failed")
                      }
                    />
                  ))}
                </div>
              )}
            </section>

            <Card className="gap-3 rounded-lg border-border bg-card py-4 shadow-none">
              <CardHeader className="gap-1 px-4">
                <CardTitle className="flex items-center gap-2 font-display text-base font-semibold text-foreground">
                  <Rocket className="size-4 text-primary" aria-hidden="true" />
                  Build a fleet
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                  Construct ships at a system you own. Each ship costs 15
                  production and 5 gold.
                </p>
              </CardHeader>
              <CardContent className="px-4">
                {ownedSystems.length === 0 ? (
                  <p
                    data-ocid="space.build_empty_state"
                    className="text-sm text-muted-foreground"
                  >
                    Claim a star system before you can build a fleet.
                  </p>
                ) : (
                  <form
                    onSubmit={handleBuild}
                    className="flex flex-wrap items-end gap-2"
                  >
                    <div className="min-w-[8rem] flex-1 space-y-1">
                      <Label
                        htmlFor="build-system"
                        className="text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground"
                      >
                        Shipyard
                      </Label>
                      <select
                        id="build-system"
                        data-ocid="space.build_system_select"
                        value={buildSystemId}
                        onChange={(event) =>
                          setBuildSystemId(event.target.value)
                        }
                        className="h-11 w-full rounded-md border border-input bg-background px-3 font-mono text-sm text-foreground outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]"
                      >
                        <option value="">Select a system…</option>
                        {ownedSystems.map((s) => (
                          <option key={s.id.toString()} value={s.id.toString()}>
                            {s.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="min-w-[5rem] flex-1 space-y-1">
                      <Label
                        htmlFor="build-ships"
                        className="text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground"
                      >
                        Ships
                      </Label>
                      <Input
                        id="build-ships"
                        data-ocid="space.build_ships_input"
                        inputMode="numeric"
                        value={ships}
                        onChange={(event) => setShips(event.target.value)}
                        className="h-11 font-mono"
                      />
                    </div>
                    <Button
                      type="submit"
                      data-ocid="space.build_button"
                      disabled={busy}
                      className="h-11 rounded-md bg-primary font-display text-xs font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110"
                    >
                      {buildFleet.isPending ? "Building…" : "Build"}
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>

            <section className="space-y-2" aria-label="Fleets">
              <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                Your fleets
              </h2>
              {battleResult && <BattleOutcome result={battleResult} />}
              {fleets.length === 0 ? (
                <div
                  data-ocid="space.fleets_empty_state"
                  className="rounded-md border border-dashed border-border bg-card p-6 text-center text-sm text-muted-foreground"
                >
                  No fleets in service. Build one at a system you own.
                </div>
              ) : (
                <div className="grid gap-3 sm:grid-cols-2">
                  {fleets.map((fleet, index) => (
                    <FleetCard
                      key={fleet.id.toString()}
                      fleet={fleet}
                      index={index + 1}
                      systems={systems}
                      busy={busy}
                      onMove={(fleetId, targetSystemId) =>
                        runAction(
                          moveFleet,
                          { fleetId, targetSystemId },
                          "Fleet move failed",
                        )
                      }
                      onBattle={handleBattle}
                    />
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </div>
    </ScreenShell>
  );
}
