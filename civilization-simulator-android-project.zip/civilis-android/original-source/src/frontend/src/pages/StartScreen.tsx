import { ScreenShell } from "@/components/ScreenShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useAiDifficulty,
  useGame,
  useSetAiDifficulty,
  useStartGame,
} from "@/hooks/useQueries";
import {
  ERA_ORDER,
  eraLabel,
  formatNumber,
  gameDateFromTurn,
} from "@/lib/game";
import { AiDifficulty, Era } from "@/types";
import { Link } from "@tanstack/react-router";
import { AlertTriangle, ArrowRight, Flag, Loader2, Swords } from "lucide-react";
import { type FormEvent, useState } from "react";

/** Plain-language description of what each AI difficulty actually changes. */
const DIFFICULTY_OPTIONS: {
  value: AiDifficulty;
  label: string;
  tagline: string;
  effect: string;
}[] = [
  {
    value: AiDifficulty.passive,
    label: "Passive",
    tagline: "A gentle world",
    effect:
      "Rival nations expand slowly, rarely declare war, and offer generous trade terms. Best for learning the systems.",
  },
  {
    value: AiDifficulty.balanced,
    label: "Balanced",
    tagline: "A fair contest",
    effect:
      "Rivals grow at a steady pace, defend their borders, and negotiate when it suits them. The intended challenge.",
  },
  {
    value: AiDifficulty.aggressive,
    label: "Aggressive",
    tagline: "A hostile world",
    effect:
      "Rivals expand fast, mass armies early, and press every advantage. Expect early wars and hard-fought borders.",
  },
];

const ERA_BLURBS: Record<Era, string> = {
  [Era.ancient]: "Begin with stone, grain and the first cities.",
  [Era.industrial]: "Steam, steel and the scramble for resources.",
  [Era.modern]: "Nations, industry and the race to the atom.",
  [Era.information]: "Networks, satellites and a connected world.",
};

function DifficultyCard({
  option,
  selected,
  onSelect,
}: {
  option: (typeof DIFFICULTY_OPTIONS)[number];
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      data-ocid={`start.difficulty.${option.value}`}
      aria-pressed={selected}
      onClick={onSelect}
      className={`flex min-h-11 w-full flex-col gap-1 rounded-md border p-3 text-left transition-smooth focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring ${
        selected
          ? "border-primary bg-primary/10 shadow-subtle"
          : "border-border bg-card hover:border-accent/60 hover:bg-secondary"
      }`}
    >
      <span className="flex items-center justify-between gap-2">
        <span className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          {option.label}
        </span>
        {selected && (
          <Badge
            variant="outline"
            className="border-primary/60 font-mono text-[0.6rem] uppercase tracking-widest text-primary"
          >
            Selected
          </Badge>
        )}
      </span>
      <span className="text-xs font-medium text-accent">{option.tagline}</span>
      <span className="text-xs leading-relaxed text-muted-foreground">
        {option.effect}
      </span>
    </button>
  );
}

function CampaignSummary() {
  const { data: game, isPending, isError, refetch } = useGame();

  if (isPending) {
    return (
      <div
        data-ocid="start.campaign.loading_state"
        className="space-y-2 rounded-md border border-border bg-card p-4 shadow-subtle"
      >
        <Skeleton className="h-4 w-32" />
        <Skeleton className="h-3 w-48" />
        <Skeleton className="h-11 w-full" />
      </div>
    );
  }

  if (isError) {
    return (
      <div
        data-ocid="start.campaign.error_state"
        className="flex flex-col gap-3 rounded-md border border-destructive/50 bg-destructive/10 p-4"
      >
        <p className="flex items-center gap-2 text-sm text-foreground">
          <AlertTriangle
            className="size-4 text-destructive"
            aria-hidden="true"
          />
          Could not load your saved campaign.
        </p>
        <Button
          type="button"
          variant="outline"
          data-ocid="start.campaign.retry_button"
          onClick={() => void refetch()}
          className="h-11 rounded-md font-display text-xs font-semibold uppercase tracking-widest"
        >
          Retry
        </Button>
      </div>
    );
  }

  if (!game) {
    return (
      <div
        data-ocid="start.campaign.empty_state"
        className="rounded-md border border-dashed border-border bg-card/60 p-4 text-sm text-muted-foreground"
      >
        No campaign in progress. Name your nation below to begin.
      </div>
    );
  }

  return (
    <div
      data-ocid="start.campaign.card"
      className="flex flex-col gap-3 rounded-md border border-border bg-card p-4 shadow-subtle"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-accent">
            Campaign in progress
          </p>
          <h2 className="truncate font-display text-lg font-bold text-foreground">
            {game.civilization.name}
          </h2>
        </div>
        <Badge
          variant="outline"
          className="shrink-0 border-border font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground"
        >
          {eraLabel(game.civilization.era)}
        </Badge>
      </div>
      <dl className="grid grid-cols-2 gap-2 font-mono text-xs tabular-nums text-muted-foreground">
        <div className="rounded-sm border border-border/60 bg-background/50 px-2 py-1.5">
          <dt className="text-[0.6rem] uppercase tracking-widest">Turn</dt>
          <dd className="text-sm font-semibold text-foreground">
            {formatNumber(game.turn)}
          </dd>
        </div>
        <div className="rounded-sm border border-border/60 bg-background/50 px-2 py-1.5">
          <dt className="text-[0.6rem] uppercase tracking-widest">Date</dt>
          <dd className="text-sm font-semibold text-foreground">
            {gameDateFromTurn(game.turn)}
          </dd>
        </div>
      </dl>
      <Button
        asChild
        data-ocid="start.continue_button"
        className="h-11 rounded-md bg-primary font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground shadow-subtle transition-smooth hover:brightness-110"
      >
        <Link to="/map">
          Continue campaign
          <ArrowRight className="size-4" aria-hidden="true" />
        </Link>
      </Button>
    </div>
  );
}

export default function StartScreen() {
  const { data: game } = useGame();
  const { data: currentDifficulty } = useAiDifficulty();
  const startGame = useStartGame();
  const setAiDifficulty = useSetAiDifficulty();

  const [name, setName] = useState("");
  const [era, setEra] = useState<Era>(Era.ancient);
  const [difficulty, setDifficulty] = useState<AiDifficulty>(
    AiDifficulty.balanced,
  );

  const trimmedName = name.trim();
  const canStart = trimmedName.length > 0 && !startGame.isPending;
  const selectedOption =
    DIFFICULTY_OPTIONS.find((option) => option.value === difficulty) ??
    DIFFICULTY_OPTIONS[1];

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canStart) return;
    const chosenName = trimmedName;
    setName("");
    startGame.mutate(
      { name: chosenName, era },
      {
        onSuccess: () => {
          setAiDifficulty.mutate(difficulty);
        },
        onError: () => {
          setName((current) => (current === "" ? chosenName : current));
        },
      },
    );
  }

  return (
    <ScreenShell
      eyebrow="New Campaign"
      title="Start or Load a Game"
      description="Name your civilization, choose a starting era, and set how hard the rival nations will push."
    >
      <div className="flex flex-col gap-4">
        <CampaignSummary />

        <form
          data-ocid="start.form"
          onSubmit={handleSubmit}
          className="flex flex-col gap-4 rounded-md border border-border bg-card p-4 shadow-subtle"
        >
          <div className="flex flex-col gap-1.5">
            <Label
              htmlFor="start.nation_name"
              className="font-display text-xs font-semibold uppercase tracking-widest text-muted-foreground"
            >
              Nation name
            </Label>
            <Input
              id="start.nation_name"
              data-ocid="start.nation_name_input"
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="e.g. Aurelia"
              maxLength={40}
              autoComplete="off"
              className="h-11 rounded-md bg-background font-body text-base"
            />
            <p className="text-xs text-muted-foreground">
              This is how your civilization appears to rivals and in the
              chronicle.
            </p>
          </div>

          <fieldset className="flex flex-col gap-2">
            <legend className="font-display text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Starting era
            </legend>
            <div className="grid grid-cols-2 gap-2">
              {ERA_ORDER.map((option) => {
                const selected = era === option;
                return (
                  <button
                    key={option}
                    type="button"
                    data-ocid={`start.era.${option}`}
                    aria-pressed={selected}
                    onClick={() => setEra(option)}
                    className={`flex min-h-11 flex-col gap-0.5 rounded-md border p-2.5 text-left transition-smooth focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring ${
                      selected
                        ? "border-primary bg-primary/10"
                        : "border-border bg-background hover:border-accent/60 hover:bg-secondary"
                    }`}
                  >
                    <span className="font-display text-sm font-semibold text-foreground">
                      {eraLabel(option)}
                    </span>
                    <span className="text-[0.7rem] leading-snug text-muted-foreground">
                      {ERA_BLURBS[option]}
                    </span>
                  </button>
                );
              })}
            </div>
          </fieldset>

          <fieldset className="flex flex-col gap-2">
            <legend className="flex items-center gap-2 font-display text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              <Swords className="size-3.5" aria-hidden="true" />
              AI difficulty
            </legend>
            <div className="flex flex-col gap-2">
              {DIFFICULTY_OPTIONS.map((option) => (
                <DifficultyCard
                  key={option.value}
                  option={option}
                  selected={difficulty === option.value}
                  onSelect={() => setDifficulty(option.value)}
                />
              ))}
            </div>
            <p
              data-ocid="start.difficulty_effect"
              className="rounded-sm border border-border/60 bg-background/50 px-3 py-2 text-xs leading-relaxed text-muted-foreground"
            >
              <span className="font-semibold text-foreground">
                {selectedOption.label}:
              </span>{" "}
              {selectedOption.effect}
            </p>
            {currentDifficulty && (
              <p className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
                Current world setting:{" "}
                <span className="text-accent">{currentDifficulty}</span>
              </p>
            )}
          </fieldset>

          {startGame.isError && (
            <p
              data-ocid="start.error_state"
              role="alert"
              className="flex items-center gap-2 rounded-sm border border-destructive/50 bg-destructive/10 px-3 py-2 text-xs text-foreground"
            >
              <AlertTriangle
                className="size-3.5 shrink-0 text-destructive"
                aria-hidden="true"
              />
              Could not start the campaign. Check your connection and try again.
            </p>
          )}

          <Button
            type="submit"
            data-ocid="start.submit_button"
            disabled={!canStart}
            className="h-12 rounded-md bg-primary font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground shadow-subtle transition-smooth hover:brightness-110 disabled:opacity-60"
          >
            {startGame.isPending ? (
              <>
                <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                Founding nation…
              </>
            ) : (
              <>
                <Flag className="size-4" aria-hidden="true" />
                {game ? "Start new campaign" : "Begin campaign"}
              </>
            )}
          </Button>
          {!trimmedName && (
            <p className="text-center text-xs text-muted-foreground">
              Enter a nation name to begin.
            </p>
          )}
        </form>
      </div>
    </ScreenShell>
  );
}
