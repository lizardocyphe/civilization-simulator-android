import type { CrisisOutcome, WeatherEffects } from "@/backend";
import { ScreenShell } from "@/components/ScreenShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useApplyCrisisChoice,
  useCrises,
  useSetLocation,
  useWeather,
  useWeatherEffects,
} from "@/hooks/useQueries";
import {
  RESOURCE_ICONS,
  RESOURCE_LABELS,
  RESOURCE_ORDER,
  formatNumber,
  formatRelativeTime,
  weatherGlyph,
} from "@/lib/game";
import type { CrisisEvent, GeoLocation } from "@/types";
import {
  AlertTriangle,
  CloudRain,
  Droplets,
  Gauge,
  Leaf,
  MapPin,
  Navigation,
  RefreshCw,
  Snowflake,
  Thermometer,
  Wind,
} from "lucide-react";
import { type FormEvent, useState } from "react";

/* ------------------------------------------------------------------ */
/* Presets                                                             */
/* ------------------------------------------------------------------ */

interface LocationPreset {
  name: string;
  latitude: number;
  longitude: number;
}

/** A few well-known coordinates so a mobile player can set a location in one tap. */
const LOCATION_PRESETS: LocationPreset[] = [
  { name: "London", latitude: 51.5074, longitude: -0.1278 },
  { name: "New York", latitude: 40.7128, longitude: -74.006 },
  { name: "Cairo", latitude: 30.0444, longitude: 31.2357 },
  { name: "Mumbai", latitude: 19.076, longitude: 72.8777 },
  { name: "São Paulo", latitude: -23.5505, longitude: -46.6333 },
  { name: "Tokyo", latitude: 35.6762, longitude: 139.6503 },
];

/* ------------------------------------------------------------------ */
/* Weather helpers                                                     */
/* ------------------------------------------------------------------ */

function conditionLabel(condition: string): string {
  if (!condition || condition === "unknown") return "No reading yet";
  return condition.charAt(0).toUpperCase() + condition.slice(1);
}

/** Tone for the temperature readout — cold, temperate or hot. */
function temperatureTone(celsius: number): string {
  if (celsius <= 0) return "text-[oklch(var(--deflation))]";
  if (celsius >= 30) return "text-[oklch(var(--inflation))]";
  return "text-foreground";
}

/** A multiplier rendered as a signed percentage change, e.g. `-40%`. */
function multiplierDelta(multiplier: number): string {
  const pct = Math.round((multiplier - 1) * 100);
  if (pct === 0) return "no change";
  return `${pct > 0 ? "+" : ""}${pct}%`;
}

function multiplierTone(
  multiplier: number,
): "positive" | "negative" | "neutral" {
  if (multiplier > 1.001) return "positive";
  if (multiplier < 0.999) return "negative";
  return "neutral";
}

const TONE_TEXT: Record<"positive" | "negative" | "neutral", string> = {
  positive: "text-[oklch(var(--success))]",
  negative: "text-[oklch(var(--destructive))]",
  neutral: "text-muted-foreground",
};

const TONE_BAR: Record<"positive" | "negative" | "neutral", string> = {
  positive: "bg-[oklch(var(--success))]",
  negative: "bg-[oklch(var(--destructive))]",
  neutral: "bg-muted-foreground",
};

/* ------------------------------------------------------------------ */
/* Current conditions                                                  */
/* ------------------------------------------------------------------ */

function WeatherStat({
  icon: Icon,
  label,
  value,
  valueClassName,
}: {
  icon: typeof Wind;
  label: string;
  value: string;
  valueClassName?: string;
}) {
  return (
    <div className="flex flex-col gap-1 rounded-md border border-border bg-background/50 px-3 py-2">
      <span className="flex items-center gap-1.5 text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground">
        <Icon className="size-3" aria-hidden="true" />
        {label}
      </span>
      <span
        className={`font-mono text-sm font-semibold tabular-nums ${
          valueClassName ?? "text-foreground"
        }`}
      >
        {value}
      </span>
    </div>
  );
}

function CurrentConditions() {
  const {
    data: weather,
    isLoading,
    isError,
    refetch,
    isFetching,
  } = useWeather();

  if (isLoading) {
    return (
      <div
        data-ocid="weather.loading_state"
        className="rounded-md border border-border bg-card p-4 shadow-subtle"
      >
        <div className="flex items-center gap-4">
          <Skeleton className="size-16 rounded-md" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-8 w-24" />
          </div>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2">
          {Array.from({ length: 3 }, (_, i) => `weather-stat-${i}`).map(
            (id) => (
              <Skeleton key={id} className="h-14 rounded-md" />
            ),
          )}
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div
        data-ocid="weather.error_state"
        className="flex flex-col items-start gap-3 rounded-md border border-destructive/50 bg-destructive/10 p-4"
      >
        <div className="flex items-center gap-2 text-destructive">
          <AlertTriangle className="size-4" aria-hidden="true" />
          <p className="text-sm font-semibold">Weather reading unavailable</p>
        </div>
        <p className="text-sm text-muted-foreground">
          The simulation could not reach the weather service. Your location is
          kept, so you can retry.
        </p>
        <Button
          type="button"
          variant="outline"
          data-ocid="weather.retry_button"
          onClick={() => void refetch()}
          disabled={isFetching}
          className="h-11 rounded-md"
        >
          <RefreshCw className="size-4" aria-hidden="true" />
          {isFetching ? "Retrying…" : "Retry"}
        </Button>
      </div>
    );
  }

  if (!weather || !weather.location) {
    return (
      <div
        data-ocid="weather.empty_state"
        className="flex flex-col items-center gap-3 rounded-md border border-dashed border-border bg-card p-6 text-center shadow-subtle"
      >
        <span className="flex size-12 items-center justify-center rounded-full bg-secondary text-accent">
          <MapPin className="size-6" aria-hidden="true" />
        </span>
        <div className="space-y-1">
          <p className="font-display text-base font-semibold text-foreground">
            Set your location
          </p>
          <p className="text-sm text-muted-foreground">
            Choose a real-world location below and the simulation will pull live
            weather to drive harvest, movement and energy.
          </p>
        </div>
      </div>
    );
  }

  const tone = temperatureTone(weather.temperatureC);

  return (
    <div
      data-ocid="weather.current_card"
      className="overflow-hidden rounded-md border border-border bg-card shadow-subtle"
    >
      <div className="flex items-center gap-4 border-b border-border/60 bg-gradient-subtle p-4">
        <span
          className="flex size-16 shrink-0 items-center justify-center rounded-md border border-border bg-background/60 text-4xl"
          aria-hidden="true"
        >
          {weatherGlyph(weather.condition)}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate font-display text-lg font-semibold text-foreground">
            {conditionLabel(weather.condition)}
          </p>
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <MapPin className="size-3 shrink-0" aria-hidden="true" />
            <span className="truncate">{weather.location.name}</span>
          </p>
          <p className="mt-0.5 font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground/70">
            Updated {formatRelativeTime(weather.updatedAt)}
          </p>
        </div>
        <div className="shrink-0 text-right">
          <p className={`font-mono text-3xl font-bold tabular-nums ${tone}`}>
            {Math.round(weather.temperatureC)}°
          </p>
          <p className="text-[0.6rem] font-semibold uppercase tracking-widest text-muted-foreground">
            Celsius
          </p>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-2 p-3">
        <WeatherStat
          icon={Wind}
          label="Wind"
          value={`${Math.round(weather.windKph)} km/h`}
        />
        <WeatherStat
          icon={Droplets}
          label="Rain"
          value={`${weather.precipitationMm.toFixed(1)} mm`}
        />
        <WeatherStat
          icon={Thermometer}
          label="Coords"
          value={`${weather.location.latitude.toFixed(1)}, ${weather.location.longitude.toFixed(1)}`}
        />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Location setter                                                     */
/* ------------------------------------------------------------------ */

function LocationForm() {
  const setLocation = useSetLocation();
  const [name, setName] = useState("");
  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");
  const [error, setError] = useState<string | null>(null);

  const latValue = Number.parseFloat(latitude);
  const lonValue = Number.parseFloat(longitude);
  const coordsValid =
    Number.isFinite(latValue) &&
    Number.isFinite(lonValue) &&
    latValue >= -90 &&
    latValue <= 90 &&
    lonValue >= -180 &&
    lonValue <= 180;
  const canSubmit =
    name.trim().length > 0 && coordsValid && !setLocation.isPending;

  function submit(location: GeoLocation) {
    setError(null);
    setLocation.mutate(location, {
      onError: () =>
        setError("Could not fetch weather for that location. Try again."),
    });
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canSubmit) return;
    submit({ name: name.trim(), latitude: latValue, longitude: lonValue });
  }

  function applyPreset(preset: LocationPreset) {
    setName(preset.name);
    setLatitude(preset.latitude.toString());
    setLongitude(preset.longitude.toString());
    submit(preset);
  }

  return (
    <section
      data-ocid="weather.location_panel"
      className="rounded-md border border-border bg-card p-4 shadow-subtle"
    >
      <div className="mb-3 flex items-center gap-2">
        <Navigation className="size-4 text-accent" aria-hidden="true" />
        <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          Set Location
        </h2>
      </div>

      <div className="mb-3 flex flex-wrap gap-2">
        {LOCATION_PRESETS.map((preset) => (
          <Button
            key={preset.name}
            type="button"
            variant="outline"
            size="sm"
            data-ocid={`weather.preset.${preset.name.toLowerCase().replace(/\s+/g, "_")}`}
            onClick={() => applyPreset(preset)}
            disabled={setLocation.isPending}
            className="h-9 rounded-full border-border px-3 text-xs"
          >
            {preset.name}
          </Button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="space-y-1.5">
          <Label htmlFor="weather-location-name">Place name</Label>
          <Input
            id="weather-location-name"
            data-ocid="weather.location_name_input"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="e.g. Reykjavík"
            autoComplete="off"
            className="h-11"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="weather-latitude">Latitude</Label>
            <Input
              id="weather-latitude"
              data-ocid="weather.latitude_input"
              type="number"
              inputMode="decimal"
              step="0.0001"
              min="-90"
              max="90"
              value={latitude}
              onChange={(event) => setLatitude(event.target.value)}
              placeholder="51.5074"
              className="h-11 font-mono"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="weather-longitude">Longitude</Label>
            <Input
              id="weather-longitude"
              data-ocid="weather.longitude_input"
              type="number"
              inputMode="decimal"
              step="0.0001"
              min="-180"
              max="180"
              value={longitude}
              onChange={(event) => setLongitude(event.target.value)}
              placeholder="-0.1278"
              className="h-11 font-mono"
            />
          </div>
        </div>

        {error && (
          <p
            data-ocid="weather.location_error"
            role="alert"
            className="text-sm text-destructive"
          >
            {error}
          </p>
        )}

        <Button
          type="submit"
          data-ocid="weather.set_location_button"
          disabled={!canSubmit}
          className="h-11 w-full rounded-md bg-primary font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110"
        >
          {setLocation.isPending ? "Fetching weather…" : "Set location"}
        </Button>
      </form>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Weather effects                                                     */
/* ------------------------------------------------------------------ */

interface EffectRow {
  key: string;
  label: string;
  icon: typeof Leaf;
  multiplier: number;
  detail: string;
}

function EffectBar({ multiplier }: { multiplier: number }) {
  const tone = multiplierTone(multiplier);
  // Map 0.5–1.5 onto 0–100% so the bar reads as a deviation from neutral.
  const width = Math.max(4, Math.min(100, ((multiplier - 0.5) / 1.0) * 100));
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
      <div
        className={`h-full rounded-full transition-smooth ${TONE_BAR[tone]}`}
        style={{ width: `${width}%` }}
      />
    </div>
  );
}

function WeatherEffectsPanel() {
  const { data: effects, isLoading } = useWeatherEffects();

  if (isLoading) {
    return (
      <section
        data-ocid="weather.effects_loading_state"
        className="rounded-md border border-border bg-card p-4 shadow-subtle"
      >
        <Skeleton className="mb-3 h-4 w-40" />
        <div className="space-y-3">
          {Array.from({ length: 3 }, (_, i) => `effect-${i}`).map((id) => (
            <Skeleton key={id} className="h-10 rounded-md" />
          ))}
        </div>
      </section>
    );
  }

  if (!effects) return null;

  const rows: EffectRow[] = [
    {
      key: "harvest",
      label: "Harvest",
      icon: Leaf,
      multiplier: effects.harvestMultiplier,
      detail: "Food yield from worked tiles",
    },
    {
      key: "movement",
      label: "Movement",
      icon: Gauge,
      multiplier: effects.movementMultiplier,
      detail: "Unit movement range per turn",
    },
    {
      key: "energy",
      label: "Energy",
      icon: Snowflake,
      multiplier: effects.energyDemandMultiplier,
      detail: "Energy demand for heating and cooling",
    },
  ];

  return (
    <section
      data-ocid="weather.effects_panel"
      className="rounded-md border border-border bg-card p-4 shadow-subtle"
    >
      <div className="mb-3 flex items-center gap-2">
        <CloudRain className="size-4 text-accent" aria-hidden="true" />
        <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          Simulation Effects
        </h2>
      </div>
      <p className="mb-3 text-sm text-muted-foreground">{effects.summary}</p>
      <ul className="space-y-3">
        {rows.map((row) => {
          const Icon = row.icon;
          const tone = multiplierTone(row.multiplier);
          return (
            <li
              key={row.key}
              data-ocid={`weather.effect.${row.key}`}
              className="space-y-1.5"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 text-sm font-medium text-foreground">
                  <Icon
                    className="size-4 text-muted-foreground"
                    aria-hidden="true"
                  />
                  {row.label}
                </span>
                <span className="flex items-baseline gap-2">
                  <span
                    className={`font-mono text-sm font-semibold tabular-nums ${TONE_TEXT[tone]}`}
                  >
                    ×{row.multiplier.toFixed(2)}
                  </span>
                  <span className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
                    {multiplierDelta(row.multiplier)}
                  </span>
                </span>
              </div>
              <EffectBar multiplier={row.multiplier} />
              <p className="text-xs text-muted-foreground">{row.detail}</p>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Crises                                                              */
/* ------------------------------------------------------------------ */

function CrisisOutcomeSummary({ outcome }: { outcome: CrisisOutcome }) {
  const deltas = RESOURCE_ORDER.filter(
    (key) => outcome.resourceDelta[key] !== 0n,
  );
  return (
    <div
      data-ocid="weather.crisis_outcome"
      className="mt-3 space-y-2 rounded-md border border-accent/40 bg-accent/10 p-3"
    >
      <p className="text-sm font-medium text-foreground">{outcome.summary}</p>
      <div className="flex flex-wrap gap-2">
        {deltas.map((key) => {
          const value = outcome.resourceDelta[key];
          const positive = value > 0n;
          return (
            <Badge
              key={key}
              variant="outline"
              className={`gap-1 border-border bg-background/60 font-mono text-xs tabular-nums ${
                positive
                  ? "text-[oklch(var(--success))]"
                  : "text-[oklch(var(--destructive))]"
              }`}
            >
              <span aria-hidden="true">{RESOURCE_ICONS[key]}</span>
              {RESOURCE_LABELS[key]} {positive ? "+" : ""}
              {formatNumber(value)}
            </Badge>
          );
        })}
        {outcome.stabilityDelta !== 0n && (
          <Badge
            variant="outline"
            className={`gap-1 border-border bg-background/60 font-mono text-xs tabular-nums ${
              outcome.stabilityDelta > 0n
                ? "text-[oklch(var(--success))]"
                : "text-[oklch(var(--destructive))]"
            }`}
          >
            Stability {outcome.stabilityDelta > 0n ? "+" : ""}
            {formatNumber(outcome.stabilityDelta)}
          </Badge>
        )}
      </div>
    </div>
  );
}

function CrisisCard({
  crisis,
  index,
}: {
  crisis: CrisisEvent;
  index: number;
}) {
  const applyChoice = useApplyCrisisChoice();
  const [outcome, setOutcome] = useState<CrisisOutcome | null>(null);
  const [error, setError] = useState<string | null>(null);

  function choose(choiceId: bigint) {
    setError(null);
    applyChoice.mutate(
      { crisisId: crisis.id, choiceId },
      {
        onSuccess: (result) => {
          if (result) setOutcome(result);
          else setError("That choice is no longer available.");
        },
        onError: () => setError("Could not apply that choice. Try again."),
      },
    );
  }

  const resolved = crisis.resolved || outcome !== null;

  return (
    <li
      data-ocid={`weather.crisis.${index + 1}`}
      className="rounded-md border border-border bg-card p-4 shadow-subtle"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <Badge
              variant="outline"
              className="border-destructive/50 bg-destructive/10 font-mono text-[0.6rem] uppercase tracking-widest text-destructive"
            >
              {crisis.kind}
            </Badge>
            {resolved && (
              <Badge
                variant="outline"
                className="border-border bg-secondary font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground"
              >
                Resolved
              </Badge>
            )}
          </div>
          <h3 className="font-display text-base font-semibold text-foreground">
            {crisis.title}
          </h3>
        </div>
        <AlertTriangle
          className="size-5 shrink-0 text-destructive"
          aria-hidden="true"
        />
      </div>

      <p className="mt-2 text-sm text-muted-foreground">{crisis.description}</p>

      {!resolved && (
        <div className="mt-3 space-y-2">
          {crisis.choices.map((choice) => (
            <Button
              key={choice.id.toString()}
              type="button"
              variant="outline"
              data-ocid={`weather.crisis_choice.${index + 1}.${choice.id.toString()}`}
              onClick={() => choose(choice.id)}
              disabled={applyChoice.isPending}
              className="h-auto min-h-11 w-full justify-start rounded-md border-border px-3 py-2 text-left text-sm font-medium transition-smooth hover:border-accent/60 hover:bg-accent/10"
            >
              {choice.name}
            </Button>
          ))}
        </div>
      )}

      {error && (
        <p
          data-ocid={`weather.crisis_error.${index + 1}`}
          role="alert"
          className="mt-3 text-sm text-destructive"
        >
          {error}
        </p>
      )}

      {outcome && <CrisisOutcomeSummary outcome={outcome} />}
    </li>
  );
}

function CrisisList() {
  const { data: crises, isLoading, isError, refetch } = useCrises();

  if (isLoading) {
    return (
      <section
        data-ocid="weather.crises_loading_state"
        className="space-y-3"
        aria-label="Active crises"
      >
        {Array.from({ length: 2 }, (_, i) => `crisis-${i}`).map((id) => (
          <Skeleton key={id} className="h-32 rounded-md" />
        ))}
      </section>
    );
  }

  if (isError) {
    return (
      <div
        data-ocid="weather.crises_error_state"
        className="flex flex-col items-start gap-3 rounded-md border border-destructive/50 bg-destructive/10 p-4"
      >
        <p className="text-sm font-semibold text-destructive">
          Could not load crises
        </p>
        <Button
          type="button"
          variant="outline"
          data-ocid="weather.crises_retry_button"
          onClick={() => void refetch()}
          className="h-11 rounded-md"
        >
          <RefreshCw className="size-4" aria-hidden="true" />
          Retry
        </Button>
      </div>
    );
  }

  const active = (crises ?? []).filter((crisis) => !crisis.resolved);
  const resolved = (crises ?? []).filter((crisis) => crisis.resolved);

  if (!crises || crises.length === 0) {
    return (
      <div
        data-ocid="weather.crises_empty_state"
        className="flex flex-col items-center gap-2 rounded-md border border-dashed border-border bg-card p-6 text-center shadow-subtle"
      >
        <span className="flex size-12 items-center justify-center rounded-full bg-secondary text-[oklch(var(--success))]">
          <Leaf className="size-6" aria-hidden="true" />
        </span>
        <p className="font-display text-base font-semibold text-foreground">
          No active crises
        </p>
        <p className="text-sm text-muted-foreground">
          Your civilization is weathering the age without disaster. New crises
          appear as the simulation advances.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {active.length > 0 && (
        <ul
          data-ocid="weather.crisis_list"
          className="space-y-3"
          aria-label="Active crises"
        >
          {active.map((crisis, index) => (
            <CrisisCard
              key={crisis.id.toString()}
              crisis={crisis}
              index={index}
            />
          ))}
        </ul>
      )}
      {resolved.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
            Resolved
          </h3>
          <ul className="space-y-3" aria-label="Resolved crises">
            {resolved.map((crisis, index) => (
              <CrisisCard
                key={crisis.id.toString()}
                crisis={crisis}
                index={active.length + index}
              />
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Screen                                                              */
/* ------------------------------------------------------------------ */

export default function WeatherScreen() {
  return (
    <ScreenShell
      eyebrow="Environment"
      title="Weather & Crises"
      description="Track real-world weather at your location and respond to active crises."
    >
      <div data-ocid="weather.page" className="flex flex-col gap-4">
        <CurrentConditions />
        <WeatherEffectsPanel />
        <LocationForm />
        <section className="space-y-3">
          <div className="flex items-center gap-2">
            <AlertTriangle
              className="size-4 text-destructive"
              aria-hidden="true"
            />
            <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
              Crises
            </h2>
          </div>
          <CrisisList />
        </section>
      </div>
    </ScreenShell>
  );
}
