import { ScreenShell } from "@/components/ScreenShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useAdvanceEra,
  useGame,
  useMilestones,
  useResearchTechnology,
  useSettlements,
  useTechnologies,
} from "@/hooks/useQueries";
import { ERA_ORDER, eraLabel, formatNumber, nextEra } from "@/lib/game";
import type { Era, EraMilestone, Technology } from "@/types";
import {
  AlertTriangle,
  Check,
  FlaskConical,
  Lock,
  Rocket,
  Sparkles,
} from "lucide-react";
import { useMemo } from "react";

/** The technology that unlocks the space layer. */
const SPACEFLIGHT_TECH_ID = 16n;

type TechState = "researched" | "available" | "blocked";

interface TechView {
  tech: Technology;
  state: TechState;
  missingPrereqs: Technology[];
  affordable: boolean;
}

function techState(
  tech: Technology,
  researched: Set<string>,
  researchPoints: bigint,
  byId: Map<string, Technology>,
): TechView {
  const missingPrereqs = tech.prerequisites
    .filter((id) => !researched.has(id.toString()))
    .map((id) => byId.get(id.toString()))
    .filter((t): t is Technology => t !== undefined);
  const affordable = researchPoints >= tech.cost;

  if (tech.unlocked) {
    return { tech, state: "researched", missingPrereqs: [], affordable };
  }
  if (missingPrereqs.length === 0 && affordable) {
    return { tech, state: "available", missingPrereqs, affordable };
  }
  return { tech, state: "blocked", missingPrereqs, affordable };
}

function TechCard({
  view,
  onResearch,
  pending,
}: {
  view: TechView;
  onResearch: (id: bigint) => void;
  pending: boolean;
}) {
  const { tech, state, missingPrereqs, affordable } = view;
  const isSpaceflight = tech.id === SPACEFLIGHT_TECH_ID;

  const reason =
    state === "blocked"
      ? missingPrereqs.length > 0
        ? `Requires ${missingPrereqs.map((t) => t.name).join(", ")}`
        : `Needs ${formatNumber(tech.cost)} research points`
      : null;

  return (
    <li
      data-ocid={`technology.item.${tech.id.toString()}`}
      className={`flex flex-col gap-2 rounded-md border p-3 shadow-subtle transition-smooth ${
        state === "researched"
          ? "border-success/50 bg-success/10"
          : state === "available"
            ? "border-primary/50 bg-card"
            : "border-border bg-card"
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex min-w-0 items-start gap-2">
          <span
            aria-hidden="true"
            className={`mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-sm border ${
              state === "researched"
                ? "border-success/60 bg-success/20 text-success"
                : "border-border bg-background/60 text-muted-foreground"
            }`}
          >
            {state === "researched" ? (
              <Check className="size-3.5" />
            ) : isSpaceflight ? (
              <Rocket className="size-3.5" />
            ) : (
              <FlaskConical className="size-3.5" />
            )}
          </span>
          <div className="min-w-0">
            <p className="truncate font-display text-sm font-semibold text-foreground">
              {tech.name}
            </p>
            <p className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
              {eraLabel(tech.era)} · {formatNumber(tech.cost)} pts
            </p>
          </div>
        </div>
        {state === "researched" ? (
          <Badge
            variant="outline"
            className="shrink-0 border-success/50 bg-success/15 font-mono text-[0.6rem] uppercase tracking-widest text-success"
          >
            Researched
          </Badge>
        ) : state === "available" ? (
          <Badge
            variant="outline"
            className="shrink-0 border-primary/50 bg-primary/15 font-mono text-[0.6rem] uppercase tracking-widest text-primary"
          >
            Ready
          </Badge>
        ) : (
          <Badge
            variant="outline"
            className="shrink-0 gap-1 border-border font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground"
          >
            <Lock className="size-3" aria-hidden="true" />
            Locked
          </Badge>
        )}
      </div>

      {isSpaceflight && (
        <p className="flex items-center gap-1.5 text-xs text-accent">
          <Rocket className="size-3.5 shrink-0" aria-hidden="true" />
          Unlocks the space exploration layer.
        </p>
      )}

      {reason && (
        <p
          className="text-xs text-muted-foreground"
          data-ocid={`technology.reason.${tech.id.toString()}`}
        >
          {reason}
        </p>
      )}

      {state !== "researched" && (
        <Button
          type="button"
          size="sm"
          variant={state === "available" ? "default" : "outline"}
          data-ocid={`technology.research_button.${tech.id.toString()}`}
          disabled={state !== "available" || pending}
          onClick={() => onResearch(tech.id)}
          className="h-11 w-full rounded-md font-display text-xs font-semibold uppercase tracking-widest"
        >
          {pending
            ? "Researching…"
            : state === "available"
              ? `Research · ${formatNumber(tech.cost)} pts`
              : affordable
                ? "Prerequisites missing"
                : "Not enough points"}
        </Button>
      )}
    </li>
  );
}

function MilestonePanel({
  milestone,
  currentEra,
  researched,
  byId,
  population,
  buildings,
  onAdvance,
  pending,
  isFinalEra,
}: {
  milestone: EraMilestone;
  currentEra: Era;
  researched: Set<string>;
  byId: Map<string, Technology>;
  population: bigint;
  buildings: bigint;
  onAdvance: () => void;
  pending: boolean;
  isFinalEra: boolean;
}) {
  const isCurrent = milestone.era === currentEra;
  const techsMet = milestone.requiredTechs.every((id) =>
    researched.has(id.toString()),
  );
  const populationMet = population >= milestone.requiredPopulation;
  const buildingsMet = buildings >= milestone.requiredBuildings;
  const allMet = techsMet && populationMet && buildingsMet;

  const missingTechs = milestone.requiredTechs
    .filter((id) => !researched.has(id.toString()))
    .map((id) => byId.get(id.toString())?.name ?? `Tech ${id.toString()}`);

  const requirements = [
    {
      key: "techs",
      label: "Technologies",
      met: techsMet,
      detail: techsMet
        ? `${milestone.requiredTechs.length} researched`
        : `Missing ${missingTechs.join(", ")}`,
    },
    {
      key: "population",
      label: "Population",
      met: populationMet,
      detail: `${formatNumber(population)} / ${formatNumber(milestone.requiredPopulation)}`,
    },
    {
      key: "buildings",
      label: "Buildings",
      met: buildingsMet,
      detail: `${formatNumber(buildings)} / ${formatNumber(milestone.requiredBuildings)}`,
    },
  ];

  return (
    <li
      data-ocid={`technology.milestone.${milestone.era}`}
      className={`flex flex-col gap-3 rounded-md border p-3 shadow-subtle ${
        isCurrent ? "border-accent/50 bg-card" : "border-border bg-card/60"
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <p className="font-display text-sm font-semibold text-foreground">
          {eraLabel(milestone.era)}
        </p>
        {isCurrent ? (
          <Badge
            variant="outline"
            className="border-accent/50 bg-accent/15 font-mono text-[0.6rem] uppercase tracking-widest text-accent"
          >
            Current
          </Badge>
        ) : (
          <Badge
            variant="outline"
            className="border-border font-mono text-[0.6rem] uppercase tracking-widest text-muted-foreground"
          >
            {allMet ? "Complete" : "Locked"}
          </Badge>
        )}
      </div>

      <ul className="flex flex-col gap-1.5">
        {requirements.map((req) => (
          <li
            key={req.key}
            data-ocid={`technology.milestone.${milestone.era}.${req.key}`}
            className="flex items-center justify-between gap-2 text-xs"
          >
            <span className="flex items-center gap-1.5 text-muted-foreground">
              <span
                aria-hidden="true"
                className={`flex size-4 items-center justify-center rounded-sm border ${
                  req.met
                    ? "border-success/60 bg-success/20 text-success"
                    : "border-border text-muted-foreground"
                }`}
              >
                {req.met ? <Check className="size-3" /> : null}
              </span>
              {req.label}
            </span>
            <span
              className={`font-mono tabular-nums ${
                req.met ? "text-success" : "text-muted-foreground"
              }`}
            >
              {req.detail}
            </span>
          </li>
        ))}
      </ul>

      {isCurrent && (
        <Button
          type="button"
          data-ocid="technology.advance_era_button"
          disabled={!allMet || pending || isFinalEra}
          onClick={onAdvance}
          className="h-11 w-full rounded-md bg-primary font-display text-xs font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110"
        >
          {isFinalEra
            ? "Final era reached"
            : pending
              ? "Advancing…"
              : allMet
                ? `Advance to ${eraLabel(nextEra(milestone.era) ?? milestone.era)}`
                : "Requirements not met"}
        </Button>
      )}
    </li>
  );
}

function LoadingState() {
  const ids = Array.from({ length: 4 }, (_, i) => `tech-skeleton-${i}`);
  return (
    <div data-ocid="technology.loading_state" className="flex flex-col gap-3">
      {ids.map((id) => (
        <div
          key={id}
          className="flex flex-col gap-2 rounded-md border border-border bg-card p-3"
        >
          <Skeleton className="h-4 w-1/2" />
          <Skeleton className="h-3 w-1/3" />
          <Skeleton className="h-11 w-full" />
        </div>
      ))}
    </div>
  );
}

export default function TechnologyScreen() {
  const technologies = useTechnologies();
  const milestones = useMilestones();
  const game = useGame();
  const settlements = useSettlements();
  const research = useResearchTechnology();
  const advanceEra = useAdvanceEra();

  const techList = technologies.data ?? [];
  const milestoneList = milestones.data ?? [];
  const currentEra = game.data?.civilization.era;
  const researchPoints = game.data?.civilization.researchPoints ?? 0n;

  const byId = useMemo(() => {
    const map = new Map<string, Technology>();
    for (const tech of techList) map.set(tech.id.toString(), tech);
    return map;
  }, [techList]);

  const researched = useMemo(() => {
    const set = new Set<string>();
    for (const tech of techList) {
      if (tech.unlocked) set.add(tech.id.toString());
    }
    return set;
  }, [techList]);

  const grouped = useMemo(() => {
    return ERA_ORDER.map((era) => ({
      era,
      items: techList
        .filter((tech) => tech.era === era)
        .map((tech) => techState(tech, researched, researchPoints, byId)),
    })).filter((group) => group.items.length > 0);
  }, [techList, researched, researchPoints, byId]);

  const population = useMemo(
    () => (settlements.data ?? []).reduce((acc, s) => acc + s.population, 0n),
    [settlements.data],
  );
  const buildings = useMemo(
    () =>
      (settlements.data ?? []).reduce(
        (acc, s) => acc + BigInt(s.buildings.length),
        0n,
      ),
    [settlements.data],
  );

  const isLoading =
    technologies.isLoading || milestones.isLoading || game.isLoading;
  const isError = technologies.isError || milestones.isError || game.isError;
  const isEmpty = !isLoading && !isError && techList.length === 0;

  const actionError =
    research.isError || advanceEra.isError
      ? "The last action could not be completed. Please try again."
      : null;

  return (
    <ScreenShell
      eyebrow="Exploit"
      title="Technology & Eras"
      description="Research technologies, track era milestones, and advance your civilization."
    >
      {isLoading ? (
        <LoadingState />
      ) : isError ? (
        <div
          data-ocid="technology.error_state"
          className="flex flex-col items-center gap-3 rounded-md border border-destructive/50 bg-destructive/10 p-6 text-center"
        >
          <AlertTriangle
            className="size-6 text-destructive"
            aria-hidden="true"
          />
          <p className="text-sm text-foreground">
            The technology tree could not be loaded.
          </p>
          <Button
            type="button"
            variant="outline"
            data-ocid="technology.retry_button"
            onClick={() => {
              void technologies.refetch();
              void milestones.refetch();
              void game.refetch();
            }}
            className="h-11 rounded-md font-display text-xs font-semibold uppercase tracking-widest"
          >
            Retry
          </Button>
        </div>
      ) : isEmpty ? (
        <div
          data-ocid="technology.empty_state"
          className="flex flex-col items-center gap-3 rounded-md border border-border bg-card p-6 text-center shadow-subtle"
        >
          <Sparkles className="size-6 text-accent" aria-hidden="true" />
          <p className="text-sm text-muted-foreground">
            No technologies are available yet. Start a game to open the research
            tree.
          </p>
        </div>
      ) : (
        <>
          <section
            data-ocid="technology.research_panel"
            className="flex items-center justify-between gap-3 rounded-md border border-border bg-card p-3 shadow-subtle"
          >
            <div className="flex items-center gap-2">
              <FlaskConical
                className="size-4 text-primary"
                aria-hidden="true"
              />
              <span className="font-display text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Research Points
              </span>
            </div>
            <span className="font-mono text-lg font-semibold tabular-nums text-primary">
              {formatNumber(researchPoints)}
            </span>
          </section>

          {actionError && (
            <p
              data-ocid="technology.action_error"
              className="rounded-md border border-destructive/50 bg-destructive/10 px-3 py-2 text-xs text-destructive"
            >
              {actionError}
            </p>
          )}

          <section
            data-ocid="technology.tree_section"
            className="flex flex-col gap-4"
          >
            <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
              Technology Tree
            </h2>
            {grouped.map((group) => (
              <div
                key={group.era}
                data-ocid={`technology.era_group.${group.era}`}
                className="flex flex-col gap-2"
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[0.65rem] font-semibold uppercase tracking-widest text-accent">
                    {eraLabel(group.era)}
                  </span>
                  <span className="h-px flex-1 bg-border" aria-hidden="true" />
                  <span className="font-mono text-[0.65rem] tabular-nums text-muted-foreground">
                    {group.items.filter((v) => v.state === "researched").length}
                    /{group.items.length}
                  </span>
                </div>
                <ul className="flex flex-col gap-2">
                  {group.items.map((view) => (
                    <TechCard
                      key={view.tech.id.toString()}
                      view={view}
                      pending={research.isPending}
                      onResearch={(id) => research.mutate(id)}
                    />
                  ))}
                </ul>
              </div>
            ))}
          </section>

          <section
            data-ocid="technology.milestones_section"
            className="flex flex-col gap-3"
          >
            <h2 className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
              Era Milestones
            </h2>
            {milestoneList.length === 0 ? (
              <p className="rounded-md border border-border bg-card p-3 text-sm text-muted-foreground">
                No era milestones are defined.
              </p>
            ) : (
              <ul className="flex flex-col gap-3">
                {milestoneList.map((milestone) => (
                  <MilestonePanel
                    key={milestone.era}
                    milestone={milestone}
                    currentEra={currentEra ?? milestone.era}
                    researched={researched}
                    byId={byId}
                    population={population}
                    buildings={buildings}
                    pending={advanceEra.isPending}
                    isFinalEra={nextEra(milestone.era) === null}
                    onAdvance={() => advanceEra.mutate()}
                  />
                ))}
              </ul>
            )}
          </section>
        </>
      )}
    </ScreenShell>
  );
}
