import { ScreenShell } from "@/components/ScreenShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useAcceptTradeCounter,
  useCancelTradeAgreement,
  useCancelTradeOffer,
  useCreateTradeAgreement,
  useOpenTradeOffer,
  useRivals,
  useTradeAgreements,
  useTradeHistory,
  useTradeOffers,
} from "@/hooks/useQueries";
import {
  RESOURCE_LABELS,
  RESOURCE_ORDER,
  formatBundle,
  formatNumber,
  tradeStatusLabel,
  tradeStatusTone,
} from "@/lib/game";
import type {
  ResourceBundle,
  ResourcePool,
  Rival,
  RivalId,
  StandingAgreement,
  TradeHistoryEntry,
  TradeOffer,
} from "@/types";
import { TradeStatus } from "@/types";
import { Handshake, Inbox, ScrollText, Send, X } from "lucide-react";
import { useMemo, useState } from "react";

type BundleKey = keyof ResourcePool;

const TONE_CLASSES: Record<ReturnType<typeof tradeStatusTone>, string> = {
  positive: "border-success/50 bg-success/15 text-success",
  negative: "border-destructive/50 bg-destructive/15 text-destructive",
  pending: "border-primary/50 bg-primary/15 text-primary",
  neutral: "border-border bg-secondary text-muted-foreground",
};

function emptyBundle(): ResourceBundle {
  return {
    food: 0n,
    production: 0n,
    science: 0n,
    gold: 0n,
    culture: 0n,
    influence: 0n,
  };
}

function bundleFromDraft(draft: Record<BundleKey, string>): ResourceBundle {
  const bundle = emptyBundle();
  for (const key of RESOURCE_ORDER) {
    const parsed = Number.parseInt(draft[key], 10);
    bundle[key] = Number.isFinite(parsed) && parsed > 0 ? BigInt(parsed) : 0n;
  }
  return bundle;
}

function bundleIsEmpty(bundle: ResourceBundle): boolean {
  return RESOURCE_ORDER.every((key) => bundle[key] === 0n);
}

function StatusBadge({ status }: { status: TradeStatus }) {
  return (
    <Badge
      variant="outline"
      className={`font-mono text-[0.65rem] uppercase tracking-widest ${TONE_CLASSES[tradeStatusTone(status)]}`}
    >
      {tradeStatusLabel(status)}
    </Badge>
  );
}

function BundleEditor({
  idPrefix,
  draft,
  onChange,
}: {
  idPrefix: string;
  draft: Record<BundleKey, string>;
  onChange: (key: BundleKey, value: string) => void;
}) {
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
      {RESOURCE_ORDER.map((key) => (
        <div key={key} className="space-y-1">
          <Label
            htmlFor={`${idPrefix}.${key}`}
            className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground"
          >
            {RESOURCE_LABELS[key]}
          </Label>
          <Input
            id={`${idPrefix}.${key}`}
            data-ocid={`${idPrefix}.${key}`}
            type="number"
            inputMode="numeric"
            min={0}
            value={draft[key]}
            onChange={(event) => onChange(key, event.target.value)}
            className="h-11 rounded-md bg-background font-mono tabular-nums"
          />
        </div>
      ))}
    </div>
  );
}

function BundleSummary({ bundle }: { bundle: ResourceBundle }) {
  return (
    <span className="font-mono text-xs tabular-nums text-foreground">
      {formatBundle(bundle)}
    </span>
  );
}

function OfferCard({ offer }: { offer: TradeOffer }) {
  const acceptCounter = useAcceptTradeCounter();
  const cancelOffer = useCancelTradeOffer();
  const countered = offer.status === TradeStatus.countered;
  const pending = offer.status === TradeStatus.pending;

  return (
    <Card
      data-ocid={`trade.offer.${offer.id.toString()}`}
      className="rounded-lg border-border bg-card shadow-none"
    >
      <CardHeader className="gap-2 pb-3">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="font-display text-sm font-semibold uppercase tracking-widest text-foreground">
            Offer #{formatNumber(offer.id)}
          </CardTitle>
          <StatusBadge status={offer.status} />
        </div>
        <p className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
          Opened turn {formatNumber(offer.createdTick)}
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid gap-2 sm:grid-cols-2">
          <div className="rounded-md border border-border bg-background/60 p-2">
            <p className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
              You offer
            </p>
            <BundleSummary bundle={offer.offered} />
            <p className="mt-1 font-mono text-xs tabular-nums text-primary">
              + {formatNumber(offer.gold)} gold
            </p>
          </div>
          <div className="rounded-md border border-border bg-background/60 p-2">
            <p className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
              You request
            </p>
            <BundleSummary bundle={offer.requested} />
          </div>
        </div>

        {countered && (
          <div
            data-ocid={`trade.counter.${offer.id.toString()}`}
            className="space-y-2 rounded-md border border-primary/50 bg-primary/10 p-3"
          >
            <p className="font-display text-xs font-semibold uppercase tracking-widest text-primary">
              Counter-offer received
            </p>
            <p className="text-sm text-foreground">
              They now offer <BundleSummary bundle={offer.requested} /> and
              request <BundleSummary bundle={offer.offered} />.
            </p>
            <p className="text-xs italic text-muted-foreground">
              “We can move on these terms — the balance favours us this season.”
            </p>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button
                type="button"
                data-ocid={`trade.accept_counter_button.${offer.id.toString()}`}
                onClick={() => acceptCounter.mutate(offer.id)}
                disabled={acceptCounter.isPending}
                className="h-11 flex-1 rounded-md bg-primary font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110"
              >
                {acceptCounter.isPending ? "Accepting…" : "Accept counter"}
              </Button>
              <Button
                type="button"
                variant="outline"
                data-ocid={`trade.cancel_offer_button.${offer.id.toString()}`}
                onClick={() => cancelOffer.mutate(offer.id)}
                disabled={cancelOffer.isPending}
                className="h-11 flex-1 rounded-md border-border font-display text-sm font-semibold uppercase tracking-widest text-foreground transition-smooth hover:bg-secondary"
              >
                {cancelOffer.isPending ? "Cancelling…" : "Cancel"}
              </Button>
            </div>
          </div>
        )}

        {pending && (
          <Button
            type="button"
            variant="outline"
            data-ocid={`trade.cancel_offer_button.${offer.id.toString()}`}
            onClick={() => cancelOffer.mutate(offer.id)}
            disabled={cancelOffer.isPending}
            className="h-11 w-full rounded-md border-border font-display text-sm font-semibold uppercase tracking-widest text-foreground transition-smooth hover:bg-secondary"
          >
            {cancelOffer.isPending ? "Cancelling…" : "Withdraw offer"}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

function OpenOfferForm({ rivals }: { rivals: Rival[] }) {
  const openOffer = useOpenTradeOffer();
  const [partnerId, setPartnerId] = useState<string>("");
  const [offered, setOffered] = useState<Record<BundleKey, string>>(
    () =>
      Object.fromEntries(RESOURCE_ORDER.map((key) => [key, "0"])) as Record<
        BundleKey,
        string
      >,
  );
  const [requested, setRequested] = useState<Record<BundleKey, string>>(
    () =>
      Object.fromEntries(RESOURCE_ORDER.map((key) => [key, "0"])) as Record<
        BundleKey,
        string
      >,
  );
  const [gold, setGold] = useState("0");

  const offeredBundle = useMemo(() => bundleFromDraft(offered), [offered]);
  const requestedBundle = useMemo(
    () => bundleFromDraft(requested),
    [requested],
  );
  const goldValue = useMemo(() => {
    const parsed = Number.parseInt(gold, 10);
    return Number.isFinite(parsed) && parsed > 0 ? BigInt(parsed) : 0n;
  }, [gold]);

  const nothingToTrade =
    bundleIsEmpty(offeredBundle) &&
    bundleIsEmpty(requestedBundle) &&
    goldValue === 0n;
  const canSubmit = partnerId !== "" && !nothingToTrade;

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canSubmit) return;
    const capturedPartner = BigInt(partnerId);
    const capturedOffered = offeredBundle;
    const capturedRequested = requestedBundle;
    const capturedGold = goldValue;
    openOffer.mutate(
      {
        partnerId: capturedPartner,
        offered: capturedOffered,
        requested: capturedRequested,
        gold: capturedGold,
      },
      {
        onSuccess: () => {
          setOffered(
            Object.fromEntries(
              RESOURCE_ORDER.map((key) => [key, "0"]),
            ) as Record<BundleKey, string>,
          );
          setRequested(
            Object.fromEntries(
              RESOURCE_ORDER.map((key) => [key, "0"]),
            ) as Record<BundleKey, string>,
          );
          setGold("0");
        },
      },
    );
  }

  return (
    <Card
      data-ocid="trade.open_offer.panel"
      className="rounded-lg border-border bg-card shadow-none"
    >
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          <Send className="size-4 text-primary" aria-hidden="true" />
          Open a trade offer
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <Label
              htmlFor="trade.partner_select"
              className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground"
            >
              Trade partner
            </Label>
            <select
              id="trade.partner_select"
              data-ocid="trade.partner_select"
              value={partnerId}
              onChange={(event) => setPartnerId(event.target.value)}
              className="h-11 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground transition-smooth focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
            >
              <option value="">Select a rival…</option>
              {rivals.map((rival) => (
                <option key={rival.id.toString()} value={rival.id.toString()}>
                  {rival.name}
                </option>
              ))}
            </select>
          </div>

          <fieldset className="space-y-2">
            <legend className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
              You offer
            </legend>
            <BundleEditor
              idPrefix="trade.offer_input"
              draft={offered}
              onChange={(key, value) =>
                setOffered((current) => ({ ...current, [key]: value }))
              }
            />
            <div className="space-y-1">
              <Label
                htmlFor="trade.offer_gold"
                className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground"
              >
                Gold sweetener
              </Label>
              <Input
                id="trade.offer_gold"
                data-ocid="trade.offer_gold"
                type="number"
                inputMode="numeric"
                min={0}
                value={gold}
                onChange={(event) => setGold(event.target.value)}
                className="h-11 rounded-md bg-background font-mono tabular-nums"
              />
            </div>
          </fieldset>

          <fieldset className="space-y-2">
            <legend className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
              You request
            </legend>
            <BundleEditor
              idPrefix="trade.request_input"
              draft={requested}
              onChange={(key, value) =>
                setRequested((current) => ({ ...current, [key]: value }))
              }
            />
          </fieldset>

          {openOffer.isError && (
            <p
              data-ocid="trade.open_offer.error_state"
              className="text-sm text-destructive"
            >
              Could not open the offer. Check your resources and try again.
            </p>
          )}

          <Button
            type="submit"
            data-ocid="trade.open_offer.submit_button"
            disabled={!canSubmit || openOffer.isPending}
            className="h-11 w-full rounded-md bg-primary font-display text-sm font-semibold uppercase tracking-widest text-primary-foreground transition-smooth hover:brightness-110 disabled:opacity-60"
          >
            {openOffer.isPending ? "Sending…" : "Send offer"}
          </Button>
          {!canSubmit && (
            <p className="text-center text-xs text-muted-foreground">
              Choose a partner and include at least one resource or gold.
            </p>
          )}
        </form>
      </CardContent>
    </Card>
  );
}

function AgreementForm({ rivals }: { rivals: Rival[] }) {
  const createAgreement = useCreateTradeAgreement();
  const [partnerId, setPartnerId] = useState<string>("");
  const [perTick, setPerTick] = useState<Record<BundleKey, string>>(
    () =>
      Object.fromEntries(RESOURCE_ORDER.map((key) => [key, "0"])) as Record<
        BundleKey,
        string
      >,
  );
  const [goldPerTick, setGoldPerTick] = useState("0");

  const perTickBundle = useMemo(() => bundleFromDraft(perTick), [perTick]);
  const goldValue = useMemo(() => {
    const parsed = Number.parseInt(goldPerTick, 10);
    return Number.isFinite(parsed) && parsed > 0 ? BigInt(parsed) : 0n;
  }, [goldPerTick]);

  const nothingToTrade = bundleIsEmpty(perTickBundle) && goldValue === 0n;
  const canSubmit = partnerId !== "" && !nothingToTrade;

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canSubmit) return;
    createAgreement.mutate(
      {
        partnerId: BigInt(partnerId),
        perTick: perTickBundle,
        goldPerTick: goldValue,
      },
      {
        onSuccess: () => {
          setPerTick(
            Object.fromEntries(
              RESOURCE_ORDER.map((key) => [key, "0"]),
            ) as Record<BundleKey, string>,
          );
          setGoldPerTick("0");
        },
      },
    );
  }

  return (
    <Card
      data-ocid="trade.agreement_form.panel"
      className="rounded-lg border-border bg-card shadow-none"
    >
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 font-display text-sm font-semibold uppercase tracking-widest text-foreground">
          <Handshake className="size-4 text-accent" aria-hidden="true" />
          New standing agreement
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <Label
              htmlFor="trade.agreement_partner_select"
              className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground"
            >
              Partner
            </Label>
            <select
              id="trade.agreement_partner_select"
              data-ocid="trade.agreement_partner_select"
              value={partnerId}
              onChange={(event) => setPartnerId(event.target.value)}
              className="h-11 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground transition-smooth focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
            >
              <option value="">Select a rival…</option>
              {rivals.map((rival) => (
                <option key={rival.id.toString()} value={rival.id.toString()}>
                  {rival.name}
                </option>
              ))}
            </select>
          </div>

          <fieldset className="space-y-2">
            <legend className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">
              Received every tick
            </legend>
            <BundleEditor
              idPrefix="trade.agreement_input"
              draft={perTick}
              onChange={(key, value) =>
                setPerTick((current) => ({ ...current, [key]: value }))
              }
            />
            <div className="space-y-1">
              <Label
                htmlFor="trade.agreement_gold"
                className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground"
              >
                Gold per tick
              </Label>
              <Input
                id="trade.agreement_gold"
                data-ocid="trade.agreement_gold"
                type="number"
                inputMode="numeric"
                min={0}
                value={goldPerTick}
                onChange={(event) => setGoldPerTick(event.target.value)}
                className="h-11 rounded-md bg-background font-mono tabular-nums"
              />
            </div>
          </fieldset>

          {createAgreement.isError && (
            <p
              data-ocid="trade.agreement_form.error_state"
              className="text-sm text-destructive"
            >
              Could not create the agreement. Try again.
            </p>
          )}

          <Button
            type="submit"
            data-ocid="trade.agreement_form.submit_button"
            disabled={!canSubmit || createAgreement.isPending}
            className="h-11 w-full rounded-md bg-accent font-display text-sm font-semibold uppercase tracking-widest text-accent-foreground transition-smooth hover:brightness-110 disabled:opacity-60"
          >
            {createAgreement.isPending ? "Creating…" : "Create agreement"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

function AgreementRow({
  agreement,
  partnerName,
}: {
  agreement: StandingAgreement;
  partnerName: string;
}) {
  const cancelAgreement = useCancelTradeAgreement();
  return (
    <li
      data-ocid={`trade.agreement.${agreement.id.toString()}`}
      className="flex flex-col gap-2 rounded-md border border-border bg-background/60 p-3 sm:flex-row sm:items-center sm:justify-between"
    >
      <div className="min-w-0 space-y-1">
        <div className="flex items-center gap-2">
          <span className="truncate font-display text-sm font-semibold text-foreground">
            {partnerName}
          </span>
          <Badge
            variant="outline"
            className={`font-mono text-[0.6rem] uppercase tracking-widest ${
              agreement.active
                ? "border-success/50 bg-success/15 text-success"
                : "border-border bg-secondary text-muted-foreground"
            }`}
          >
            {agreement.active ? "Active" : "Ended"}
          </Badge>
        </div>
        <p className="font-mono text-xs tabular-nums text-muted-foreground">
          {formatBundle(agreement.perTick)} ·{" "}
          {formatNumber(agreement.goldPerTick)} gold / tick
        </p>
        <p className="font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
          Since turn {formatNumber(agreement.startedTick)}
        </p>
      </div>
      {agreement.active && (
        <Button
          type="button"
          variant="outline"
          data-ocid={`trade.cancel_agreement_button.${agreement.id.toString()}`}
          onClick={() => cancelAgreement.mutate(agreement.id)}
          disabled={cancelAgreement.isPending}
          className="h-11 shrink-0 rounded-md border-border font-display text-xs font-semibold uppercase tracking-widest text-foreground transition-smooth hover:bg-secondary"
        >
          {cancelAgreement.isPending ? "Ending…" : "End agreement"}
        </Button>
      )}
    </li>
  );
}

function HistoryRow({
  entry,
  partnerName,
}: {
  entry: TradeHistoryEntry;
  partnerName: string;
}) {
  return (
    <li
      data-ocid={`trade.history.${entry.tick.toString()}`}
      className="space-y-1 rounded-md border border-border bg-background/60 p-3"
    >
      <div className="flex items-center justify-between gap-2">
        <span className="truncate font-display text-sm font-semibold text-foreground">
          {partnerName}
        </span>
        <span className="shrink-0 font-mono text-[0.65rem] uppercase tracking-widest text-muted-foreground">
          Turn {formatNumber(entry.tick)}
        </span>
      </div>
      <p className="text-sm text-muted-foreground">{entry.summary}</p>
      <p className="font-mono text-xs tabular-nums text-muted-foreground">
        Gave {formatBundle(entry.offered)} · {formatNumber(entry.gold)} gold ·
        Got {formatBundle(entry.requested)}
      </p>
    </li>
  );
}

function LoadingList() {
  const ids = Array.from({ length: 3 }, (_, i) => `trade-skeleton-${i}`);
  return (
    <div data-ocid="trade.loading_state" className="space-y-2">
      {ids.map((id) => (
        <Skeleton key={id} className="h-24 w-full rounded-md" />
      ))}
    </div>
  );
}

function EmptyState({
  ocid,
  icon,
  title,
  body,
}: {
  ocid: string;
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <div
      data-ocid={ocid}
      className="flex flex-col items-center gap-2 rounded-md border border-dashed border-border bg-card/60 px-4 py-8 text-center"
    >
      <span className="text-muted-foreground" aria-hidden="true">
        {icon}
      </span>
      <p className="font-display text-sm font-semibold text-foreground">
        {title}
      </p>
      <p className="max-w-xs text-xs text-muted-foreground">{body}</p>
    </div>
  );
}

export default function TradeScreen() {
  const rivalsQuery = useRivals();
  const offersQuery = useTradeOffers();
  const historyQuery = useTradeHistory();
  const agreementsQuery = useTradeAgreements();

  const rivals = rivalsQuery.data ?? [];
  const rivalNames = useMemo(() => {
    const map = new Map<string, string>();
    for (const rival of rivals) map.set(rival.id.toString(), rival.name);
    return map;
  }, [rivals]);

  const partnerName = (id: RivalId) =>
    rivalNames.get(id.toString()) ?? `Rival #${id.toString()}`;

  const offers = offersQuery.data ?? [];
  const history = historyQuery.data ?? [];
  const agreements = agreementsQuery.data ?? [];

  const activeOffers = offers.filter(
    (offer) =>
      offer.status === TradeStatus.pending ||
      offer.status === TradeStatus.countered,
  );
  const settledOffers = offers.filter(
    (offer) =>
      offer.status !== TradeStatus.pending &&
      offer.status !== TradeStatus.countered,
  );

  return (
    <ScreenShell
      eyebrow="Exploit"
      title="Trade"
      description="Open offers with known rivals, review counters, and manage standing agreements."
    >
      <div className="space-y-6">
        {rivalsQuery.isLoading ? (
          <LoadingList />
        ) : rivals.length === 0 ? (
          <EmptyState
            ocid="trade.no_rivals_state"
            icon={<Inbox className="size-6" />}
            title="No rivals discovered"
            body="Explore the map to meet other civilizations before you can trade."
          />
        ) : (
          <OpenOfferForm rivals={rivals} />
        )}

        <section className="space-y-3" aria-labelledby="trade-offers-heading">
          <h2
            id="trade-offers-heading"
            className="font-display text-sm font-semibold uppercase tracking-widest text-foreground"
          >
            Active offers
          </h2>
          {offersQuery.isLoading ? (
            <LoadingList />
          ) : offersQuery.isError ? (
            <p
              data-ocid="trade.offers.error_state"
              className="rounded-md border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive"
            >
              Could not load your trade offers.
            </p>
          ) : activeOffers.length === 0 ? (
            <EmptyState
              ocid="trade.offers.empty_state"
              icon={<Send className="size-6" />}
              title="No open offers"
              body="Send an offer above and it will appear here while your rival decides."
            />
          ) : (
            <div className="space-y-3">
              {activeOffers.map((offer) => (
                <OfferCard key={offer.id.toString()} offer={offer} />
              ))}
            </div>
          )}
        </section>

        {settledOffers.length > 0 && (
          <section
            className="space-y-3"
            aria-labelledby="trade-settled-heading"
          >
            <h2
              id="trade-settled-heading"
              className="font-display text-sm font-semibold uppercase tracking-widest text-foreground"
            >
              Settled offers
            </h2>
            <div className="space-y-3">
              {settledOffers.map((offer) => (
                <OfferCard key={offer.id.toString()} offer={offer} />
              ))}
            </div>
          </section>
        )}

        <section
          className="space-y-3"
          aria-labelledby="trade-agreements-heading"
        >
          <h2
            id="trade-agreements-heading"
            className="font-display text-sm font-semibold uppercase tracking-widest text-foreground"
          >
            Standing agreements
          </h2>
          {rivals.length > 0 && <AgreementForm rivals={rivals} />}
          {agreementsQuery.isLoading ? (
            <LoadingList />
          ) : agreementsQuery.isError ? (
            <p
              data-ocid="trade.agreements.error_state"
              className="rounded-md border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive"
            >
              Could not load your standing agreements.
            </p>
          ) : agreements.length === 0 ? (
            <EmptyState
              ocid="trade.agreements.empty_state"
              icon={<Handshake className="size-6" />}
              title="No standing agreements"
              body="Set up a recurring exchange that delivers resources every tick."
            />
          ) : (
            <ul className="space-y-2">
              {agreements.map((agreement) => (
                <AgreementRow
                  key={agreement.id.toString()}
                  agreement={agreement}
                  partnerName={partnerName(agreement.partner)}
                />
              ))}
            </ul>
          )}
        </section>

        <section className="space-y-3" aria-labelledby="trade-history-heading">
          <h2
            id="trade-history-heading"
            className="font-display text-sm font-semibold uppercase tracking-widest text-foreground"
          >
            Trade history
          </h2>
          {historyQuery.isLoading ? (
            <LoadingList />
          ) : historyQuery.isError ? (
            <p
              data-ocid="trade.history.error_state"
              className="rounded-md border border-destructive/50 bg-destructive/10 p-3 text-sm text-destructive"
            >
              Could not load your trade history.
            </p>
          ) : history.length === 0 ? (
            <EmptyState
              ocid="trade.history.empty_state"
              icon={<ScrollText className="size-6" />}
              title="No completed trades yet"
              body="Accepted offers and recurring deliveries will be logged here."
            />
          ) : (
            <ul className="space-y-2">
              {history.map((entry) => (
                <HistoryRow
                  key={`${entry.tick.toString()}-${entry.partner.toString()}-${entry.summary}`}
                  entry={entry}
                  partnerName={partnerName(entry.partner)}
                />
              ))}
            </ul>
          )}
        </section>
      </div>
    </ScreenShell>
  );
}
