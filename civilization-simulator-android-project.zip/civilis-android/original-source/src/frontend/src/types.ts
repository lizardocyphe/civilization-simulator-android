import type {
  ActionResult,
  AiActivity,
  AiDecision,
  Building,
  BuildingId,
  Civilization,
  CombatResult,
  CrisisChoice,
  CrisisEffect,
  CrisisEvent,
  CrisisId,
  DiscussionMessage,
  EconomicPolicy,
  EconomyState,
  EconomyTick,
  EraMilestone,
  Fleet,
  GameId,
  GameState,
  GeoLocation,
  HexCoord,
  HexMap,
  Policy,
  Proposal,
  Resolution,
  ResourceBundle,
  ResourceNode,
  ResourcePocket,
  ResourcePool,
  Rival,
  RivalId,
  Settlement,
  SettlementId,
  SpaceBattleResult,
  StandingAgreement,
  StarSystem,
  TechId,
  Technology,
  Terrain,
  Tile,
  TileId,
  TradeHistoryEntry,
  TradeOffer,
  TurnSummary,
  Unit,
  UnitId,
  Vote,
  WeatherState,
} from "@/backend";

// Backend enums are runtime values — re-export them as values so pages can use
// `Era.ancient`, `Terrain.ocean`, `AiDifficulty.balanced`, etc. in switches and
// comparisons.
export {
  AiActionKind,
  AiDifficulty,
  DiplomaticStance,
  Era,
  FogState,
  PocketKind,
  ProposalKind,
  ProposalStatus,
  Terrain,
  TradeStatus,
  UserRole,
} from "@/backend";

export type {
  ActionResult,
  AiActivity,
  AiDecision,
  Building,
  BuildingId,
  Civilization,
  CombatResult,
  CrisisChoice,
  CrisisEffect,
  CrisisEvent,
  CrisisId,
  DiscussionMessage,
  EconomicPolicy,
  EconomyState,
  EconomyTick,
  EraMilestone,
  Fleet,
  GameId,
  GameState,
  GeoLocation,
  HexCoord,
  HexMap,
  Policy,
  Proposal,
  Resolution,
  ResourceBundle,
  ResourceNode,
  ResourcePocket,
  ResourcePool,
  Rival,
  RivalId,
  Settlement,
  SettlementId,
  SpaceBattleResult,
  StandingAgreement,
  StarSystem,
  TechId,
  Technology,
  Tile,
  TileId,
  TradeHistoryEntry,
  TradeOffer,
  TurnSummary,
  Unit,
  UnitId,
  Vote,
  WeatherState,
};

/**
 * The following types exist in the backend source but are not exposed through
 * any public endpoint, so bindgen omits them from `@/backend`. They are
 * declared here with shapes matching the Motoko definitions so screens can
 * share them.
 */

/** Simulation speed for the pausable clock. */
export enum SimSpeed {
  paused = "paused",
  x1 = "x1",
  x2 = "x2",
  x4 = "x4",
}

/** The simulation clock: tick index, in-game date, speed and run state. */
export interface SimClock {
  tick: bigint;
  date: string;
  speed: SimSpeed;
  running: boolean;
  lastAdvanced: bigint;
}

/** An order issued while the clock is paused, queued for the next tick. */
export interface QueuedOrder {
  id: bigint;
  kind: string;
  payload: string;
  issuedAt: bigint;
}

/** A counter-offer payload attached to a countered trade. */
export interface CounterOffer {
  offerId: bigint;
  offered: ResourceBundle;
  requested: ResourceBundle;
  gold: bigint;
  note: string;
}

/** Per-terrain yield and movement cost data. */
export interface TerrainProfile {
  terrain: Terrain;
  yield: ResourcePool;
  movementCost: bigint;
}

/** The top-level screens of the game shell. */
export type ScreenId =
  | "start"
  | "map"
  | "settlement"
  | "technology"
  | "diplomacy"
  | "weather"
  | "economy"
  | "trade"
  | "space"
  | "council";

/** A single resource counter shown in the persistent dock. */
export interface ResourceMeter {
  key: keyof ResourcePool;
  label: string;
  icon: string;
  tone: "food" | "production" | "science" | "gold" | "culture" | "influence";
}

/** Per-turn deltas keyed by resource, used by the turn ledger. */
export type ResourceDelta = Partial<Record<keyof ResourcePool, bigint>>;
