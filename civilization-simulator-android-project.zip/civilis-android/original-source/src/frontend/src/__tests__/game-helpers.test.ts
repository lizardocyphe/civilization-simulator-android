import {
  ERA_ORDER,
  RESOURCE_LABELS,
  RESOURCE_ORDER,
  deltaTone,
  emptyResourcePool,
  eraLabel,
  formatDelta,
  formatNumber,
  hexDistance,
  nextEra,
  weatherGlyph,
} from "@/lib/game";
import { Era } from "@/types";
import { describe, expect, it } from "vitest";

describe("era helpers", () => {
  it("labels every era in the progression", () => {
    expect(eraLabel(Era.ancient)).toBe("Ancient Era");
    expect(eraLabel(Era.industrial)).toBe("Industrial Era");
    expect(eraLabel(Era.modern)).toBe("Modern Era");
    expect(eraLabel(Era.information)).toBe("Information Era");
  });

  it("orders eras from ancient to information", () => {
    expect(ERA_ORDER).toEqual([
      Era.ancient,
      Era.industrial,
      Era.modern,
      Era.information,
    ]);
  });

  it("advances to the next era and stops at the last", () => {
    expect(nextEra(Era.ancient)).toBe(Era.industrial);
    expect(nextEra(Era.industrial)).toBe(Era.modern);
    expect(nextEra(Era.modern)).toBe(Era.information);
    expect(nextEra(Era.information)).toBeNull();
  });
});

describe("resource helpers", () => {
  it("keeps the six-resource order and labels aligned", () => {
    expect(RESOURCE_ORDER).toEqual([
      "food",
      "production",
      "science",
      "gold",
      "culture",
      "influence",
    ]);
    for (const key of RESOURCE_ORDER) {
      expect(RESOURCE_LABELS[key]).toBeTruthy();
    }
  });

  it("builds a zeroed resource pool", () => {
    expect(emptyResourcePool()).toEqual({
      food: 0n,
      production: 0n,
      science: 0n,
      gold: 0n,
      culture: 0n,
      influence: 0n,
    });
  });

  it("formats signed deltas and their tone", () => {
    expect(formatDelta(5n)).toBe("+5");
    expect(formatDelta(-3n)).toBe("-3");
    expect(formatDelta(0n)).toBe("0");
    expect(deltaTone(5n)).toBe("positive");
    expect(deltaTone(-3n)).toBe("negative");
    expect(deltaTone(0n)).toBe("neutral");
  });

  it("renders bigint counters without separators", () => {
    expect(formatNumber(1234n)).toBe("1234");
  });
});

describe("weatherGlyph", () => {
  it("maps condition text to a glyph", () => {
    expect(weatherGlyph("Light rain")).toBe("🌧️");
    expect(weatherGlyph("Snow showers")).toBe("🌨️");
    expect(weatherGlyph("Thunderstorm")).toBe("⛈️");
    expect(weatherGlyph("Overcast")).toBe("☁️");
    expect(weatherGlyph("Fog")).toBe("🌫️");
    expect(weatherGlyph("Clear sky")).toBe("☀️");
    expect(weatherGlyph("something else")).toBe("🌤️");
  });
});

describe("hexDistance", () => {
  it("is zero for the same tile", () => {
    expect(hexDistance({ q: 2n, r: 3n }, { q: 2n, r: 3n })).toBe(0n);
  });

  it("measures axial distance across directions", () => {
    expect(hexDistance({ q: 0n, r: 0n }, { q: 3n, r: 0n })).toBe(3n);
    expect(hexDistance({ q: 0n, r: 0n }, { q: 0n, r: 2n })).toBe(2n);
    expect(hexDistance({ q: 0n, r: 0n }, { q: 1n, r: 1n })).toBe(2n);
    expect(hexDistance({ q: -1n, r: -1n }, { q: 1n, r: 1n })).toBe(4n);
  });
});
