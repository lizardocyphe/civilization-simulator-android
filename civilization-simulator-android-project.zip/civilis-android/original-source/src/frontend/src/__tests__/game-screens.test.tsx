import { setIdentityForTest } from "@/__tests__/setup";
import { renderWithActor } from "@/__tests__/test-utils";
import type { backendInterface } from "@/backend";
import CouncilScreen from "@/pages/CouncilScreen";
import EconomyScreen from "@/pages/EconomyScreen";
import SpaceScreen from "@/pages/SpaceScreen";
import StartScreen from "@/pages/StartScreen";
import TradeScreen from "@/pages/TradeScreen";
import WorldMapScreen from "@/pages/WorldMapScreen";
import {
  AiActionKind,
  type AiActivity,
  AiDifficulty,
  type DiscussionMessage,
  type EconomicPolicy,
  type EconomyState,
  type EconomyTick,
  Era,
  type Fleet,
  FogState,
  type GameState,
  type HexMap,
  type Proposal,
  ProposalKind,
  ProposalStatus,
  type Resolution,
  type ResourceBundle,
  type ResourcePool,
  type Rival,
  type SpaceBattleResult,
  type StarSystem,
  type Tile,
  type TradeHistoryEntry,
  type TradeOffer,
  TradeStatus,
  type Vote,
  type WeatherState,
} from "@/types";
import { act, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

/* ------------------------------------------------------------------ */
/* Fixtures                                                            */
/* ------------------------------------------------------------------ */

const POOL: ResourcePool = {
  food: 10n,
  production: 5n,
  science: 2n,
  gold: 10n,
  culture: 1n,
  influence: 0n,
};

const BUNDLE: ResourceBundle = {
  food: 20n,
  production: 0n,
  science: 0n,
  gold: 0n,
  culture: 0n,
  influence: 0n,
};

function makeGame(overrides: Partial<GameState> = {}): GameState {
  return {
    id: 1n,
    createdAt: 0n,
    updatedAt: 0n,
    turn: 3n,
    civilization: {
      id: 1n,
      name: "Testland",
      era: Era.ancient,
      resources: POOL,
      stability: 50n,
      researchPoints: 0n,
      policies: [],
      isPlayer: true,
    },
    ...overrides,
  };
}

function makeRival(overrides: Partial<Rival> = {}): Rival {
  return {
    id: 2n,
    name: "Rivalia",
    era: Era.ancient,
    stance: "neutral" as Rival["stance"],
    strength: 12n,
    ...overrides,
  };
}

function makeTile(overrides: Partial<Tile> = {}): Tile {
  return {
    id: 1n,
    coord: { q: 0n, r: 0n },
    terrain: "grassland" as Tile["terrain"],
    fog: FogState.visible,
    ...overrides,
  };
}

function makeMap(tiles: Tile[]): HexMap {
  return { width: 4n, height: 4n, tiles };
}

function makeEconomy(overrides: Partial<EconomyState> = {}): EconomyState {
  return {
    priceLevel: 120,
    inflationRate: 0.08,
    history: [],
    upkeep: 4n,
    interestRate: 0.05,
    income: 12n,
    spending: 100n,
    taxRate: 0.2,
    moneySupply: 1000n,
    ...overrides,
  };
}

function makeSystem(overrides: Partial<StarSystem> = {}): StarSystem {
  return {
    id: 1n,
    name: "Sol",
    coord: { q: 1n, r: 1n },
    discovered: true,
    claimed: false,
    planets: 3n,
    defense: 5n,
    resourceYield: POOL,
    ...overrides,
  };
}

function makeFleet(overrides: Partial<Fleet> = {}): Fleet {
  return {
    id: 1n,
    owner: 1n,
    systemId: 1n,
    ships: 4n,
    strength: 20n,
    movement: 2n,
    ...overrides,
  };
}

function makeProposal(overrides: Partial<Proposal> = {}): Proposal {
  return {
    id: 1n,
    sponsor: 2n,
    kind: ProposalKind.tradePact,
    description: "Open trade lanes between our nations.",
    status: ProposalStatus.open,
    votesFor: 2n,
    votesAgainst: 1n,
    ...overrides,
  };
}

/* ------------------------------------------------------------------ */
/* Start screen — campaign creation                                    */
/* ------------------------------------------------------------------ */

describe("start screen", () => {
  it("starts a campaign with the chosen name and era", async () => {
    const startGame = vi.fn<backendInterface["startGame"]>(async () =>
      makeGame(),
    );
    const setAiDifficulty = vi.fn<backendInterface["setAiDifficulty"]>(
      async () => ({ __kind__: "ok", ok: null }),
    );
    const actor = {
      loadGame: vi.fn<backendInterface["loadGame"]>(async () => null),
      getAiDifficulty: vi.fn<backendInterface["getAiDifficulty"]>(
        async () => AiDifficulty.balanced,
      ),
      startGame,
      setAiDifficulty,
    } satisfies Pick<
      backendInterface,
      "loadGame" | "getAiDifficulty" | "startGame" | "setAiDifficulty"
    >;

    renderWithActor(<StartScreen />, actor);

    await userEvent.type(
      await screen.findByTestId("start.nation_name_input"),
      "Aurelia",
    );
    await userEvent.click(screen.getByTestId("start.era.industrial"));
    await userEvent.click(screen.getByTestId("start.submit_button"));

    await waitFor(() =>
      expect(startGame).toHaveBeenCalledWith("Aurelia", Era.industrial),
    );
    // The chosen difficulty is committed after the campaign is created.
    await waitFor(() =>
      expect(setAiDifficulty).toHaveBeenCalledWith(AiDifficulty.balanced),
    );
  });

  it("shows the empty campaign state before a game exists", async () => {
    const actor = {
      loadGame: vi.fn<backendInterface["loadGame"]>(async () => null),
      getAiDifficulty: vi.fn<backendInterface["getAiDifficulty"]>(
        async () => AiDifficulty.balanced,
      ),
    } satisfies Pick<backendInterface, "loadGame" | "getAiDifficulty">;

    renderWithActor(<StartScreen />, actor);

    expect(
      await screen.findByTestId("start.campaign.empty_state"),
    ).toBeInTheDocument();
  });
});

/* ------------------------------------------------------------------ */
/* World map — tile inspector and resource pockets                     */
/* ------------------------------------------------------------------ */

describe("world map screen", () => {
  it("shows terrain, pocket kind, remaining amount and renewal rate for a selected tile", async () => {
    const tile = makeTile({
      id: 7n,
      coord: { q: 1n, r: 0n },
      terrain: "hills" as Tile["terrain"],
      pocket: {
        kind: "production" as NonNullable<Tile["pocket"]>["kind"],
        remaining: 40n,
        initial: 50n,
        renewalRate: 2n,
        renewable: true,
      },
    });
    const actor = {
      getMap: vi.fn<backendInterface["getMap"]>(async () => makeMap([tile])),
      listUnits: vi.fn<backendInterface["listUnits"]>(async () => []),
      listSettlements: vi.fn<backendInterface["listSettlements"]>(
        async () => [],
      ),
    } satisfies Pick<
      backendInterface,
      "getMap" | "listUnits" | "listSettlements"
    >;

    renderWithActor(<WorldMapScreen />, actor);

    await userEvent.click(
      await screen.findByRole("button", { name: /Hills tile at 1, 0/ }),
    );

    const panel = screen.getByTestId("map.tile_panel");
    expect(within(panel).getByText("Hills")).toBeInTheDocument();
    expect(within(panel).getByText("Production Pocket")).toBeInTheDocument();
    expect(within(panel).getByText("40")).toBeInTheDocument();
    expect(within(panel).getByText("+2")).toBeInTheDocument();
  });

  it("shows the empty state when no world has been generated", async () => {
    const actor = {
      getMap: vi.fn<backendInterface["getMap"]>(async () => makeMap([])),
      listUnits: vi.fn<backendInterface["listUnits"]>(async () => []),
      listSettlements: vi.fn<backendInterface["listSettlements"]>(
        async () => [],
      ),
    } satisfies Pick<
      backendInterface,
      "getMap" | "listUnits" | "listSettlements"
    >;

    renderWithActor(<WorldMapScreen />, actor);

    expect(await screen.findByTestId("map.empty_state")).toBeInTheDocument();
  });
});

/* ------------------------------------------------------------------ */
/* Economy — inflation panel and policy levers                         */
/* ------------------------------------------------------------------ */

describe("economy screen", () => {
  it("renders the inflation rate and scales displayed costs by the price level", async () => {
    const history: EconomyTick[] = [
      {
        tick: 1n,
        moneySupply: 900n,
        priceLevel: 100,
        inflationRate: 0,
        income: 10n,
        upkeep: 4n,
      },
      {
        tick: 2n,
        moneySupply: 1000n,
        priceLevel: 120,
        inflationRate: 0.08,
        income: 12n,
        upkeep: 4n,
      },
    ];
    const policy: EconomicPolicy = {
      id: 1n,
      name: "Stimulus",
      description: "Spend to grow.",
      interestRateDelta: 0,
      taxRateDelta: 0,
      spendingDelta: 50n,
    };
    const actor = {
      getEconomy: vi.fn<backendInterface["getEconomy"]>(async () =>
        makeEconomy({ history }),
      ),
      getEconomyHistory: vi.fn<backendInterface["getEconomyHistory"]>(
        async () => history,
      ),
      listEconomicPolicies: vi.fn<backendInterface["listEconomicPolicies"]>(
        async () => [policy],
      ),
      scaledCost: vi.fn<backendInterface["scaledCost"]>(async () => 100n),
    } satisfies Pick<
      backendInterface,
      "getEconomy" | "getEconomyHistory" | "listEconomicPolicies" | "scaledCost"
    >;

    renderWithActor(<EconomyScreen />, actor);

    const inflation = await screen.findByTestId("economy.indicator.inflation");
    // The panel surfaces the backend's inflation rate; assert it is rendered
    // rather than pinning a unit interpretation of the raw value.
    expect(inflation).toHaveTextContent("Inflation Rate");
    expect(inflation).toHaveTextContent("%");
    // A 100 base cost at a 120 price index renders as 120 with a +20 premium.
    const building = screen.getByTestId("economy.real_cost.building");
    expect(building).toHaveTextContent("120");
    expect(building).toHaveTextContent("+20");
    expect(screen.getByTestId("economy.policy.1")).toBeInTheDocument();
  });

  it("shows the empty state when no economy is running", async () => {
    const actor = {
      // The generated interface types these as non-nullable, but the screen's
      // empty state is driven by the query resolving to null at runtime.
      getEconomy: vi.fn<backendInterface["getEconomy"]>(
        async () => null as unknown as EconomyState,
      ),
      getEconomyHistory: vi.fn<backendInterface["getEconomyHistory"]>(
        async () => [],
      ),
      listEconomicPolicies: vi.fn<backendInterface["listEconomicPolicies"]>(
        async () => [],
      ),
      scaledCost: vi.fn<backendInterface["scaledCost"]>(
        async () => null as unknown as bigint,
      ),
    } satisfies Pick<
      backendInterface,
      "getEconomy" | "getEconomyHistory" | "listEconomicPolicies" | "scaledCost"
    >;

    renderWithActor(<EconomyScreen />, actor);

    expect(
      await screen.findByTestId("economy.empty_state"),
    ).toBeInTheDocument();
  });
});

/* ------------------------------------------------------------------ */
/* Trade — offer, counter-offer and history                            */
/* ------------------------------------------------------------------ */

describe("trade screen", () => {
  it("sends a trade offer to a rival and shows a counter-offer with history", async () => {
    const openTradeOffer = vi.fn<backendInterface["openTradeOffer"]>(
      async () => ({ __kind__: "ok", ok: null }),
    );
    const offer: TradeOffer = {
      id: 5n,
      partner: 2n,
      offered: BUNDLE,
      requested: BUNDLE,
      gold: 0n,
      status: TradeStatus.countered,
      createdTick: 3n,
    };
    const history: TradeHistoryEntry = {
      tick: 4n,
      partner: 2n,
      offered: BUNDLE,
      requested: BUNDLE,
      gold: 0n,
      summary: "Accepted a grain exchange.",
    };
    const actor = {
      listRivals: vi.fn<backendInterface["listRivals"]>(async () => [
        makeRival(),
      ]),
      listTradeOffers: vi.fn<backendInterface["listTradeOffers"]>(async () => [
        offer,
      ]),
      listTradeHistory: vi.fn<backendInterface["listTradeHistory"]>(
        async () => [history],
      ),
      listTradeAgreements: vi.fn<backendInterface["listTradeAgreements"]>(
        async () => [],
      ),
      openTradeOffer,
    } satisfies Pick<
      backendInterface,
      | "listRivals"
      | "listTradeOffers"
      | "listTradeHistory"
      | "listTradeAgreements"
      | "openTradeOffer"
    >;

    renderWithActor(<TradeScreen />, actor);

    // A countered offer surfaces its counter panel.
    expect(await screen.findByTestId("trade.counter.5")).toBeInTheDocument();
    // Accepted trades appear in history.
    expect(screen.getByTestId("trade.history.4")).toHaveTextContent(
      "Accepted a grain exchange.",
    );

    // Send a new offer: choose the rival and include a resource.
    await userEvent.selectOptions(
      screen.getByTestId("trade.partner_select"),
      "2",
    );
    await userEvent.type(screen.getByTestId("trade.offer_input.food"), "20");
    await userEvent.click(screen.getByTestId("trade.open_offer.submit_button"));

    await waitFor(() => expect(openTradeOffer).toHaveBeenCalledTimes(1));
    const [partnerId, offered] = openTradeOffer.mock.calls[0];
    expect(partnerId).toBe(2n);
    expect(offered.food).toBe(20n);
  });

  it("shows the no-rivals empty state", async () => {
    const actor = {
      listRivals: vi.fn<backendInterface["listRivals"]>(async () => []),
      listTradeOffers: vi.fn<backendInterface["listTradeOffers"]>(
        async () => [],
      ),
      listTradeHistory: vi.fn<backendInterface["listTradeHistory"]>(
        async () => [],
      ),
      listTradeAgreements: vi.fn<backendInterface["listTradeAgreements"]>(
        async () => [],
      ),
    } satisfies Pick<
      backendInterface,
      | "listRivals"
      | "listTradeOffers"
      | "listTradeHistory"
      | "listTradeAgreements"
    >;

    renderWithActor(<TradeScreen />, actor);

    expect(
      await screen.findByTestId("trade.no_rivals_state"),
    ).toBeInTheDocument();
  });
});

/* ------------------------------------------------------------------ */
/* Space — exploration, fleet and battle                               */
/* ------------------------------------------------------------------ */

describe("space screen", () => {
  it("launches an exploration mission and resolves a battle with a reported outcome", async () => {
    const launchMission = vi.fn<backendInterface["launchMission"]>(
      async () => ({
        __kind__: "ok",
        ok: null,
      }),
    );
    const resolveSpaceBattle = vi.fn<backendInterface["resolveSpaceBattle"]>(
      async (): Promise<SpaceBattleResult> => ({
        attackerWon: true,
        attackerLosses: 1n,
        defenderLosses: 3n,
        summary: "Your fleet broke the orbital defense.",
      }),
    );
    const actor = {
      loadGame: vi.fn<backendInterface["loadGame"]>(async () =>
        makeGame({
          civilization: {
            ...makeGame().civilization,
            era: Era.modern,
          },
        }),
      ),
      listTechnologies: vi.fn<backendInterface["listTechnologies"]>(
        async () => [
          {
            id: 16n,
            name: "Spaceflight",
            era: Era.modern,
            cost: 10n,
            prerequisites: [],
            unlocked: true,
          },
        ],
      ),
      listSystems: vi.fn<backendInterface["listSystems"]>(async () => [
        makeSystem({ id: 1n, name: "Sol", claimed: true, owner: 1n }),
        makeSystem({ id: 2n, name: "Vega", claimed: false }),
      ]),
      listFleets: vi.fn<backendInterface["listFleets"]>(async () => [
        makeFleet({ id: 1n, systemId: 1n }),
      ]),
      launchMission,
      resolveSpaceBattle,
    } satisfies Pick<
      backendInterface,
      | "loadGame"
      | "listTechnologies"
      | "listSystems"
      | "listFleets"
      | "launchMission"
      | "resolveSpaceBattle"
    >;

    renderWithActor(<SpaceScreen />, actor);

    // Launch a mission to a coordinate.
    await userEvent.type(
      await screen.findByTestId("space.mission_q_input"),
      "2",
    );
    await userEvent.type(screen.getByTestId("space.mission_r_input"), "2");
    await userEvent.click(screen.getByTestId("space.launch_button"));
    await waitFor(() => expect(launchMission).toHaveBeenCalledTimes(1));
    expect(launchMission.mock.calls[0][0]).toEqual({ q: 2n, r: 2n });

    // Move the fleet to the hostile system and engage.
    await userEvent.selectOptions(
      screen.getByTestId("space.fleet_target.1"),
      "2",
    );
    await userEvent.click(screen.getByTestId("space.battle_button.1"));

    await waitFor(() => expect(resolveSpaceBattle).toHaveBeenCalledTimes(1));
    expect(resolveSpaceBattle.mock.calls[0]).toEqual([1n, 2n]);
    const outcome = await screen.findByTestId("space.battle_result");
    expect(outcome).toHaveTextContent("Victory");
    expect(outcome).toHaveTextContent("Your fleet broke the orbital defense.");
  });

  it("shows the spaceflight gate when the era and technology are not met", async () => {
    const actor = {
      loadGame: vi.fn<backendInterface["loadGame"]>(async () => makeGame()),
      listTechnologies: vi.fn<backendInterface["listTechnologies"]>(
        async () => [
          {
            id: 16n,
            name: "Spaceflight",
            era: Era.modern,
            cost: 10n,
            prerequisites: [],
            unlocked: false,
          },
        ],
      ),
      listSystems: vi.fn<backendInterface["listSystems"]>(async () => []),
      listFleets: vi.fn<backendInterface["listFleets"]>(async () => []),
    } satisfies Pick<
      backendInterface,
      "loadGame" | "listTechnologies" | "listSystems" | "listFleets"
    >;

    renderWithActor(<SpaceScreen />, actor);

    expect(await screen.findByTestId("space.gate_notice")).toBeInTheDocument();
  });
});

/* ------------------------------------------------------------------ */
/* Council — proposals, votes and discussions                          */
/* ------------------------------------------------------------------ */

describe("council screen", () => {
  it("raises a proposal, reveals each rival's vote, and shows a passed resolution", async () => {
    const raiseProposal = vi.fn<backendInterface["raiseProposal"]>(async () =>
      makeProposal(),
    );
    const votes: Vote[] = [
      { nation: 2n, inFavour: true, reason: "Trade benefits us both." },
      { nation: 3n, inFavour: false, reason: "We distrust your motives." },
    ];
    const resolution: Resolution = {
      id: 1n,
      proposalId: 1n,
      kind: ProposalKind.tradePact,
      effect: "Tariffs lowered across the council.",
      passedTick: 5n,
    };
    const actor = {
      listProposals: vi.fn<backendInterface["listProposals"]>(async () => [
        makeProposal(),
      ]),
      listRivals: vi.fn<backendInterface["listRivals"]>(async () => [
        makeRival({ id: 2n, name: "Rivalia" }),
        makeRival({ id: 3n, name: "Nordia" }),
      ]),
      listResolutions: vi.fn<backendInterface["listResolutions"]>(async () => [
        resolution,
      ]),
      listVotes: vi.fn<backendInterface["listVotes"]>(async () => votes),
      listDiscussions: vi.fn<backendInterface["listDiscussions"]>(
        async () => [],
      ),
      raiseProposal,
    } satisfies Pick<
      backendInterface,
      | "listProposals"
      | "listRivals"
      | "listResolutions"
      | "listVotes"
      | "listDiscussions"
      | "raiseProposal"
    >;

    renderWithActor(<CouncilScreen />, actor);

    // A passed resolution applies its effect to the world.
    expect(await screen.findByTestId("council.resolution.1")).toHaveTextContent(
      "Tariffs lowered across the council.",
    );

    // Reveal each rival's vote on the proposal.
    await userEvent.click(screen.getByTestId("council.toggle_votes_button.1"));
    await waitFor(() => expect(actor.listVotes).toHaveBeenCalledWith(1n));
    expect(
      await screen.findByText("Trade benefits us both."),
    ).toBeInTheDocument();
    expect(screen.getByText("We distrust your motives.")).toBeInTheDocument();

    // Raise a new proposal.
    await userEvent.type(
      screen.getByTestId("council.description_textarea"),
      "Let us open a joint space program.",
    );
    await userEvent.click(screen.getByTestId("council.raise_button"));
    await waitFor(() => expect(raiseProposal).toHaveBeenCalledTimes(1));
    expect(raiseProposal.mock.calls[0][1]).toBe(
      "Let us open a joint space program.",
    );
  });

  it("opens a discussion with a rival and shows the AI-generated reply", async () => {
    const reply: DiscussionMessage = {
      nation: 2n,
      speaker: "Envoy of Rivalia",
      text: "We will consider your proposal.",
      tick: 6n,
    };
    const discussWithNation = vi.fn<backendInterface["discussWithNation"]>(
      async () => reply,
    );
    const actor = {
      listProposals: vi.fn<backendInterface["listProposals"]>(async () => []),
      listRivals: vi.fn<backendInterface["listRivals"]>(async () => [
        makeRival({ id: 2n, name: "Rivalia" }),
      ]),
      listResolutions: vi.fn<backendInterface["listResolutions"]>(
        async () => [],
      ),
      listDiscussions: vi.fn<backendInterface["listDiscussions"]>(
        async () => [],
      ),
      discussWithNation,
    } satisfies Pick<
      backendInterface,
      | "listProposals"
      | "listRivals"
      | "listResolutions"
      | "listDiscussions"
      | "discussWithNation"
    >;

    renderWithActor(<CouncilScreen />, actor);

    await userEvent.type(
      await screen.findByTestId("council.message_textarea"),
      "Will you join our trade pact?",
    );
    await userEvent.click(screen.getByTestId("council.send_button"));

    await waitFor(() => expect(discussWithNation).toHaveBeenCalledTimes(1));
    expect(discussWithNation.mock.calls[0]).toEqual([
      2n,
      "Will you join our trade pact?",
    ]);
    const replyPanel = await screen.findByTestId("council.reply");
    expect(replyPanel).toHaveTextContent("We will consider your proposal.");
  });
});

/* ------------------------------------------------------------------ */
/* AI activity log — autonomous rivals                                 */
/* ------------------------------------------------------------------ */

describe("AI activity log", () => {
  it("renders rival actions from the activity log", async () => {
    const activity: AiActivity[] = [
      {
        rival: 2n,
        tick: 3n,
        action: AiActionKind.expand,
        reasoning: "Settling the fertile river valley.",
      },
    ];
    const actor = {
      listAiActivity: vi.fn<backendInterface["listAiActivity"]>(
        async () => activity,
      ),
      getAiDifficulty: vi.fn<backendInterface["getAiDifficulty"]>(
        async () => AiDifficulty.balanced,
      ),
      listRivals: vi.fn<backendInterface["listRivals"]>(async () => [
        makeRival({ id: 2n, name: "Rivalia" }),
      ]),
      listUnits: vi.fn<backendInterface["listUnits"]>(async () => []),
    } satisfies Pick<
      backendInterface,
      "listAiActivity" | "getAiDifficulty" | "listRivals" | "listUnits"
    >;

    // The AI panel lives on the diplomacy screen; render it directly.
    const { default: DiplomacyScreen } = await import(
      "@/pages/DiplomacyScreen"
    );
    renderWithActor(<DiplomacyScreen />, actor);

    const list = await screen.findByTestId("diplomacy.ai.list");
    expect(list).toHaveTextContent("Rivalia");
    expect(list).toHaveTextContent("Expand");
    expect(list).toHaveTextContent("Settling the fertile river valley.");
  });
});

/* ------------------------------------------------------------------ */
/* Simulation clock — pause and speed controls                         */
/* ------------------------------------------------------------------ */

describe("simulation clock", () => {
  it("toggles pause and selects a speed step", async () => {
    const actor = {
      loadGame: vi.fn<backendInterface["loadGame"]>(async () => makeGame()),
      // The generated interface types this as non-nullable, but the shell
      // tolerates a null weather query at runtime.
      getWeather: vi.fn<backendInterface["getWeather"]>(
        async () => null as unknown as WeatherState,
      ),
    } satisfies Pick<backendInterface, "loadGame" | "getWeather">;

    const { default: App } = await import("@/App");
    setIdentityForTest({
      identity: {
        getPrincipal: () => ({
          isAnonymous: () => false,
          toText: () => "aaaaa-aa",
        }),
      } as unknown as NonNullable<
        Parameters<typeof setIdentityForTest>[0]
      >["identity"],
    });
    renderWithActor(<App />, actor);

    // Starts paused: the control offers to resume.
    const pauseButton = await screen.findByTestId("clock.pause_button");
    expect(pauseButton).toHaveAttribute("aria-label", "Resume simulation");

    // Resume, then pick 2x.
    await userEvent.click(pauseButton);
    expect(screen.getByTestId("clock.pause_button")).toHaveAttribute(
      "aria-label",
      "Pause simulation",
    );
    await userEvent.click(screen.getByTestId("clock.speed.x2"));
    expect(screen.getByTestId("clock.speed.x2")).toHaveAttribute(
      "aria-pressed",
      "true",
    );
  });

  it("advances the world through endTurn on the selected speed and stops when paused", async () => {
    // Fake only the interval clock the sim uses; leave timeouts real so
    // Testing Library queries and user-event keep working.
    vi.useFakeTimers({ toFake: ["Date", "setInterval", "clearInterval"] });
    try {
      const endTurn = vi.fn<backendInterface["endTurn"]>(async () => ({
        turn: 4n,
        resourcesGained: POOL,
        events: [],
        stabilityDelta: 0n,
      }));
      const actor = {
        loadGame: vi.fn<backendInterface["loadGame"]>(async () => makeGame()),
        getWeather: vi.fn<backendInterface["getWeather"]>(
          async () => null as unknown as WeatherState,
        ),
        endTurn,
      } satisfies Pick<backendInterface, "loadGame" | "getWeather" | "endTurn">;

      const { default: App } = await import("@/App");
      setIdentityForTest({
        identity: {
          getPrincipal: () => ({
            isAnonymous: () => false,
            toText: () => "aaaaa-aa",
          }),
        } as unknown as NonNullable<
          Parameters<typeof setIdentityForTest>[0]
        >["identity"],
      });
      renderWithActor(<App />, actor);

      // Paused: no timer is running, so no turn advances.
      await screen.findByTestId("clock.pause_button");
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });
      expect(endTurn).not.toHaveBeenCalled();

      // Resume at 1x: each 5000ms interval advances the world once.
      await userEvent.click(screen.getByTestId("clock.pause_button"));
      await act(async () => {
        await vi.advanceTimersByTimeAsync(5_000);
      });
      expect(endTurn).toHaveBeenCalledTimes(1);

      // 4x runs four times faster: 1250ms per tick.
      await userEvent.click(screen.getByTestId("clock.speed.x4"));
      await act(async () => {
        await vi.advanceTimersByTimeAsync(1_250);
      });
      expect(endTurn).toHaveBeenCalledTimes(2);

      // Pausing clears the timer so the world stops advancing.
      await userEvent.click(screen.getByTestId("clock.pause_button"));
      await act(async () => {
        await vi.advanceTimersByTimeAsync(10_000);
      });
      expect(endTurn).toHaveBeenCalledTimes(2);
    } finally {
      vi.useRealTimers();
    }
  });
});
