import App from "@/App";
import { setIdentityForTest } from "@/__tests__/setup";
import { renderWithActor } from "@/__tests__/test-utils";
import type { backendInterface } from "@/backend";
import { Era, type GameState, type WeatherState } from "@/types";
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

const RESOURCES = {
  food: 10n,
  production: 5n,
  science: 2n,
  gold: 10n,
  culture: 1n,
  influence: 0n,
};

function makeGame(overrides: Partial<GameState> = {}): GameState {
  return {
    id: 1n,
    createdAt: 0n,
    updatedAt: 0n,
    turn: 3n,
    civilization: {
      id: 1n,
      name: "Testland",
      era: Era.ancient,
      resources: RESOURCES,
      stability: 50n,
      researchPoints: 0n,
      policies: [],
      isPlayer: true,
    },
    ...overrides,
  };
}

function makeWeather(overrides: Partial<WeatherState> = {}): WeatherState {
  return {
    condition: "Clear sky",
    temperatureC: 21,
    precipitationMm: 0,
    windKph: 5,
    updatedAt: 0n,
    ...overrides,
  };
}

/** A non-anonymous identity so the auth gate renders the app shell. */
function signedInIdentity() {
  return {
    getPrincipal: () => ({
      isAnonymous: () => false,
      toText: () => "aaaaa-aa",
    }),
  } as unknown as NonNullable<
    Parameters<typeof setIdentityForTest>[0]
  >["identity"];
}

function makeActor(
  overrides: Partial<
    Pick<backendInterface, "loadGame" | "getWeather" | "endTurn">
  > = {},
) {
  return {
    loadGame: vi.fn<backendInterface["loadGame"]>(async () => makeGame()),
    getWeather: vi.fn<backendInterface["getWeather"]>(async () =>
      makeWeather(),
    ),
    endTurn: vi.fn<backendInterface["endTurn"]>(async () => ({
      turn: 4n,
      resourcesGained: RESOURCES,
      events: [],
      stabilityDelta: 0n,
    })),
    ...overrides,
  } satisfies Pick<backendInterface, "loadGame" | "getWeather" | "endTurn">;
}

describe("app shell", () => {
  it("shows the sign-in gate when no identity is present", () => {
    setIdentityForTest();
    renderWithActor(<App />, makeActor());

    expect(
      screen.getByRole("heading", { name: "CIVILIS" }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Sign in with Internet Identity" }),
    ).toBeInTheDocument();
  });

  it("renders the default route and shell chrome once signed in", async () => {
    setIdentityForTest({ identity: signedInIdentity() });
    renderWithActor(<App />, makeActor());

    // Default route is the start screen, not a blank page.
    expect(
      await screen.findByRole("heading", { name: "Start or Load a Game" }),
    ).toBeInTheDocument();
    // Shell chrome: turn indicator, resource dock, end-turn and city actions.
    expect(await screen.findByText("Ancient Era")).toBeInTheDocument();
    // The header turn indicator is the only element whose text starts with
    // "Turn " and carries the turn number; the start screen's campaign card
    // also has a bare "Turn" label, so match the header's full text.
    expect(
      screen.getByText((_, element) => {
        const text = element?.textContent ?? "";
        return element?.tagName === "SPAN" && /^Turn\s+3\b/.test(text);
      }),
    ).toBeInTheDocument();
    expect(screen.getByTestId("dock.resource_bar")).toBeInTheDocument();
    expect(screen.getByTestId("dock.end_turn_button")).toBeInTheDocument();
    expect(screen.getByTestId("dock.city_button")).toBeInTheDocument();
  });

  it("shows the empty resource ledger before a game exists", async () => {
    setIdentityForTest({ identity: signedInIdentity() });
    renderWithActor(
      <App />,
      makeActor({
        loadGame: vi.fn<backendInterface["loadGame"]>(async () => null),
      }),
    );

    expect(await screen.findByTestId("dock.empty_state")).toBeInTheDocument();
    expect(screen.queryByTestId("dock.resource_bar")).not.toBeInTheDocument();
  });

  it("renders the weather chip from the weather query", async () => {
    setIdentityForTest({ identity: signedInIdentity() });
    renderWithActor(<App />, makeActor());

    const chip = await screen.findByTestId("header.weather_chip");
    expect(chip).toHaveTextContent("21°C");
  });

  it("calls endTurn when the end-turn button is pressed", async () => {
    setIdentityForTest({ identity: signedInIdentity() });
    const actor = makeActor();
    renderWithActor(<App />, actor);

    const button = await screen.findByTestId("dock.end_turn_button");
    await userEvent.click(button);

    await waitFor(() => expect(actor.endTurn).toHaveBeenCalledTimes(1));
  });

  it("opens the navigation sheet and lists every screen", async () => {
    setIdentityForTest({ identity: signedInIdentity() });
    renderWithActor(<App />, makeActor());

    await userEvent.click(
      await screen.findByRole("button", { name: "Open navigation menu" }),
    );

    const nav = screen.getByRole("navigation", { name: "Game screens" });
    for (const label of [
      "Map",
      "Settlement",
      "Technology",
      "Diplomacy",
      "Weather",
    ]) {
      expect(nav).toHaveTextContent(label);
    }
  });
});
