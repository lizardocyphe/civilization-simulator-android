import EconomyTypes "types/economy";

module {
  /// Re-export the economy domain types so callers can import a single module.
  public type EconomyState = EconomyTypes.EconomyState;
  public type EconomyTick = EconomyTypes.EconomyTick;
  public type EconomicPolicy = EconomyTypes.EconomicPolicy;
};
