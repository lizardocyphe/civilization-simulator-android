import Principal "mo:core/Principal";
import AccessControl "mo:caffeineai-authorization/access-control";
import MixinAuthorization "mo:caffeineai-authorization/MixinAuthorization";
import OutCall "mo:caffeineai-http-outcalls/outcall";
import OQL "mo:caffeineai-oql";
import Expose "mo:caffeineai-oql/Expose";
import Entity "mo:caffeineai-oql/Entity";
import PrincipalValue "mo:caffeineai-oql/PrincipalValue";
import NatValue "mo:caffeineai-oql/NatValue";
import TextValue "mo:caffeineai-oql/TextValue";
import BoolValue "mo:caffeineai-oql/BoolValue";
import FloatValue "mo:caffeineai-oql/FloatValue";
import IntValue "mo:caffeineai-oql/IntValue";

import WorldTypes "types/world";
import SettlementTypes "types/settlements";
import MilitaryTypes "types/military";
import TechTypes "types/tech";
import EconomyTypes "types/economy";
import TradeTypes "types/trade";
import SpaceTypes "types/space";
import CouncilTypes "types/council";
import SimulationTypes "types/simulation";
import OqlLib "lib/oql";

import GameApi "mixins/game-api";
import MapApi "mixins/map-api";
import SettlementsApi "mixins/settlements-api";
import MilitaryApi "mixins/military-api";
import TechApi "mixins/tech-api";
import WorldApi "mixins/world-api";
import AiApi "mixins/ai-api";
import EconomyApi "mixins/economy-api";
import TradeApi "mixins/trade-api";
import SpaceApi "mixins/space-api";
import CouncilApi "mixins/council-api";
import ApiDocMixin "mixins/api-doc";

actor {
  let accessControlState : AccessControl.AccessControlState;
  let world : WorldTypes.WorldState;

  include MixinAuthorization(accessControlState, null);

  /// HTTP outcall response-normalization callback required by the weather fetch.
  public query func transform(input : OutCall.TransformationInput) : async OutCall.TransformationOutput {
    OutCall.transform(input);
  };

  include GameApi(world);
  include MapApi(world);
  include SettlementsApi(world);
  include MilitaryApi(world);
  include TechApi(world);
  include WorldApi(world, transform);
  include AiApi(world);
  include EconomyApi(world);
  include TradeApi(world);
  include SpaceApi(world);
  include CouncilApi(world);
  include ApiDocMixin();

  // ---------------------------------------------------------------------------
  // OQL — Object Query Layer
  //
  // Every queryable collection lives inside a per-player PlayerState held in
  // `world.players`, keyed by the owner principal. Each entity below flattens
  // one collection into rows carrying a synthetic `owner` column, and is
  // scoped per user so a signed-in caller reads only its own rows while the
  // platform controller (and the Data Intelligence agent) reads all.
  // ---------------------------------------------------------------------------

  include Expose({
    entities = [
      OQL.Entity.manual<(Principal, SettlementTypes.Settlement)>(
        "settlement", func () = OqlLib.settlements(world), "Settlement", "id"
      )
        .sample((OqlLib.sampleOwner(), {
          id = 0; name = ""; owner = 0; position = { q = 0; r = 0 };
          population = 0; buildings = []; workedTiles = []; production = OqlLib.samplePool();
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, s)) = s.id)
        .payload("name", func ((_, s)) = s.name)
        .payload("civOwner", func ((_, s)) = s.owner)
        .payload("q", func ((_, s)) = s.position.q)
        .payload("r", func ((_, s)) = s.position.r)
        .payload("population", func ((_, s)) = s.population)
        .payload("buildingCount", func ((_, s)) = s.buildings.size())
        .payload("workedTileCount", func ((_, s)) = s.workedTiles.size())
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, MilitaryTypes.Unit)>(
        "unit", func () = OqlLib.units(world), "Unit", "id"
      )
        .sample((OqlLib.sampleOwner(), {
          id = 0; owner = 0; kind = ""; strength = 0; movement = 0; position = { q = 0; r = 0 };
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, u)) = u.id)
        .payload("kind", func ((_, u)) = u.kind)
        .payload("strength", func ((_, u)) = u.strength)
        .payload("movement", func ((_, u)) = u.movement)
        .payload("q", func ((_, u)) = u.position.q)
        .payload("r", func ((_, u)) = u.position.r)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, MilitaryTypes.Rival)>(
        "rival", func () = OqlLib.rivals(world), "Rival", "id"
      )
        .sample((OqlLib.sampleOwner(), { id = 0; name = ""; era = #ancient; stance = #neutral; strength = 0 }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, r)) = r.id)
        .payload("name", func ((_, r)) = r.name)
        .payload("era", func ((_, r)) = switch (r.era) {
          case (#ancient) { "ancient" }; case (#industrial) { "industrial" };
          case (#modern) { "modern" }; case (#information) { "information" };
        })
        .payload("stance", func ((_, r)) = switch (r.stance) {
          case (#war) { "war" }; case (#neutral) { "neutral" };
          case (#peace) { "peace" }; case (#alliance) { "alliance" };
        })
        .payload("strength", func ((_, r)) = r.strength)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, TechTypes.Technology)>(
        "technology", func () = OqlLib.technologies(world), "Technology", "id"
      )
        .sample((OqlLib.sampleOwner(), {
          id = 0; name = ""; era = #ancient; cost = 0; prerequisites = []; unlocked = false;
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, t)) = t.id)
        .payload("name", func ((_, t)) = t.name)
        .payload("era", func ((_, t)) = switch (t.era) {
          case (#ancient) { "ancient" }; case (#industrial) { "industrial" };
          case (#modern) { "modern" }; case (#information) { "information" };
        })
        .payload("cost", func ((_, t)) = t.cost)
        .payload("unlocked", func ((_, t)) = t.unlocked)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, WorldTypes.CrisisEvent)>(
        "crisis", func () = OqlLib.crises(world), "Crisis", "id"
      )
        .sample((OqlLib.sampleOwner(), {
          id = 0; kind = ""; title = ""; description = ""; choices = []; resolved = false;
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, c)) = c.id)
        .payload("kind", func ((_, c)) = c.kind)
        .payload("title", func ((_, c)) = c.title)
        .payload("resolved", func ((_, c)) = c.resolved)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, TradeTypes.TradeOffer)>(
        "tradeOffer", func () = OqlLib.tradeOffers(world), "TradeOffer", "id"
      )
        .sample((OqlLib.sampleOwner(), {
          id = 0; partner = 0; offered = OqlLib.samplePool(); requested = OqlLib.samplePool();
          gold = 0; status = #pending; createdTick = 0;
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, o)) = o.id)
        .payload("partner", func ((_, o)) = o.partner)
        .payload("gold", func ((_, o)) = o.gold)
        .payload("status", func ((_, o)) = switch (o.status) {
          case (#pending) { "pending" }; case (#accepted) { "accepted" };
          case (#rejected) { "rejected" }; case (#countered) { "countered" };
          case (#cancelled) { "cancelled" };
        })
        .payload("createdTick", func ((_, o)) = o.createdTick)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, TradeTypes.StandingAgreement)>(
        "tradeAgreement", func () = OqlLib.tradeAgreements(world), "TradeAgreement", "id"
      )
        .sample((OqlLib.sampleOwner(), {
          id = 0; partner = 0; perTick = OqlLib.samplePool(); goldPerTick = 0; active = false; startedTick = 0;
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, a)) = a.id)
        .payload("partner", func ((_, a)) = a.partner)
        .payload("goldPerTick", func ((_, a)) = a.goldPerTick)
        .payload("active", func ((_, a)) = a.active)
        .payload("startedTick", func ((_, a)) = a.startedTick)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, TradeTypes.TradeHistoryEntry)>(
        "tradeHistory", func () = OqlLib.tradeHistory(world), "TradeHistory", "tick"
      )
        .sample((OqlLib.sampleOwner(), {
          tick = 0; partner = 0; offered = OqlLib.samplePool(); requested = OqlLib.samplePool(); gold = 0; summary = "";
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("tick", func ((_, h)) = h.tick)
        .payload("partner", func ((_, h)) = h.partner)
        .payload("gold", func ((_, h)) = h.gold)
        .payload("summary", func ((_, h)) = h.summary)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, SpaceTypes.StarSystem)>(
        "starSystem", func () = OqlLib.spaceSystems(world), "StarSystem", "id"
      )
        .sample((OqlLib.sampleOwner(), {
          id = 0; name = ""; coord = { q = 0; r = 0 }; discovered = false; claimed = false;
          owner = null; planets = 0; resourceYield = OqlLib.samplePool(); defense = 0;
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, s)) = s.id)
        .payload("name", func ((_, s)) = s.name)
        .payload("q", func ((_, s)) = s.coord.q)
        .payload("r", func ((_, s)) = s.coord.r)
        .payload("discovered", func ((_, s)) = s.discovered)
        .payload("claimed", func ((_, s)) = s.claimed)
        .payload("planets", func ((_, s)) = s.planets)
        .payload("defense", func ((_, s)) = s.defense)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, SpaceTypes.Fleet)>(
        "fleet", func () = OqlLib.fleets(world), "Fleet", "id"
      )
        .sample((OqlLib.sampleOwner(), {
          id = 0; owner = 0; systemId = 0; ships = 0; strength = 0; movement = 0;
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, f)) = f.id)
        .payload("systemId", func ((_, f)) = f.systemId)
        .payload("ships", func ((_, f)) = f.ships)
        .payload("strength", func ((_, f)) = f.strength)
        .payload("movement", func ((_, f)) = f.movement)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, CouncilTypes.Proposal)>(
        "proposal", func () = OqlLib.proposals(world), "Proposal", "id"
      )
        .sample((OqlLib.sampleOwner(), {
          id = 0; sponsor = 0; kind = #tradePact; description = ""; status = #open;
          votesFor = 0; votesAgainst = 0;
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, p)) = p.id)
        .payload("kind", func ((_, p)) = switch (p.kind) {
          case (#tradePact) { "tradePact" }; case (#peace) { "peace" };
          case (#sanctions) { "sanctions" }; case (#territorialClaim) { "territorialClaim" };
          case (#jointSpaceProgram) { "jointSpaceProgram" };
        })
        .payload("description", func ((_, p)) = p.description)
        .payload("status", func ((_, p)) = switch (p.status) {
          case (#open) { "open" }; case (#passed) { "passed" };
          case (#failed) { "failed" }; case (#withdrawn) { "withdrawn" };
        })
        .payload("votesFor", func ((_, p)) = p.votesFor)
        .payload("votesAgainst", func ((_, p)) = p.votesAgainst)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, CouncilTypes.Resolution)>(
        "resolution", func () = OqlLib.resolutions(world), "Resolution", "id"
      )
        .sample((OqlLib.sampleOwner(), {
          id = 0; proposalId = 0; kind = #tradePact; effect = ""; passedTick = 0;
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("id", func ((_, r)) = r.id)
        .payload("proposalId", func ((_, r)) = r.proposalId)
        .payload("kind", func ((_, r)) = switch (r.kind) {
          case (#tradePact) { "tradePact" }; case (#peace) { "peace" };
          case (#sanctions) { "sanctions" }; case (#territorialClaim) { "territorialClaim" };
          case (#jointSpaceProgram) { "jointSpaceProgram" };
        })
        .payload("effect", func ((_, r)) = r.effect)
        .payload("passedTick", func ((_, r)) = r.passedTick)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, SimulationTypes.DiscussionMessage)>(
        "discussion", func () = OqlLib.discussions(world), "Discussion", "tick"
      )
        .sample((OqlLib.sampleOwner(), { speaker = ""; nation = 0; text = ""; tick = 0 }))
        .payload("owner", func ((p, _)) = p)
        .payload("speaker", func ((_, m)) = m.speaker)
        .payload("nation", func ((_, m)) = m.nation)
        .payload("text", func ((_, m)) = m.text)
        .payload("tick", func ((_, m)) = m.tick)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, SimulationTypes.AiActivity)>(
        "aiActivity", func () = OqlLib.aiLog(world), "AiActivity", "tick"
      )
        .sample((OqlLib.sampleOwner(), { tick = 0; rival = 0; action = #idle; reasoning = "" }))
        .payload("owner", func ((p, _)) = p)
        .payload("tick", func ((_, a)) = a.tick)
        .payload("rival", func ((_, a)) = a.rival)
        .payload("action", func ((_, a)) = switch (a.action) {
          case (#expand) { "expand" }; case (#research) { "research" };
          case (#build) { "build" }; case (#recruit) { "recruit" };
          case (#attack) { "attack" }; case (#trade) { "trade" };
          case (#diplomacy) { "diplomacy" }; case (#space) { "space" };
          case (#idle) { "idle" };
        })
        .payload("reasoning", func ((_, a)) = a.reasoning)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
      OQL.Entity.manual<(Principal, EconomyTypes.EconomyTick)>(
        "economyTick", func () = OqlLib.economyHistory(world), "EconomyTick", "tick"
      )
        .sample((OqlLib.sampleOwner(), {
          tick = 0; moneySupply = 0; priceLevel = 1.0; inflationRate = 0.0; income = 0; upkeep = 0;
        }))
        .payload("owner", func ((p, _)) = p)
        .payload("tick", func ((_, e)) = e.tick)
        .payload("moneySupply", func ((_, e)) = e.moneySupply)
        .payload("priceLevel", func ((_, e)) = e.priceLevel)
        .payload("inflationRate", func ((_, e)) = e.inflationRate)
        .payload("income", func ((_, e)) = e.income)
        .payload("upkeep", func ((_, e)) = e.upkeep)
        .ownedBy("owner")
        .controllerOrScoped()
        .build(),
    ];
  });
};
