import Array "mo:core/Array";
import Iter "mo:core/Iter";
import Map "mo:core/Map";
import Nat "mo:core/Nat";
import Common "types/common";
import TechTypes "types/tech";
import MilitaryTypes "types/military";
import WorldTypes "types/world";

/// Technology, politics and conflict domain for the civilization game.
///
/// This module owns the research tree, era advancement, diplomacy and
/// military combat logic. It is stateless: every function takes the
/// caller's persisted state record and mutates it in place, so the actor
/// can hold the state as a stable field and pass it in.
module {
  // ------------------------------------------------------------------
  // Technology catalog
  // ------------------------------------------------------------------

  /// The full technology tree, ordered by era then cost.
  public func catalog() : [TechTypes.Technology] {
    [
      { id = 1; name = "Agriculture"; era = #ancient; cost = 10; prerequisites = []; unlocked = false },
      { id = 2; name = "Pottery"; era = #ancient; cost = 15; prerequisites = [1]; unlocked = false },
      { id = 3; name = "Bronze Working"; era = #ancient; cost = 25; prerequisites = [1]; unlocked = false },
      { id = 4; name = "Writing"; era = #ancient; cost = 30; prerequisites = [2]; unlocked = false },
      { id = 5; name = "Iron Working"; era = #ancient; cost = 40; prerequisites = [3]; unlocked = false },
      { id = 6; name = "Mathematics"; era = #ancient; cost = 50; prerequisites = [4]; unlocked = false },
      { id = 7; name = "Engineering"; era = #industrial; cost = 70; prerequisites = [5, 6]; unlocked = false },
      { id = 8; name = "Steam Power"; era = #industrial; cost = 90; prerequisites = [7]; unlocked = false },
      { id = 9; name = "Railroad"; era = #industrial; cost = 110; prerequisites = [8]; unlocked = false },
      { id = 10; name = "Electricity"; era = #modern; cost = 140; prerequisites = [9]; unlocked = false },
      { id = 11; name = "Combustion"; era = #modern; cost = 170; prerequisites = [10]; unlocked = false },
      { id = 12; name = "Flight"; era = #modern; cost = 200; prerequisites = [11]; unlocked = false },
      { id = 13; name = "Computers"; era = #information; cost = 240; prerequisites = [12]; unlocked = false },
      { id = 14; name = "Internet"; era = #information; cost = 280; prerequisites = [13]; unlocked = false },
      { id = 15; name = "Artificial Intelligence"; era = #information; cost = 340; prerequisites = [14]; unlocked = false },
      { id = 16; name = "Spaceflight"; era = #information; cost = 400; prerequisites = [15]; unlocked = false },
    ];
  };

  /// The milestone requirements to advance out of each era.
  public func milestones() : [TechTypes.EraMilestone] {
    [
      { era = #ancient; requiredTechs = [1, 2, 3, 4, 5, 6]; requiredPopulation = 6; requiredBuildings = 3 },
      { era = #industrial; requiredTechs = [7, 8, 9]; requiredPopulation = 20; requiredBuildings = 8 },
      { era = #modern; requiredTechs = [10, 11, 12]; requiredPopulation = 45; requiredBuildings = 15 },
      { era = #information; requiredTechs = [13, 14, 15]; requiredPopulation = 80; requiredBuildings = 25 },
    ];
  };

  /// Saturating subtraction: never traps when `b` exceeds `a`.
  func subFloor(a : Nat, b : Nat) : Nat {
    if (a >= b) { a - b } else { 0 };
  };

  func eraIndex(era : Common.Era) : Nat {
    switch (era) {
      case (#ancient) { 0 };
      case (#industrial) { 1 };
      case (#modern) { 2 };
      case (#information) { 3 };
    };
  };

  func eraAt(index : Nat) : Common.Era {
    switch (index) {
      case (0) { #ancient };
      case (1) { #industrial };
      case (2) { #modern };
      case _ { #information };
    };
  };

  func findTech(techId : Common.TechId) : ?TechTypes.Technology {
    catalog().find(func t = t.id == techId);
  };

  /// Base strength and movement for a unit kind.
  func unitProfile(kind : Text) : (Nat, Nat) {
    switch (kind) {
      case ("warrior") { (10, 2) };
      case ("archer") { (8, 2) };
      case ("spearman") { (12, 1) };
      case ("horseman") { (14, 4) };
      case ("catapult") { (18, 1) };
      case ("tank") { (30, 3) };
      case ("infantry") { (24, 2) };
      case ("artillery") { (28, 2) };
      case ("drone") { (22, 5) };
      case _ { (10, 2) };
    };
  };

  // ------------------------------------------------------------------
  // PlayerState adapters
  //
  // The actor persists one `WorldTypes.PlayerState` per principal, whose
  // technology, unit and rival collections are arrays. These adapters bridge
  // the array-backed player record to the map-backed domain logic above.
  // ------------------------------------------------------------------

  /// Seed the player's rival list from the default rival set.
  public func seedPlayerRivals(state : WorldTypes.PlayerState) : () {
    state.rivals := [
      { id = 1; name = "Northern Realm"; era = #ancient; stance = #neutral; strength = 12 },
      { id = 2; name = "Eastern Empire"; era = #ancient; stance = #neutral; strength = 15 },
      { id = 3; name = "Southern League"; era = #ancient; stance = #neutral; strength = 10 },
    ];
  };

  /// List every technology with its unlock state for the player.
  public func listTechnologies(state : WorldTypes.PlayerState) : [TechTypes.Technology] {
    let researched = researchedSet(state);
    catalog().map(func t = { t with unlocked = researched.get(t.id) != null });
  };

  /// List the era milestone requirements.
  public func listMilestones() : [TechTypes.EraMilestone] {
    milestones();
  };

  /// Spend research points to unlock a technology for the player.
  public func researchTechnology(state : WorldTypes.PlayerState, techId : Common.TechId) : Common.ActionResult {
    let tech = switch (findTech(techId)) {
      case (?t) { t };
      case null { return #err("Unknown technology") };
    };
    let researched = researchedSet(state);
    if (researched.get(techId) != null) {
      return #err("Technology already researched");
    };
    if (not tech.prerequisites.all(func p = researched.get(p) != null)) {
      return #err("Prerequisites not met");
    };
    let points = switch (state.game) {
      case (?g) { g.civilization.researchPoints };
      case null { 0 };
    };
    if (points < tech.cost) {
      return #err("Not enough research points");
    };
    state.technologies := state.technologies.concat([{ tech with unlocked = true }]);
    switch (state.game) {
      case (?g) {
        let civ = g.civilization;
        state.game := ?{
          g with
          civilization = { civ with researchPoints = subFloor(civ.researchPoints, tech.cost) };
        };
      };
      case null {};
    };
    #ok;
  };

  /// Advance the player to the next era when the current milestone is met.
  public func advanceEra(state : WorldTypes.PlayerState) : Common.ActionResult {
    let game = switch (state.game) {
      case (?g) { g };
      case null { return #err("No game in progress") };
    };
    let index = eraIndex(game.civilization.era);
    if (index >= 3) {
      return #err("Already in the final era");
    };
    let milestone = switch (milestones().find(func m = m.era == game.civilization.era)) {
      case (?m) { m };
      case null { return #err("No milestone for current era") };
    };
    let researched = researchedSet(state);
    if (not milestone.requiredTechs.all(func t = researched.get(t) != null)) {
      return #err("Required technologies not researched");
    };
    let population = state.settlements.foldLeft(0, func(acc, s) = acc + s.population);
    if (population < milestone.requiredPopulation) {
      return #err("Population milestone not reached");
    };
    let buildings = state.settlements.foldLeft(0, func(acc, s) = acc + s.buildings.size());
    if (buildings < milestone.requiredBuildings) {
      return #err("Building milestone not reached");
    };
    let civ = game.civilization;
    state.game := ?{ game with civilization = { civ with era = eraAt(index + 1) } };
    #ok;
  };

  /// Recruit a new unit at a coordinate for the player.
  public func recruitUnit(state : WorldTypes.PlayerState, kind : Text, position : Common.HexCoord) : Common.ActionResult {
    let (strength, movement) = unitProfile(kind);
    let id = state.nextUnitId;
    state.nextUnitId := id + 1;
    state.units := state.units.concat([{
      id;
      owner = 1;
      kind;
      strength;
      movement;
      position;
    }]);
    #ok;
  };

  /// List the player's units.
  public func listUnits(state : WorldTypes.PlayerState) : [MilitaryTypes.Unit] {
    state.units;
  };

  /// List the player's known rivals.
  public func listRivals(state : WorldTypes.PlayerState) : [MilitaryTypes.Rival] {
    state.rivals;
  };

  /// Set the diplomatic stance toward a rival.
  public func setDiplomacy(state : WorldTypes.PlayerState, rivalId : Common.RivalId, stance : MilitaryTypes.DiplomaticStance) : Common.ActionResult {
    if (not state.rivals.any(func r = r.id == rivalId)) {
      return #err("Unknown rival");
    };
    state.rivals := state.rivals.map(
      func r { if (r.id == rivalId) { { r with stance } } else { r } }
    );
    #ok;
  };

  /// Resolve combat between two of the player's units.
  public func resolveCombat(state : WorldTypes.PlayerState, attackerId : Common.UnitId, defenderId : Common.UnitId) : MilitaryTypes.CombatResult {
    let attacker = switch (state.units.find(func u = u.id == attackerId)) {
      case (?u) { u };
      case null {
        return { attackerWon = false; attackerLosses = 0; defenderLosses = 0; summary = "Attacker unit not found" };
      };
    };
    let defender = switch (state.units.find(func u = u.id == defenderId)) {
      case (?u) { u };
      case null {
        return { attackerWon = false; attackerLosses = 0; defenderLosses = 0; summary = "Defender unit not found" };
      };
    };
    let attackerPower = attacker.strength + (attackerId % 5);
    let defenderPower = defender.strength + (defenderId % 5);
    let attackerWon = attackerPower >= defenderPower;
    let attackerLosses = if (attackerWon) { defenderPower / 4 } else { attacker.strength };
    let defenderLosses = if (attackerWon) { defender.strength } else { attackerPower / 4 };
    if (attackerWon) {
      state.units := state.units.filter(func u = u.id != defenderId).map(
        func u { if (u.id == attackerId) { { u with strength = subFloor(u.strength, attackerLosses) } } else { u } }
      );
    } else {
      state.units := state.units.filter(func u = u.id != attackerId).map(
        func u { if (u.id == defenderId) { { u with strength = subFloor(u.strength, defenderLosses) } } else { u } }
      );
    };
    {
      attackerWon;
      attackerLosses;
      defenderLosses;
      summary = if (attackerWon) {
        "Attacker " # attacker.kind # " defeated defender " # defender.kind;
      } else {
        "Defender " # defender.kind # " repelled attacker " # attacker.kind;
      };
    };
  };

  /// The set of technology ids the player has already researched.
  func researchedSet(state : WorldTypes.PlayerState) : Map.Map<Common.TechId, Bool> {
    let set = Map.empty<Common.TechId, Bool>();
    for (tech in state.technologies.values()) {
      if (tech.unlocked) { set.add(tech.id, true) };
    };
    set;
  };
};
