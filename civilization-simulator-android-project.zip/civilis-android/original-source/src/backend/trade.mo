import Common "types/common";
import WorldTypes "types/world";
import TradeTypes "types/trade";
import MilitaryTypes "types/military";
import EconomyTypes "types/economy";
import TradeLib "lib/trade";

/// Nation trading domain: opening and cancelling trade offers, deterministic
/// rival evaluation (accept / reject / counter), one-off settlement, and
/// recurring standing agreements.
///
/// This is a plain module (no shared functions). The public API mixin lives in
/// `mixins/trade-api.mo` and the composition root passes the shared per-player
/// state map.
module {
  // ---------------------------------------------------------------------------
  // Re-exported types
  // ---------------------------------------------------------------------------

  public type ResourceBundle = TradeTypes.ResourceBundle;
  public type TradeStatus = TradeTypes.TradeStatus;
  public type TradeOffer = TradeTypes.TradeOffer;
  public type CounterOffer = TradeTypes.CounterOffer;
  public type StandingAgreement = TradeTypes.StandingAgreement;
  public type TradeHistoryEntry = TradeTypes.TradeHistoryEntry;
  public type Evaluation = TradeLib.Evaluation;

  // ---------------------------------------------------------------------------
  // Offers
  // ---------------------------------------------------------------------------

  /// Open a trade offer with a known rival, evaluated deterministically.
  public func openOffer(
    state : WorldTypes.PlayerState,
    partnerId : Common.RivalId,
    offered : ResourceBundle,
    requested : ResourceBundle,
    gold : Nat,
  ) : Common.ActionResult {
    TradeLib.openOffer(state, partnerId, offered, requested, gold);
  };

  /// Cancel a pending or countered trade offer.
  public func cancelOffer(state : WorldTypes.PlayerState, offerId : Nat) : Common.ActionResult {
    TradeLib.cancelOffer(state, offerId);
  };

  /// Accept a countered offer, transferring the rival's revised terms.
  public func acceptCounter(state : WorldTypes.PlayerState, offerId : Nat) : Common.ActionResult {
    TradeLib.acceptCounter(state, offerId);
  };

  /// List the player's trade offers.
  public func listOffers(state : WorldTypes.PlayerState) : [TradeOffer] {
    TradeLib.listOffers(state);
  };

  /// List the player's completed-trade history.
  public func listHistory(state : WorldTypes.PlayerState) : [TradeHistoryEntry] {
    TradeLib.listHistory(state);
  };

  // ---------------------------------------------------------------------------
  // Standing agreements
  // ---------------------------------------------------------------------------

  /// Create a standing agreement that exchanges a bundle every simulation tick.
  public func createAgreement(
    state : WorldTypes.PlayerState,
    partnerId : Common.RivalId,
    perTick : ResourceBundle,
    goldPerTick : Nat,
  ) : Common.ActionResult {
    TradeLib.createAgreement(state, partnerId, perTick, goldPerTick);
  };

  /// Cancel a standing agreement.
  public func cancelAgreement(state : WorldTypes.PlayerState, agreementId : Nat) : Common.ActionResult {
    TradeLib.cancelAgreement(state, agreementId);
  };

  /// List the player's standing agreements.
  public func listAgreements(state : WorldTypes.PlayerState) : [StandingAgreement] {
    TradeLib.listAgreements(state);
  };

  /// Apply every active standing agreement for one simulation tick.
  public func applyAgreements(state : WorldTypes.PlayerState) {
    TradeLib.applyAgreements(state);
  };

  // ---------------------------------------------------------------------------
  // Evaluation (exposed for the mixin's counter preview)
  // ---------------------------------------------------------------------------

  /// Deterministically evaluate an exchange from a rival's perspective.
  public func evaluate(
    rival : MilitaryTypes.Rival,
    economy : EconomyTypes.EconomyState,
    offered : ResourceBundle,
    requested : ResourceBundle,
    gold : Nat,
  ) : Evaluation {
    TradeLib.evaluate(rival, economy, offered, requested, gold);
  };
};
