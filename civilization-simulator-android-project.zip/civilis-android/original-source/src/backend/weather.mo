import Float "mo:core/Float";
import Nat "mo:core/Nat";
import Time "mo:core/Time";

import OutCall "mo:caffeineai-http-outcalls/outcall";

import Json "mo:jayson/Json";

/// Weather and crises domain logic: live real-world weather for the player's
/// location, weather effects on in-game outcomes, and the crisis /
/// environmental-disaster system with player choices and visible consequences.
///
/// This is a plain module (no shared functions). The public API mixin lives in
/// `mixins/world-api.mo` and the composition root passes the shared per-player
/// state map, the access-control state, and the outcall transform callback.
module {

  // ---------------------------------------------------------------------------
  // Shared types
  // ---------------------------------------------------------------------------

  /// Signed nanoseconds since the epoch (Time.now()).
  public type Timestamp = Int;

  /// The four playable eras, from Ancient to Information.
  public type Era = {
    #ancient;
    #industrial;
    #modern;
    #information;
  };

  /// The six strategic resource pools a civilization accumulates.
  public type ResourcePool = {
    food : Nat;
    production : Nat;
    gold : Nat;
    science : Nat;
    culture : Nat;
    influence : Nat;
  };

  /// A player's geographic location used to drive real-world weather.
  public type GeoLocation = {
    latitude : Float;
    longitude : Float;
    name : Text;
  };

  /// Generic outcome for a mutating game action.
  public type ActionResult = {
    #ok;
    #err : Text;
  };

  /// Live weather state derived from the player's real-world location.
  public type WeatherState = {
    location : ?GeoLocation;
    condition : Text;
    temperatureC : Float;
    windKph : Float;
    precipitationMm : Float;
    updatedAt : Timestamp;
  };

  /// A choice the player can make in response to a crisis.
  public type CrisisChoice = {
    id : Nat;
    name : Text;
    effect : CrisisEffect;
  };

  /// The effect of a crisis choice on game state.
  public type CrisisEffect = {
    resourceDelta : ResourcePool;
    stabilityDelta : Int;
    summary : Text;
  };

  /// A crisis or environmental disaster event.
  public type CrisisEvent = {
    id : Nat;
    kind : Text;
    title : Text;
    description : Text;
    choices : [CrisisChoice];
    resolved : Bool;
  };

  /// The outcome of applying a crisis choice, with the visible consequences.
  public type CrisisOutcome = {
    crisisId : Nat;
    choiceId : Nat;
    summary : Text;
    resourceDelta : ResourcePool;
    stabilityDelta : Int;
    severity : Nat;
  };

  /// Weather effects applied to in-game outcomes for the current conditions.
  public type WeatherEffects = {
    harvestMultiplier : Float;
    movementMultiplier : Float;
    energyDemandMultiplier : Float;
    summary : Text;
  };

  // ---------------------------------------------------------------------------
  // Internal state
  // ---------------------------------------------------------------------------

  /// The stored weather record for a player.
  public type WeatherRecord = {
    var location : ?GeoLocation;
    var condition : Text;
    var temperatureC : Float;
    var windKph : Float;
    var precipitationMm : Float;
    var updatedAt : Timestamp;
  };

  /// A stored crisis instance for a player.
  public type CrisisRecord = {
    id : Nat;
    kind : Text;
    title : Text;
    description : Text;
    choices : [CrisisChoice];
    var resolved : Bool;
  };

  /// Per-player world state: weather plus the active crisis queue.
  public type WorldState = {
    var weather : WeatherRecord;
    var crises : [CrisisRecord];
    var nextCrisisId : Nat;
  };

  /// The catalog entry describing a crisis archetype.
  public type CrisisTemplate = {
    kind : Text;
    title : Text;
    description : Text;
    choices : [CrisisChoice];
  };

  /// The player's civilization context used to scale crisis severity.
  public type CivContext = {
    era : Era;
    population : Nat;
    stability : Nat;
  };

  // ---------------------------------------------------------------------------
  // Constants
  // ---------------------------------------------------------------------------

  /// Open-Meteo current-conditions endpoint. The latitude/longitude query
  /// parameters are the server-side bound: one point, one small JSON object.
  let weatherBaseUrl = "https://api.open-meteo.com/v1/forecast";

  /// The response is a few hundred bytes; cap well below the 1 MB ceiling.
  let weatherMaxResponseBytes : Nat64 = 100_000;

  // ---------------------------------------------------------------------------
  // State construction
  // ---------------------------------------------------------------------------

  /// Build a fresh, empty world state for a player.
  public func newState() : WorldState {
    {
      var weather = {
        var location = null;
        var condition = "unknown";
        var temperatureC = 0.0;
        var windKph = 0.0;
        var precipitationMm = 0.0;
        var updatedAt = 0;
      };
      var crises = [];
      var nextCrisisId = 1;
    };
  };

  // ---------------------------------------------------------------------------
  // Weather
  // ---------------------------------------------------------------------------

  /// Format a float as a plain decimal for a URL query parameter.
  func floatToQuery(value : Float) : Text {
    value.format(#fix 4);
  };

  /// Build the Open-Meteo request URL for a location.
  func weatherUrl(location : GeoLocation) : Text {
    weatherBaseUrl
      # "?latitude=" # floatToQuery(location.latitude)
      # "&longitude=" # floatToQuery(location.longitude)
      # "&current=temperature_2m,wind_speed_10m,precipitation,weather_code";
  };

  /// Map a WMO weather code to a human-readable condition label.
  func conditionFromCode(code : Int) : Text {
    if (code == 0) { "clear" }
    else if (code == 1) { "mainly clear" }
    else if (code == 2) { "partly cloudy" }
    else if (code == 3) { "overcast" }
    else if (code == 45 or code == 48) { "fog" }
    else if (code >= 51 and code <= 57) { "drizzle" }
    else if (code >= 61 and code <= 67) { "rain" }
    else if (code >= 71 and code <= 77) { "snow" }
    else if (code >= 80 and code <= 82) { "rain showers" }
    else if (code >= 85 and code <= 86) { "snow showers" }
    else if (code >= 95 and code <= 99) { "thunderstorm" }
    else { "unknown" };
  };

  /// Look up a field in a decoded JSON object.
  func objectField(fields : [(Text, Json.Json)], name : Text) : ?Json.Json {
    switch (fields.find(func entry = entry.0 == name)) {
      case (?entry) { ?entry.1 };
      case null { null };
    };
  };

  /// Read a numeric field from a decoded JSON object, accepting Int or Float.
  func numberField(fields : [(Text, Json.Json)], name : Text) : ?Float {
    switch (objectField(fields, name)) {
      case (?#Number(#Int(int))) { ?int.toFloat() };
      case (?#Number(#Float(float))) { ?float };
      case _ { null };
    };
  };

  /// Parse the Open-Meteo response body into a weather reading.
  func parseWeather(body : Text) : ?(Text, Float, Float, Float) {
    let ?root = Json.parse(body) else return null;
    let ?rootFields = switch (root) {
      case (#Object(fields)) { ?fields };
      case _ { null };
    } else return null;
    let ?currentJson = objectField(rootFields, "current") else return null;
    let ?current = switch (currentJson) {
      case (#Object(fields)) { ?fields };
      case _ { null };
    } else return null;

    let ?temperature = numberField(current, "temperature_2m") else return null;
    let ?wind = numberField(current, "wind_speed_10m") else return null;
    let ?precipitation = numberField(current, "precipitation") else return null;
    let code = switch (numberField(current, "weather_code")) {
      case (?value) { value.toInt() };
      case null { 0 };
    };

    ?(conditionFromCode(code), temperature, wind, precipitation);
  };

  /// Fetch live current conditions for a location through an HTTP outcall.
  /// Returns the parsed reading, or null when the provider is unreachable or
  /// the response cannot be parsed.
  public func fetchWeather(location : GeoLocation, transform : OutCall.Transform) : async ?(Text, Float, Float, Float) {
    let response = await OutCall.httpRequest({
      url = weatherUrl(location);
      method = #get;
      headers = [];
      body = null;
      maxResponseBytes = weatherMaxResponseBytes;
      transform;
    });
    if (response.status >= 300) { return null };
    let ?body = response.body.decodeUtf8() else return null;
    parseWeather(body);
  };

  /// Set the player's real-world location and refresh the weather reading.
  public func setLocation(state : WorldState, location : GeoLocation, transform : OutCall.Transform) : async ActionResult {
    state.weather.location := ?location;
    switch (await fetchWeather(location, transform)) {
      case (?(condition, temperature, wind, precipitation)) {
        state.weather.condition := condition;
        state.weather.temperatureC := temperature;
        state.weather.windKph := wind;
        state.weather.precipitationMm := precipitation;
        state.weather.updatedAt := Time.now();
        #ok;
      };
      case null {
        // Keep the location so the player can retry; report the fetch failure.
        #err("Could not fetch weather for this location");
      };
    };
  };

  /// Return the current weather state for a player.
  public func getWeather(state : WorldState) : WeatherState {
    {
      location = state.weather.location;
      condition = state.weather.condition;
      temperatureC = state.weather.temperatureC;
      windKph = state.weather.windKph;
      precipitationMm = state.weather.precipitationMm;
      updatedAt = state.weather.updatedAt;
    };
  };

  /// Derive in-game effects from the current weather reading.
  public func weatherEffects(state : WorldState) : WeatherEffects {
    let precipitation = state.weather.precipitationMm;
    let wind = state.weather.windKph;
    let temperature = state.weather.temperatureC;

    // Drought: no rain and hot. Flood: heavy rain. Storm: high wind.
    let harvest = if (precipitation < 0.5 and temperature > 30.0) { 0.6 }
      else if (precipitation > 20.0) { 0.7 }
      else if (precipitation > 5.0) { 1.1 }
      else { 1.0 };

    let movement = if (wind > 60.0) { 0.5 }
      else if (precipitation > 20.0) { 0.7 }
      else if (temperature < -10.0) { 0.8 }
      else { 1.0 };

    let energy = if (temperature > 30.0) { 1.4 }
      else if (temperature < 0.0) { 1.5 }
      else { 1.0 };

    let summary = "Harvest x" # harvest.format(#fix 2)
      # ", movement x" # movement.format(#fix 2)
      # ", energy demand x" # energy.format(#fix 2);

    { harvestMultiplier = harvest; movementMultiplier = movement; energyDemandMultiplier = energy; summary };
  };

  // ---------------------------------------------------------------------------
  // Crises
  // ---------------------------------------------------------------------------

  /// Build a resource delta from individual amounts.
  func resources(food : Nat, production : Nat, gold : Nat, science : Nat, culture : Nat, influence : Nat) : ResourcePool {
    { food; production; gold; science; culture; influence };
  };

  /// The crisis catalog: droughts, floods, storms, wildfires, plagues,
  /// famines, economic crashes and political unrest. Each presents choices
  /// with trade-offs.
  func catalog() : [CrisisTemplate] {
    [
      {
        kind = "drought";
        title = "Drought";
        description = "A prolonged dry spell is withering the fields and draining the wells.";
        choices = [
          { id = 1; name = "Ration water and food"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = -1; summary = "Stores hold, but the people grumble." } },
          { id = 2; name = "Dig emergency wells"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = 1; summary = "Costly works buy goodwill and water." } },
        ];
      },
      {
        kind = "flood";
        title = "Flood";
        description = "Rivers have burst their banks, swamping farmland and roads.";
        choices = [
          { id = 1; name = "Build levees"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = 1; summary = "The levees hold back the worst of it." } },
          { id = 2; name = "Evacuate the lowlands"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = -1; summary = "Lives are saved, but the harvest is lost." } },
        ];
      },
      {
        kind = "storm";
        title = "Great Storm";
        description = "A violent storm is battering the coast and tearing at the settlements.";
        choices = [
          { id = 1; name = "Shelter in place"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = -1; summary = "The storm passes, leaving damage behind." } },
          { id = 2; name = "Mobilize repairs"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = 1; summary = "Swift repairs restore confidence." } },
        ];
      },
      {
        kind = "wildfire";
        title = "Wildfire";
        description = "Fire is sweeping through the forests and threatening the outskirts.";
        choices = [
          { id = 1; name = "Fight the fire"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = 1; summary = "The blaze is contained at great effort." } },
          { id = 2; name = "Let it burn out"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = -1; summary = "The fire burns itself out, scarring the land." } },
        ];
      },
      {
        kind = "plague";
        title = "Plague";
        description = "A sickness is spreading through the settlements, emptying the streets.";
        choices = [
          { id = 1; name = "Quarantine the sick"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = -1; summary = "The quarantine slows the spread but breeds resentment." } },
          { id = 2; name = "Fund healers"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = 1; summary = "The healers save many and earn the people's trust." } },
        ];
      },
      {
        kind = "famine";
        title = "Famine";
        description = "The granaries are empty and the people are starving.";
        choices = [
          { id = 1; name = "Open the royal stores"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = 1; summary = "The stores feed the hungry and steady the realm." } },
          { id = 2; name = "Impose rationing"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = -1; summary = "Rationing stretches the food but angers the people." } },
        ];
      },
      {
        kind = "economic_crash";
        title = "Economic Crash";
        description = "Markets have collapsed and trade has ground to a halt.";
        choices = [
          { id = 1; name = "Bail out the merchants"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = 1; summary = "The bailout steadies the markets." } },
          { id = 2; name = "Let the market correct"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = -1; summary = "The crash runs its course, ruining many." } },
        ];
      },
      {
        kind = "political_unrest";
        title = "Political Unrest";
        description = "Crowds are gathering in the squares, demanding change.";
        choices = [
          { id = 1; name = "Concede reforms"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = 1; summary = "Reforms calm the crowds and restore order." } },
          { id = 2; name = "Crack down"; effect = { resourceDelta = resources(0, 0, 0, 0, 0, 0); stabilityDelta = -1; summary = "The crackdown silences dissent for now." } },
        ];
      },
    ];
  };

  /// Scale a crisis severity by era and civilization size. Later eras and
  /// larger civilizations face harsher crises.
  func severityFor(context : CivContext) : Nat {
    let eraWeight = switch (context.era) {
      case (#ancient) { 1 };
      case (#industrial) { 2 };
      case (#modern) { 3 };
      case (#information) { 4 };
    };
    // Population contributes one point per 1000 people, capped at 5.
    let popWeight = Nat.min(context.population / 1000, 5);
    eraWeight + popWeight;
  };

  /// Scale a resource delta by a severity factor.
  func scaleResources(pool : ResourcePool, severity : Nat) : ResourcePool {
    let factor = severity + 1;
    {
      food = pool.food * factor;
      production = pool.production * factor;
      gold = pool.gold * factor;
      science = pool.science * factor;
      culture = pool.culture * factor;
      influence = pool.influence * factor;
    };
  };

  /// Spawn a crisis of the given kind into the player's state, scaled by the
  /// civilization context. Returns the new crisis id.
  public func spawnCrisis(state : WorldState, kind : Text, context : CivContext) : Nat {
    let template = switch (catalog().find(func t = t.kind == kind)) {
      case (?found) { found };
      case null { catalog()[0] };
    };
    let severity = severityFor(context);
    let scaledChoices = template.choices.map(func choice = do {
      let scaled : CrisisChoice = {
        id = choice.id;
        name = choice.name;
        effect = {
          resourceDelta = scaleResources(choice.effect.resourceDelta, severity);
          stabilityDelta = choice.effect.stabilityDelta * (severity + 1);
          summary = choice.effect.summary;
        };
      };
      scaled;
    });
    let id = state.nextCrisisId;
    state.nextCrisisId := id + 1;
    let record : CrisisRecord = {
      id;
      kind = template.kind;
      title = template.title;
      description = template.description;
      choices = scaledChoices;
      var resolved = false;
    };
    state.crises := state.crises.concat([record]);
    id;
  };

  /// List the player's crisis events.
  public func listCrises(state : WorldState) : [CrisisEvent] {
    state.crises.map(func record = do {
      let event : CrisisEvent = {
        id = record.id;
        kind = record.kind;
        title = record.title;
        description = record.description;
        choices = record.choices;
        resolved = record.resolved;
      };
      event;
    });
  };

  /// Apply a crisis choice, returning the visible consequences. The caller
  /// applies the resource and stability deltas to the civilization.
  public func applyCrisisChoice(state : WorldState, crisisId : Nat, choiceId : Nat) : ?CrisisOutcome {
    let ?record = state.crises.find(func c = c.id == crisisId) else return null;
    if (record.resolved) { return null };
    let ?choice = record.choices.find(func c = c.id == choiceId) else return null;
    record.resolved := true;
    ?{
      crisisId;
      choiceId;
      summary = choice.effect.summary;
      resourceDelta = choice.effect.resourceDelta;
      stabilityDelta = choice.effect.stabilityDelta;
      severity = 1;
    };
  };
};
