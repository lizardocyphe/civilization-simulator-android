import Common "../types/common";
import SpaceTypes "../types/space";
import WorldTypes "../types/world";
import SpaceLib "../lib/space";
import Players "../lib/players";

mixin (state : WorldTypes.WorldState) {
  /// Launch an exploration mission to a coordinate, discovering a star system.
  public shared ({ caller }) func launchMission(coord : Common.HexCoord) : async Common.ActionResult {
    SpaceLib.launchMission(Players.playerFor(state, caller), coord);
  };

  /// Claim a discovered star system for the caller's civilization.
  public shared ({ caller }) func claimSystem(systemId : Nat) : async Common.ActionResult {
    SpaceLib.claimSystem(Players.playerFor(state, caller), systemId);
  };

  /// Colonize a claimed star system to increase its resource yield.
  public shared ({ caller }) func colonizeSystem(systemId : Nat) : async Common.ActionResult {
    SpaceLib.colonizeSystem(Players.playerFor(state, caller), systemId);
  };

  /// Build a fleet at a star system the caller owns.
  public shared ({ caller }) func buildFleet(systemId : Nat, ships : Nat) : async Common.ActionResult {
    SpaceLib.buildFleet(Players.playerFor(state, caller), systemId, ships);
  };

  /// Move a fleet to another discovered star system within range.
  public shared ({ caller }) func moveFleet(fleetId : Nat, targetSystemId : Nat) : async Common.ActionResult {
    SpaceLib.moveFleet(Players.playerFor(state, caller), fleetId, targetSystemId);
  };

  /// Engage a hostile fleet or defended system and return the battle outcome.
  public shared ({ caller }) func resolveSpaceBattle(fleetId : Nat, targetSystemId : Nat) : async SpaceTypes.SpaceBattleResult {
    SpaceLib.resolveSpaceBattle(Players.playerFor(state, caller), fleetId, targetSystemId);
  };

  /// List the star systems the caller has charted.
  public query ({ caller }) func listSystems() : async [SpaceTypes.StarSystem] {
    SpaceLib.listSystems(Players.playerFor(state, caller));
  };

  /// List the caller's fleets.
  public query ({ caller }) func listFleets() : async [SpaceTypes.Fleet] {
    SpaceLib.listFleets(Players.playerFor(state, caller));
  };
};
