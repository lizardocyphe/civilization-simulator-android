import Common "../types/common";
import SimulationTypes "../types/simulation";
import WorldTypes "../types/world";
import Ai "../ai";
import Players "../lib/players";

/// Public API for the offline AI opponent domain.
///
/// Takes the shared `WorldState` as a parameter, following the existing mixin
/// pattern, and resolves the caller's player record through the shared
/// per-caller lookup helper in `lib/players.mo` (called qualified).
mixin (state : WorldTypes.WorldState) {
  /// Run one AI evaluation for the caller's rivals on the current tick.
  /// Returns the activity entries recorded this tick.
  public shared ({ caller }) func runAiTick() : async [SimulationTypes.AiActivity] {
    Ai.runTick(Players.playerFor(state, caller));
  };

  /// The caller's AI activity log, newest entries last.
  public query ({ caller }) func listAiActivity() : async [SimulationTypes.AiActivity] {
    Ai.listActivity(Players.playerFor(state, caller));
  };

  /// The most recent AI decision the caller's rivals made, if any.
  public query ({ caller }) func getAiDecision() : async ?SimulationTypes.AiDecision {
    Ai.lastDecision(Players.playerFor(state, caller));
  };

  /// The caller's current AI difficulty setting.
  public query ({ caller }) func getAiDifficulty() : async SimulationTypes.AiDifficulty {
    Ai.getDifficulty(Players.playerFor(state, caller));
  };

  /// Set the caller's AI difficulty.
  public shared ({ caller }) func setAiDifficulty(difficulty : SimulationTypes.AiDifficulty) : async Common.ActionResult {
    Ai.setDifficulty(Players.playerFor(state, caller), difficulty);
  };
};
