import Common "../types/common";
import TechTypes "../types/tech";
import WorldTypes "../types/world";
import TechLib "../lib/tech";
import Players "../lib/players";

mixin (state : WorldTypes.WorldState) {
  /// Begin researching a technology.
  public shared ({ caller }) func researchTechnology(techId : Common.TechId) : async Common.ActionResult {
    TechLib.researchTechnology(Players.playerFor(state, caller), techId);
  };

  /// Advance to the next era if the milestone is met.
  public shared ({ caller }) func advanceEra() : async Common.ActionResult {
    TechLib.advanceEra(Players.playerFor(state, caller));
  };

  /// List all technologies and their unlock state.
  public query ({ caller }) func listTechnologies() : async [TechTypes.Technology] {
    TechLib.listTechnologies(Players.playerFor(state, caller));
  };

  /// List the era milestone requirements.
  public query ({ caller }) func listMilestones() : async [TechTypes.EraMilestone] {
    TechLib.listMilestones();
  };
};
