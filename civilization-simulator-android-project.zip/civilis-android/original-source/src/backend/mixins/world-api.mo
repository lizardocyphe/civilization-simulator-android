import Principal "mo:core/Principal";
import OutCall "mo:caffeineai-http-outcalls/outcall";
import Common "../types/common";
import WorldTypes "../types/world";
import WorldLib "../lib/world";
import Players "../lib/players";
import Weather "../weather";

mixin (state : WorldTypes.WorldState, transform : OutCall.Transform) {
  /// Resolve the caller's live weather record, creating it on first use.
  func weatherFor(caller : Principal) : Weather.WorldState {
    switch (state.weather.get(caller)) {
      case (?w) { w };
      case null {
        let fresh = Weather.newState();
        state.weather.add(caller, fresh);
        fresh;
      };
    };
  };

  // ---------------------------------------------------------------------------
  // Weather
  // ---------------------------------------------------------------------------

  /// Set the player's real-world location and fetch live weather for it.
  public shared ({ caller }) func setLocation(location : Common.GeoLocation) : async Common.ActionResult {
    await Weather.setLocation(weatherFor(caller), location, transform);
  };

  /// Return the current weather state.
  public query ({ caller }) func getWeather() : async WorldTypes.WeatherState {
    let w = weatherFor(caller);
    {
      location = w.weather.location;
      condition = w.weather.condition;
      temperatureC = w.weather.temperatureC;
      windKph = w.weather.windKph;
      precipitationMm = w.weather.precipitationMm;
      updatedAt = w.weather.updatedAt;
    };
  };

  /// Derive in-game effects from the current weather reading.
  public query ({ caller }) func getWeatherEffects() : async Weather.WeatherEffects {
    Weather.weatherEffects(weatherFor(caller));
  };

  // ---------------------------------------------------------------------------
  // Crises
  // ---------------------------------------------------------------------------

  /// List the player's crisis events.
  public query ({ caller }) func listCrises() : async [Weather.CrisisEvent] {
    Weather.listCrises(weatherFor(caller));
  };

  /// Spawn a crisis of the given kind, scaled by the player's civilization.
  public shared ({ caller }) func spawnCrisis(kind : Text) : async Nat {
    let player = Players.playerFor(state, caller);
    let context : Weather.CivContext = switch (player.game) {
      case (?g) {
        {
          era = g.civilization.era;
          population = player.settlements.foldLeft(0, func(acc, s) = acc + s.population);
          stability = g.civilization.stability;
        };
      };
      case null { { era = #ancient; population = 0; stability = 0 } };
    };
    Weather.spawnCrisis(weatherFor(caller), kind, context);
  };

  /// Apply a crisis choice and return its visible consequences.
  public shared ({ caller }) func applyCrisisChoice(crisisId : Common.CrisisId, choiceId : Nat) : async ?Weather.CrisisOutcome {
    Weather.applyCrisisChoice(weatherFor(caller), crisisId, choiceId);
  };

  // ---------------------------------------------------------------------------
  // Economy
  // ---------------------------------------------------------------------------

  /// Trade resources with a discovered rival.
  public shared ({ caller }) func trade(partnerId : Common.RivalId, resource : Text, amount : Nat) : async Common.ActionResult {
    WorldLib.trade(Players.playerFor(state, caller), partnerId, resource, amount);
  };
};
