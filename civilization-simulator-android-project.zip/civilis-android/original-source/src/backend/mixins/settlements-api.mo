import Common "../types/common";
import SettlementTypes "../types/settlements";
import WorldTypes "../types/world";
import SettlementLib "../lib/settlements";
import Players "../lib/players";

mixin (state : WorldTypes.WorldState) {
  /// Found a new settlement at a coordinate.
  public shared ({ caller }) func foundSettlement(name : Text, position : Common.HexCoord) : async Common.ActionResult {
    SettlementLib.foundSettlement(Players.playerFor(state, caller), name, position);
  };

  /// Assign a population unit to work a tile.
  public shared ({ caller }) func assignPopulation(settlementId : Common.SettlementId, tileId : Common.TileId) : async Common.ActionResult {
    SettlementLib.assignPopulation(Players.playerFor(state, caller), settlementId, tileId);
  };

  /// Construct a building in a settlement.
  public shared ({ caller }) func constructBuilding(settlementId : Common.SettlementId, kind : Text) : async Common.ActionResult {
    SettlementLib.constructBuilding(Players.playerFor(state, caller), settlementId, kind);
  };

  /// List the caller's settlements.
  public query ({ caller }) func listSettlements() : async [SettlementTypes.Settlement] {
    SettlementLib.listSettlements(Players.playerFor(state, caller));
  };
};
