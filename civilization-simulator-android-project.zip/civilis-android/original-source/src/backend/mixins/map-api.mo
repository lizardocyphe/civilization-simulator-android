import Common "../types/common";
import MapTypes "../types/map";
import WorldTypes "../types/world";
import MapLib "../lib/map";
import Players "../lib/players";

mixin (state : WorldTypes.WorldState) {
  /// Return the current hex map.
  public query ({ caller }) func getMap() : async MapTypes.HexMap {
    MapLib.getMap(Players.playerFor(state, caller));
  };

  /// Reveal tiles around a coordinate.
  public shared ({ caller }) func revealAround(coord : Common.HexCoord, radius : Nat) : async () {
    MapLib.revealAround(Players.playerFor(state, caller), coord, radius);
  };
};
