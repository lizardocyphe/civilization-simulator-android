import Common "../types/common";
import WorldTypes "../types/world";
import EconomyTypes "../types/economy";
import EconomyLib "../lib/economy";
import Players "../lib/players";

mixin (state : WorldTypes.WorldState) {
  /// Return the caller's current macro-economic state.
  public query ({ caller }) func getEconomy() : async EconomyTypes.EconomyState {
    EconomyLib.getEconomy(Players.playerFor(state, caller));
  };

  /// Return the caller's recorded per-tick economic history for trend display.
  public query ({ caller }) func getEconomyHistory() : async [EconomyTypes.EconomyTick] {
    EconomyLib.history(Players.playerFor(state, caller));
  };

  /// List the fiscal and monetary policies the player can adopt.
  public query func listEconomicPolicies() : async [EconomyTypes.EconomicPolicy] {
    EconomyLib.policies();
  };

  /// Apply an economic policy to the caller's economy.
  public shared ({ caller }) func applyEconomicPolicy(policyId : Nat) : async Common.ActionResult {
    EconomyLib.applyPolicy(Players.playerFor(state, caller), policyId);
  };

  /// Advance the caller's economy one tick and return the new state.
  public shared ({ caller }) func advanceEconomy() : async EconomyTypes.EconomyState {
    EconomyLib.tick(Players.playerFor(state, caller));
  };

  /// Scale a base cost by the caller's current price level, so every cost the
  /// player sees reflects inflation or deflation.
  public query ({ caller }) func scaledCost(baseCost : Nat) : async Nat {
    EconomyLib.scaleCost(Players.playerFor(state, caller), baseCost);
  };
};
