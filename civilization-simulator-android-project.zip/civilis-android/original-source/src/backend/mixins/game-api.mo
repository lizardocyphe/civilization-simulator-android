import Common "../types/common";
import GameTypes "../types/game";
import WorldTypes "../types/world";
import GameLib "../lib/game";
import Players "../lib/players";

mixin (state : WorldTypes.WorldState) {
  /// Start a new game with a civilization name and starting era.
  public shared ({ caller }) func startGame(name : Text, era : Common.Era) : async GameTypes.GameState {
    GameLib.startGame(Players.playerFor(state, caller), name, era);
  };

  /// Load the saved game for the caller.
  public query ({ caller }) func loadGame() : async ?GameTypes.GameState {
    GameLib.loadGame(Players.playerFor(state, caller));
  };

  /// End the current turn and return the turn summary.
  public shared ({ caller }) func endTurn() : async GameTypes.TurnSummary {
    GameLib.endTurn(Players.playerFor(state, caller));
  };

  /// Choose a policy to adopt.
  public shared ({ caller }) func choosePolicy(policyId : Nat) : async Common.ActionResult {
    GameLib.choosePolicy(Players.playerFor(state, caller), policyId);
  };
};
