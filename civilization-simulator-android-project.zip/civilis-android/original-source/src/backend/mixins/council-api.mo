import Nat "mo:core/Nat";
import Common "../types/common";
import CouncilTypes "../types/council";
import SimulationTypes "../types/simulation";
import WorldTypes "../types/world";
import CouncilLib "../lib/council";
import Inference "../lib/inference";
import Players "../lib/players";

mixin (state : WorldTypes.WorldState) {
  /// Raise a council proposal of any kind and put it to a vote.
  public shared ({ caller }) func raiseProposal(kind : CouncilTypes.ProposalKind, description : Text) : async CouncilTypes.Proposal {
    CouncilLib.raiseProposal(Players.playerFor(state, caller), kind, description);
  };

  /// List every proposal the caller has raised.
  public query ({ caller }) func listProposals() : async [CouncilTypes.Proposal] {
    CouncilLib.listProposals(Players.playerFor(state, caller));
  };

  /// List every resolution that has passed.
  public query ({ caller }) func listResolutions() : async [CouncilTypes.Resolution] {
    CouncilLib.listResolutions(Players.playerFor(state, caller));
  };

  /// The votes cast on a proposal, with each rival's stated reason.
  public query ({ caller }) func listVotes(proposalId : Nat) : async [CouncilTypes.Vote] {
    CouncilLib.listVotes(Players.playerFor(state, caller), proposalId);
  };

  /// Open a discussion with a rival and receive an AI-generated reply.
  /// Falls back to a deterministic rule-based reply if inference fails.
  public shared ({ caller }) func discussWithNation(rivalId : Common.RivalId, message : Text) : async SimulationTypes.DiscussionMessage {
    let player = Players.playerFor(state, caller);
    let rival = switch (CouncilLib.findRival(player, rivalId)) {
      case (?r) { r };
      case null { return { speaker = "Council"; nation = rivalId; text = "Unknown nation."; tick = 0 } };
    };
    CouncilLib.recordMessage(player, "You", rivalId, message);

    let prompt = "You are the leader of the nation \"" # rival.name
      # "\" in a grand-strategy civilization game. Your diplomatic stance toward the player is "
      # CouncilLib.stanceLabel(rival.stance) # " and your military strength is " # rival.strength.toText()
      # ". The player says: \"" # message
      # "\". Reply in character in two or three sentences, stating your position and what you want.";

    let reply = try {
      await* Inference.runChat<system>(prompt);
    } catch (_) {
      CouncilLib.fallbackReply(rival, message);
    };

    CouncilLib.recordMessage(player, rival.name, rivalId, reply);
    { speaker = rival.name; nation = rivalId; text = reply; tick = player.clock.tick };
  };

  /// The full discussion thread for the caller.
  public query ({ caller }) func listDiscussions() : async [SimulationTypes.DiscussionMessage] {
    CouncilLib.listDiscussions(Players.playerFor(state, caller));
  };
};
