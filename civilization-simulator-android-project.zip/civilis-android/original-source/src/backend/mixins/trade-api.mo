import Common "../types/common";
import WorldTypes "../types/world";
import TradeTypes "../types/trade";
import TradeLib "../lib/trade";
import Players "../lib/players";

mixin (state : WorldTypes.WorldState) {
  // ---------------------------------------------------------------------------
  // Offers
  // ---------------------------------------------------------------------------

  /// Open a trade offer with a known rival proposing an exchange of resources
  /// and gold. The rival evaluates it deterministically and the offer resolves
  /// to accepted, rejected or countered.
  public shared ({ caller }) func openTradeOffer(
    partnerId : Common.RivalId,
    offered : TradeTypes.ResourceBundle,
    requested : TradeTypes.ResourceBundle,
    gold : Nat,
  ) : async Common.ActionResult {
    TradeLib.openOffer(Players.playerFor(state, caller), partnerId, offered, requested, gold);
  };

  /// Cancel a pending or countered trade offer.
  public shared ({ caller }) func cancelTradeOffer(offerId : Nat) : async Common.ActionResult {
    TradeLib.cancelOffer(Players.playerFor(state, caller), offerId);
  };

  /// Accept a countered offer, transferring the rival's revised terms.
  public shared ({ caller }) func acceptTradeCounter(offerId : Nat) : async Common.ActionResult {
    TradeLib.acceptCounter(Players.playerFor(state, caller), offerId);
  };

  /// List the caller's trade offers.
  public query ({ caller }) func listTradeOffers() : async [TradeTypes.TradeOffer] {
    TradeLib.listOffers(Players.playerFor(state, caller));
  };

  /// List the caller's completed-trade history.
  public query ({ caller }) func listTradeHistory() : async [TradeTypes.TradeHistoryEntry] {
    TradeLib.listHistory(Players.playerFor(state, caller));
  };

  // ---------------------------------------------------------------------------
  // Standing agreements
  // ---------------------------------------------------------------------------

  /// Create a standing agreement that exchanges a bundle every simulation tick.
  public shared ({ caller }) func createTradeAgreement(
    partnerId : Common.RivalId,
    perTick : TradeTypes.ResourceBundle,
    goldPerTick : Nat,
  ) : async Common.ActionResult {
    TradeLib.createAgreement(Players.playerFor(state, caller), partnerId, perTick, goldPerTick);
  };

  /// Cancel a standing agreement.
  public shared ({ caller }) func cancelTradeAgreement(agreementId : Nat) : async Common.ActionResult {
    TradeLib.cancelAgreement(Players.playerFor(state, caller), agreementId);
  };

  /// List the caller's standing agreements.
  public query ({ caller }) func listTradeAgreements() : async [TradeTypes.StandingAgreement] {
    TradeLib.listAgreements(Players.playerFor(state, caller));
  };
};
