import Common "../types/common";
import MilitaryTypes "../types/military";
import WorldTypes "../types/world";
import MilitaryLib "../lib/military";
import Players "../lib/players";

mixin (state : WorldTypes.WorldState) {
  /// Recruit a new unit at a coordinate.
  public shared ({ caller }) func recruitUnit(kind : Text, position : Common.HexCoord) : async Common.ActionResult {
    MilitaryLib.recruitUnit(Players.playerFor(state, caller), kind, position);
  };

  /// Resolve combat between two units.
  public shared ({ caller }) func resolveCombat(attackerId : Common.UnitId, defenderId : Common.UnitId) : async MilitaryTypes.CombatResult {
    MilitaryLib.resolveCombat(Players.playerFor(state, caller), attackerId, defenderId);
  };

  /// Set the diplomatic stance toward a rival.
  public shared ({ caller }) func setDiplomacy(rivalId : Common.RivalId, stance : MilitaryTypes.DiplomaticStance) : async Common.ActionResult {
    MilitaryLib.setDiplomacy(Players.playerFor(state, caller), rivalId, stance);
  };

  /// List the caller's units.
  public query ({ caller }) func listUnits() : async [MilitaryTypes.Unit] {
    MilitaryLib.listUnits(Players.playerFor(state, caller));
  };

  /// List the known rivals.
  public query ({ caller }) func listRivals() : async [MilitaryTypes.Rival] {
    MilitaryLib.listRivals(Players.playerFor(state, caller));
  };
};
