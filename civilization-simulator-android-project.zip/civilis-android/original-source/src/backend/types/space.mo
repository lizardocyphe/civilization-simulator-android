import Common "common";

module {
  /// A star system on the space map.
  public type StarSystem = {
    id : Nat;
    name : Text;
    coord : Common.HexCoord;
    discovered : Bool;
    claimed : Bool;
    owner : ?Common.GameId;
    planets : Nat;
    resourceYield : Common.ResourcePool;
    defense : Nat;
  };

  /// A fleet of ships travelling between star systems.
  public type Fleet = {
    id : Nat;
    owner : Common.GameId;
    systemId : Nat;
    ships : Nat;
    strength : Nat;
    movement : Nat;
  };

  /// The outcome of a space battle over a star system.
  public type SpaceBattleResult = {
    attackerWon : Bool;
    attackerLosses : Nat;
    defenderLosses : Nat;
    capturedSystem : ?Nat;
    summary : Text;
  };
};
