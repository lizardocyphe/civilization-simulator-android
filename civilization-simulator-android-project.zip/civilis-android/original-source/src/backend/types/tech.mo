import Common "common";

module {
  /// A researchable technology.
  public type Technology = {
    id : Common.TechId;
    name : Text;
    era : Common.Era;
    cost : Nat;
    prerequisites : [Common.TechId];
    unlocked : Bool;
  };

  /// The milestone requirements to advance into the next era.
  public type EraMilestone = {
    era : Common.Era;
    requiredTechs : [Common.TechId];
    requiredPopulation : Nat;
    requiredBuildings : Nat;
  };
};
