import Common "common";

module {
  /// How aggressively an autonomous AI opponent plays.
  public type AiDifficulty = {
    #passive;
    #balanced;
    #aggressive;
  };

  /// The kind of action an AI opponent took on a tick.
  public type AiActionKind = {
    #expand;
    #research;
    #build;
    #recruit;
    #attack;
    #trade;
    #diplomacy;
    #space;
    #idle;
  };

  /// One entry in the visible AI activity log: what a rival did and why.
  public type AiActivity = {
    tick : Nat;
    rival : Common.RivalId;
    action : AiActionKind;
    reasoning : Text;
  };

  /// A recorded AI decision, including the alternatives it considered.
  public type AiDecision = {
    tick : Nat;
    rival : Common.RivalId;
    action : AiActionKind;
    reasoning : Text;
    considered : [Text];
    score : Int;
  };

  /// Simulation speed for the pausable clock.
  public type SimSpeed = {
    #paused;
    #x1;
    #x2;
    #x4;
  };

  /// The simulation clock: tick index, in-game date, speed and run state.
  public type SimClock = {
    tick : Nat;
    date : Text;
    speed : SimSpeed;
    running : Bool;
    lastAdvanced : Common.Timestamp;
  };

  /// An order issued while the clock is paused, queued for the next tick.
  public type QueuedOrder = {
    id : Nat;
    kind : Text;
    payload : Text;
    issuedAt : Common.Timestamp;
  };

  /// A message in an AI-backed nation discussion thread.
  public type DiscussionMessage = {
    speaker : Text;
    nation : Common.RivalId;
    text : Text;
    tick : Nat;
  };
};
