import Common "common";

module {
  /// Terrain classification for a hex tile. The original ten terrains are
  /// extended with jungle, savanna, wetlands, volcanic, reef and mesa.
  public type Terrain = {
    #ocean;
    #coast;
    #grassland;
    #plains;
    #desert;
    #forest;
    #hills;
    #mountains;
    #tundra;
    #ice;
    #jungle;
    #savanna;
    #wetlands;
    #volcanic;
    #reef;
    #mesa;
  };

  /// Per-terrain yield and movement cost data.
  public type TerrainProfile = {
    terrain : Terrain;
    yield : Common.ResourcePool;
    movementCost : Nat;
  };

  /// A resource node sitting on a tile.
  public type ResourceNode = {
    kind : Text;
    amount : Nat;
    renewable : Bool;
  };

  /// The kind of resource a pocket yields.
  public type PocketKind = {
    #food;
    #production;
    #gold;
    #science;
    #culture;
    #influence;
  };

  /// A depletable resource pocket on a tile.
  public type ResourcePocket = {
    kind : PocketKind;
    remaining : Nat;
    initial : Nat;
    renewalRate : Nat;
    renewable : Bool;
  };

  /// Visibility state of a tile for the player.
  public type FogState = {
    #unexplored;
    #explored;
    #visible;
  };

  /// A single hex tile on the world map.
  public type Tile = {
    id : Common.TileId;
    coord : Common.HexCoord;
    terrain : Terrain;
    resource : ?ResourceNode;
    pocket : ?ResourcePocket;
    fog : FogState;
    owner : ?Common.GameId;
  };

  /// The full hex map.
  public type HexMap = {
    width : Nat;
    height : Nat;
    tiles : [Tile];
  };
};
