module {
  /// Cross-cutting identifiers and shared scalar aliases for the whole game.
  public type GameId = Nat;
  public type TileId = Nat;
  public type SettlementId = Nat;
  public type BuildingId = Nat;
  public type UnitId = Nat;
  public type TechId = Nat;
  public type RivalId = Nat;
  public type CrisisId = Nat;

  /// Signed nanoseconds since the epoch (Time.now()).
  public type Timestamp = Int;

  /// Axial hex coordinates on the world map.
  public type HexCoord = { q : Int; r : Int };

  /// The four playable eras, from Ancient to Information.
  public type Era = {
    #ancient;
    #industrial;
    #modern;
    #information;
  };

  /// The six strategic resource pools a civilization accumulates.
  public type ResourcePool = {
    food : Nat;
    production : Nat;
    gold : Nat;
    science : Nat;
    culture : Nat;
    influence : Nat;
  };

  /// A player's geographic location used to drive real-world weather.
  public type GeoLocation = {
    latitude : Float;
    longitude : Float;
    name : Text;
  };

  /// Generic outcome for a mutating game action.
  public type ActionResult = {
    #ok;
    #err : Text;
  };
};
