import Common "common";

module {
  /// A bundle of resources exchanged in a trade.
  public type ResourceBundle = {
    food : Nat;
    production : Nat;
    gold : Nat;
    science : Nat;
    culture : Nat;
    influence : Nat;
  };

  /// The lifecycle state of a trade offer.
  public type TradeStatus = {
    #pending;
    #accepted;
    #rejected;
    #countered;
    #cancelled;
  };

  /// A trade offer between the player and a rival nation.
  public type TradeOffer = {
    id : Nat;
    partner : Common.RivalId;
    offered : ResourceBundle;
    requested : ResourceBundle;
    gold : Nat;
    status : TradeStatus;
    createdTick : Nat;
  };

  /// A counter-offer payload attached to a countered trade.
  public type CounterOffer = {
    offerId : Nat;
    offered : ResourceBundle;
    requested : ResourceBundle;
    gold : Nat;
    note : Text;
  };

  /// A standing agreement that exchanges a bundle every tick.
  public type StandingAgreement = {
    id : Nat;
    partner : Common.RivalId;
    perTick : ResourceBundle;
    goldPerTick : Nat;
    active : Bool;
    startedTick : Nat;
  };

  /// A completed trade recorded in the player's history.
  public type TradeHistoryEntry = {
    tick : Nat;
    partner : Common.RivalId;
    offered : ResourceBundle;
    requested : ResourceBundle;
    gold : Nat;
    summary : Text;
  };
};
