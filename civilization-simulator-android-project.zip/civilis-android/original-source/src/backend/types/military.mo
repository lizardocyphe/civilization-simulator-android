import Common "common";

module {
  /// A military unit on the map.
  public type Unit = {
    id : Common.UnitId;
    owner : Common.GameId;
    kind : Text;
    strength : Nat;
    movement : Nat;
    position : Common.HexCoord;
  };

  /// A rival civilization and the player's stance toward it.
  public type Rival = {
    id : Common.RivalId;
    name : Text;
    era : Common.Era;
    stance : DiplomaticStance;
    strength : Nat;
  };

  /// Diplomatic stance between the player and a rival.
  public type DiplomaticStance = {
    #war;
    #neutral;
    #peace;
    #alliance;
  };

  /// Outcome of a resolved combat.
  public type CombatResult = {
    attackerWon : Bool;
    attackerLosses : Nat;
    defenderLosses : Nat;
    summary : Text;
  };
};
