import Principal "mo:core/Principal";
import Map "mo:core/Map";
import Weather "../weather";
import Common "common";
import GameTypes "game";
import MapTypes "map";
import SettlementTypes "settlements";
import MilitaryTypes "military";
import TechTypes "tech";
import SimulationTypes "simulation";
import EconomyTypes "economy";
import TradeTypes "trade";
import SpaceTypes "space";
import CouncilTypes "council";

module {
  /// Live weather state derived from the player's real-world location.
  public type WeatherState = {
    location : ?Common.GeoLocation;
    condition : Text;
    temperatureC : Float;
    windKph : Float;
    precipitationMm : Float;
    updatedAt : Common.Timestamp;
  };

  /// A crisis or environmental disaster event.
  public type CrisisEvent = {
    id : Common.CrisisId;
    kind : Text;
    title : Text;
    description : Text;
    choices : [CrisisChoice];
    resolved : Bool;
  };

  /// A choice the player can make in response to a crisis.
  public type CrisisChoice = {
    id : Nat;
    name : Text;
    effect : CrisisEffect;
  };

  /// The effect of a crisis choice on game state.
  public type CrisisEffect = {
    resourceDelta : Common.ResourcePool;
    stabilityDelta : Int;
    summary : Text;
  };

  /// Per-player mutable game state. One record per principal, keyed in the
  /// actor's stable `players` map. All collections are arrays so the record is
  /// stable and shared by reference across mixins.
  public type PlayerState = {
    var game : ?GameTypes.GameState;
    var map : MapTypes.HexMap;
    var settlements : [SettlementTypes.Settlement];
    var units : [MilitaryTypes.Unit];
    var rivals : [MilitaryTypes.Rival];
    var technologies : [TechTypes.Technology];
    var weather : WeatherState;
    var crises : [CrisisEvent];
    var nextSettlementId : Nat;
    var nextUnitId : Nat;
    var nextCrisisId : Nat;
    // Simulation expansion state.
    var economy : EconomyTypes.EconomyState;
    var tradeOffers : [TradeTypes.TradeOffer];
    var tradeAgreements : [TradeTypes.StandingAgreement];
    var tradeHistory : [TradeTypes.TradeHistoryEntry];
    var clock : SimulationTypes.SimClock;
    var queuedOrders : [SimulationTypes.QueuedOrder];
    var spaceSystems : [SpaceTypes.StarSystem];
    var fleets : [SpaceTypes.Fleet];
    var proposals : [CouncilTypes.Proposal];
    var resolutions : [CouncilTypes.Resolution];
    var discussions : [SimulationTypes.DiscussionMessage];
    var aiDifficulty : SimulationTypes.AiDifficulty;
    var aiLog : [SimulationTypes.AiActivity];
    var nextTradeId : Nat;
    var nextOrderId : Nat;
    var nextFleetId : Nat;
    var nextProposalId : Nat;
  };

  /// The actor's shared stable state: one mutable player record per principal,
  /// plus the live weather/crisis record per principal.
  public type WorldState = {
    var players : Map.Map<Principal, PlayerState>;
    var weather : Map.Map<Principal, Weather.WorldState>;
  };
};
