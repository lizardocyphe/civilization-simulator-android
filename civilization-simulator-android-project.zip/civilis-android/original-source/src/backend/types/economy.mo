module {
  /// The macro-economic state of a civilization: money supply, prices,
  /// inflation, fiscal and monetary levers, and a short trend history.
  public type EconomyState = {
    moneySupply : Nat;
    priceLevel : Float;
    inflationRate : Float;
    taxRate : Float;
    interestRate : Float;
    spending : Nat;
    income : Nat;
    upkeep : Nat;
    history : [EconomyTick];
  };

  /// One recorded economic observation, used to draw the trend history.
  public type EconomyTick = {
    tick : Nat;
    moneySupply : Nat;
    priceLevel : Float;
    inflationRate : Float;
    income : Nat;
    upkeep : Nat;
  };

  /// A fiscal or monetary policy the player can adopt.
  public type EconomicPolicy = {
    id : Nat;
    name : Text;
    description : Text;
    taxRateDelta : Float;
    interestRateDelta : Float;
    spendingDelta : Int;
  };
};
