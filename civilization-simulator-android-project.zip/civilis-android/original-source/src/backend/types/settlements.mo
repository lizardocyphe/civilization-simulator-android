import Common "common";

module {
  /// A building constructed in a settlement.
  public type Building = {
    id : Common.BuildingId;
    name : Text;
    kind : Text;
    level : Nat;
    productionBonus : Common.ResourcePool;
  };

  /// A settlement founded by a civilization.
  public type Settlement = {
    id : Common.SettlementId;
    name : Text;
    owner : Common.GameId;
    position : Common.HexCoord;
    population : Nat;
    buildings : [Building];
    workedTiles : [Common.TileId];
    production : Common.ResourcePool;
  };
};
