import Common "common";

module {
  /// The kind of resolution a council proposal puts to a vote.
  public type ProposalKind = {
    #tradePact;
    #peace;
    #sanctions;
    #territorialClaim;
    #jointSpaceProgram;
  };

  /// The lifecycle state of a council proposal.
  public type ProposalStatus = {
    #open;
    #passed;
    #failed;
    #withdrawn;
  };

  /// A proposal put before the international council.
  public type Proposal = {
    id : Nat;
    sponsor : Common.RivalId;
    kind : ProposalKind;
    description : Text;
    status : ProposalStatus;
    votesFor : Nat;
    votesAgainst : Nat;
  };

  /// A single nation's vote on a proposal.
  public type Vote = {
    nation : Common.RivalId;
    inFavour : Bool;
    reason : Text;
  };

  /// A resolution that passed, with the effect it applied.
  public type Resolution = {
    id : Nat;
    proposalId : Nat;
    kind : ProposalKind;
    effect : Text;
    passedTick : Nat;
  };
};
