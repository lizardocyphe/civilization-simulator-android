import Common "common";

module {
  /// A civilization controlled by the player or a rival.
  public type Civilization = {
    id : Common.GameId;
    name : Text;
    era : Common.Era;
    resources : Common.ResourcePool;
    stability : Nat;
    researchPoints : Nat;
    policies : [Policy];
    isPlayer : Bool;
  };

  /// A policy the civilization has adopted.
  public type Policy = {
    id : Nat;
    name : Text;
    description : Text;
    effect : Text;
  };

  /// A full saved game snapshot.
  public type GameState = {
    id : Common.GameId;
    civilization : Civilization;
    turn : Nat;
    createdAt : Common.Timestamp;
    updatedAt : Common.Timestamp;
  };

  /// Summary returned at the end of a turn.
  public type TurnSummary = {
    turn : Nat;
    resourcesGained : Common.ResourcePool;
    events : [Text];
    stabilityDelta : Int;
  };
};
