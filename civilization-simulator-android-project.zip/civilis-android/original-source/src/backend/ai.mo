import Common "types/common";
import SimulationTypes "types/simulation";
import WorldTypes "types/world";
import AiLib "lib/ai";

/// Offline AI opponent domain module.
///
/// Thin domain facade over `lib/ai.mo`, mirroring the `progress.mo` pattern:
/// the mixin calls these functions with the caller's persisted `PlayerState`,
/// and this module forwards to the stateless AI logic. No network calls are
/// made anywhere in this domain.
module {
  /// Run one AI evaluation for the caller's rivals on the current tick.
  public func runTick(state : WorldTypes.PlayerState) : [SimulationTypes.AiActivity] {
    AiLib.runTick(state);
  };

  /// Evaluate every candidate action and pick the highest-scoring one.
  public func decide(state : WorldTypes.PlayerState) : SimulationTypes.AiDecision {
    AiLib.decide(state);
  };

  /// The caller's AI activity log, newest entries last.
  public func listActivity(state : WorldTypes.PlayerState) : [SimulationTypes.AiActivity] {
    AiLib.listActivity(state);
  };

  /// The caller's current AI difficulty setting.
  public func getDifficulty(state : WorldTypes.PlayerState) : SimulationTypes.AiDifficulty {
    AiLib.getDifficulty(state);
  };

  /// Set the caller's AI difficulty.
  public func setDifficulty(state : WorldTypes.PlayerState, difficulty : SimulationTypes.AiDifficulty) : Common.ActionResult {
    AiLib.setDifficulty(state, difficulty);
  };

  /// The most recent decision the AI made for the caller, if any.
  public func lastDecision(state : WorldTypes.PlayerState) : ?SimulationTypes.AiDecision {
    AiLib.lastDecision(state);
  };
};
