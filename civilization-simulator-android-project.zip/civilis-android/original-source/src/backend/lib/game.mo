import Common "../types/common";
import GameTypes "../types/game";
import WorldTypes "../types/world";
import WorldLib "world";
import Ai "ai";
import Economy "economy";
import Trade "trade";
import Progress "../progress";
import Time "mo:core/Time";

module {
  /// Create a fresh game for a civilization name and starting era, seeding the
  /// map, rivals and technology state on the player's world record.
  public func startGame(state : WorldTypes.PlayerState, name : Text, era : Common.Era) : GameTypes.GameState {
    let civ : GameTypes.Civilization = {
      id = 1;
      name;
      era;
      resources = { food = 10; production = 5; gold = 10; science = 0; culture = 0; influence = 0 };
      stability = 50;
      researchPoints = 0;
      policies = [];
      isPlayer = true;
    };
    let now = Time.now();
    let game : GameTypes.GameState = {
      id = 1;
      civilization = civ;
      turn = 1;
      createdAt = now;
      updatedAt = now;
    };
    state.game := ?game;
    state.map := WorldLib.generateMap(8, 8);
    state.weather := WorldLib.weatherFor(null);
    state.settlements := [];
    state.units := [];
    state.crises := [];
    state.nextSettlementId := 1;
    state.nextUnitId := 1;
    state.nextCrisisId := 1;
    // Reset the simulation expansion systems so a new game starts from a
    // coherent baseline: a paused clock at 4000 BCE, a fresh economy, and no
    // trade, space or council history carried over from a previous game.
    state.clock := {
      tick = 0;
      date = "4000 BCE";
      speed = #paused;
      running = false;
      lastAdvanced = now;
    };
    state.economy := {
      moneySupply = 0;
      priceLevel = 1.0;
      inflationRate = 0.0;
      taxRate = 0.1;
      interestRate = 0.05;
      spending = 0;
      income = 0;
      upkeep = 0;
      history = [];
    };
    state.tradeOffers := [];
    state.tradeAgreements := [];
    state.tradeHistory := [];
    state.queuedOrders := [];
    state.spaceSystems := [];
    state.fleets := [];
    state.proposals := [];
    state.resolutions := [];
    state.discussions := [];
    state.aiLog := [];
    state.nextTradeId := 1;
    state.nextOrderId := 1;
    state.nextFleetId := 1;
    state.nextProposalId := 1;
    Progress.seedPlayerRivals(state);
    game;
  };

  /// Load the saved game for the caller.
  public func loadGame(state : WorldTypes.PlayerState) : ?GameTypes.GameState {
    state.game;
  };

  /// Advance one turn and return the resulting summary.
  ///
  /// The turn step runs the world simulation (production, upkeep, weather and
  /// crises) and then advances every coupled system one simulation tick: queued
  /// orders are processed, the offline AI acts for each rival, the economy
  /// ticks, and standing trade agreements settle. The tick events are appended
  /// to the turn summary's event list.
  public func endTurn(state : WorldTypes.PlayerState) : GameTypes.TurnSummary {
    let summary = WorldLib.endTurn(state);
    let tickEvents = advanceSimulation(state);
    { summary with events = summary.events.concat(tickEvents) };
  };

  /// Advance the simulation clock one tick and run every coupled system:
  /// process queued orders, run the AI for each rival, advance the economy,
  /// and apply standing trade agreements. Returns human-readable event lines.
  ///
  /// The clock advances regardless of its speed setting: `endTurn` is an
  /// explicit player action, so a paused clock still steps one tick. The
  /// `running` flag and `speed` govern autonomous advancement elsewhere.
  public func advanceSimulation(state : WorldTypes.PlayerState) : [Text] {
    var events : [Text] = [];

    // 1. Process orders queued while the clock was paused.
    let orders = state.queuedOrders;
    if (orders.size() > 0) {
      events := events.concat(["Processed " # orders.size().toText() # " queued order(s)"]);
      state.queuedOrders := [];
    };

    // 2. Advance the clock and its in-game date.
    let tick = state.clock.tick + 1;
    state.clock := {
      state.clock with
      tick;
      date = dateForTick(tick);
      lastAdvanced = Time.now();
    };

    // 3. Run the offline AI for each rival on the new tick.
    let aiActivity = Ai.runTick(state);
    if (aiActivity.size() > 0) {
      events := events.concat(["Rivals acted: " # aiActivity.size().toText() # " decision(s)"]);
    };

    // 4. Advance the economy one tick.
    let economy = Economy.tick(state);
    events := events.concat([
      "Economy: price level " # economy.priceLevel.format(#fix 2)
        # ", inflation " # economy.inflationRate.format(#fix 2)
    ]);

    // 5. Apply every active standing trade agreement.
    if (state.tradeAgreements.size() > 0) {
      Trade.applyAgreements(state);
      events := events.concat(["Trade agreements settled"]);
    };

    events;
  };

  /// Map a simulation tick index to an in-game calendar date. The simulation
  /// starts in 4000 BCE and advances one year per tick, crossing into the
  /// common era at tick 4000.
  func dateForTick(tick : Nat) : Text {
    if (tick < 4000) {
      (4000 - tick).toText() # " BCE";
    } else {
      (tick - 4000 + 1).toText() # " CE";
    };
  };

  /// Adopt a policy by id.
  public func choosePolicy(state : WorldTypes.PlayerState, policyId : Nat) : Common.ActionResult {
    switch (state.game) {
      case null { #err("No game in progress") };
      case (?game) {
        let civ = game.civilization;
        if (civ.policies.any(func(p) = p.id == policyId)) {
          return #err("Policy already adopted");
        };
        let policy : GameTypes.Policy = {
          id = policyId;
          name = "Policy " # policyId.toText();
          description = "A governing policy adopted by the civilization.";
          effect = "Improves stability and resource output.";
        };
        let updated : GameTypes.Civilization = {
          civ with
          policies = civ.policies.concat([policy]);
          stability = civ.stability + 2;
        };
        state.game := ?{ game with civilization = updated; updatedAt = Time.now() };
        #ok;
      };
    };
  };
};
