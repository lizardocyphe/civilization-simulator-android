import Common "../types/common";
import CouncilTypes "../types/council";
import MilitaryTypes "../types/military";
import SimulationTypes "../types/simulation";
import WorldTypes "../types/world";

/// World council and AI-backed nation discussion domain.
///
/// Stateless: every function takes the caller's persisted `PlayerState` and
/// mutates it in place. Voting is deterministic and derived from each rival's
/// stance, strength and interests, so the council works fully offline. The
/// discussion reply is produced by the caller (the mixin) via Caffeine
/// Inference, with a deterministic rule-based fallback supplied here.
module {
  // ------------------------------------------------------------------
  // Proposal helpers
  // ------------------------------------------------------------------

  /// A human-readable label for a proposal kind.
  public func kindLabel(kind : CouncilTypes.ProposalKind) : Text {
    switch (kind) {
      case (#tradePact) { "Trade Pact" };
      case (#peace) { "Peace Treaty" };
      case (#sanctions) { "Sanctions" };
      case (#territorialClaim) { "Territorial Claim" };
      case (#jointSpaceProgram) { "Joint Space Program" };
    };
  };

  /// A human-readable label for a diplomatic stance.
  public func stanceLabel(stance : MilitaryTypes.DiplomaticStance) : Text {
    switch (stance) {
      case (#war) { "war" };
      case (#neutral) { "neutral" };
      case (#peace) { "peaceful" };
      case (#alliance) { "allied" };
    };
  };

  /// The effect text a passed resolution applies to all nations.
  func effectFor(kind : CouncilTypes.ProposalKind) : Text {
    switch (kind) {
      case (#tradePact) { "All nations open their markets: trade income rises for every signatory." };
      case (#peace) { "Hostilities cease: every nation's stance toward the others becomes peaceful." };
      case (#sanctions) { "Sanctions imposed: the targeted nation loses trade income and influence." };
      case (#territorialClaim) { "The claim is recognised: the sponsor's borders are acknowledged by the council." };
      case (#jointSpaceProgram) { "A joint space program is funded: all nations pool research toward orbital expansion." };
    };
  };

  /// The current simulation tick for the player, defaulting to 0.
  func currentTick(state : WorldTypes.PlayerState) : Nat {
    state.clock.tick;
  };

  // ------------------------------------------------------------------
  // Voting
  // ------------------------------------------------------------------

  /// Decide how a rival votes on a proposal, with a stated reason derived
  /// from its stance, strength and the proposal kind.
  func voteFor(rival : MilitaryTypes.Rival, kind : CouncilTypes.ProposalKind) : CouncilTypes.Vote {
    let (inFavour, reason) = switch (kind) {
      case (#tradePact) {
        switch (rival.stance) {
          case (#war) { (false, rival.name # " is at war and refuses to trade with an enemy.") };
          case (#neutral) { (true, rival.name # " sees mutual profit in open markets.") };
          case (#peace) { (true, rival.name # " welcomes deeper commercial ties.") };
          case (#alliance) { (true, rival.name # " trades freely with an ally.") };
        };
      };
      case (#peace) {
        switch (rival.stance) {
          case (#war) {
            if (rival.strength > 20) {
              (false, rival.name # " is winning and sees no reason to stop fighting.");
            } else {
              (true, rival.name # " is weary of war and accepts a truce.");
            };
          };
          case (#neutral) { (true, rival.name # " prefers stability over conflict.") };
          case (#peace) { (true, rival.name # " already at peace and endorses the treaty.") };
          case (#alliance) { (true, rival.name # " supports its ally's call for peace.") };
        };
      };
      case (#sanctions) {
        switch (rival.stance) {
          case (#war) { (true, rival.name # " is glad to isolate a rival power.") };
          case (#neutral) {
            if (rival.strength > 15) {
              (false, rival.name # " is strong enough to resist trade restrictions.");
            } else {
              (true, rival.name # " cannot afford to defy the council.") };
          };
          case (#peace) { (false, rival.name # " fears sanctions will hurt its own economy.") };
          case (#alliance) { (false, rival.name # " will not sanction a partner.") };
        };
      };
      case (#territorialClaim) {
        switch (rival.stance) {
          case (#war) { (false, rival.name # " contests the claim by force.") };
          case (#neutral) {
            if (rival.strength > 12) {
              (false, rival.name # " has its own ambitions in the disputed region.");
            } else {
              (true, rival.name # " lacks the strength to object.") };
          };
          case (#peace) { (true, rival.name # " accepts the claim to preserve the peace.") };
          case (#alliance) { (true, rival.name # " defers to its ally's claim.") };
        };
      };
      case (#jointSpaceProgram) {
        switch (rival.stance) {
          case (#war) { (false, rival.name # " will not share technology with an enemy.") };
          case (#neutral) {
            if (rival.strength > 18) {
              (false, rival.name # " prefers to pursue space alone.");
            } else {
              (true, rival.name # " joins the program to share the cost.") };
          };
          case (#peace) { (true, rival.name # " sees scientific value in cooperation.") };
          case (#alliance) { (true, rival.name # " commits fully to the joint venture.") };
        };
      };
    };
    { nation = rival.id; inFavour; reason };
  };

  /// Collect every rival's vote on a proposal.
  public func tallyVotes(state : WorldTypes.PlayerState, kind : CouncilTypes.ProposalKind) : [CouncilTypes.Vote] {
    state.rivals.map(func(r) = voteFor(r, kind));
  };

  // ------------------------------------------------------------------
  // Proposals and resolutions
  // ------------------------------------------------------------------

  /// Raise a council proposal and immediately put it to a vote. The proposal
  /// is recorded with its outcome; a passed proposal also records a
  /// resolution applying its effect to all nations.
  public func raiseProposal(state : WorldTypes.PlayerState, kind : CouncilTypes.ProposalKind, description : Text) : CouncilTypes.Proposal {
    let id = state.nextProposalId;
    state.nextProposalId := id + 1;

    let votes = tallyVotes(state, kind);
    let votesFor = votes.foldLeft(0, func(acc, v) = if (v.inFavour) { acc + 1 } else { acc });
    let votesAgainst = subFloor(votes.size(), votesFor);
    let passed = votesFor > votesAgainst;

    let proposal : CouncilTypes.Proposal = {
      id;
      sponsor = 0;
      kind;
      description;
      status = if (passed) { #passed } else { #failed };
      votesFor;
      votesAgainst;
    };
    state.proposals := state.proposals.concat([proposal]);

    if (passed) {
      let resolution : CouncilTypes.Resolution = {
        id = state.resolutions.size() + 1;
        proposalId = id;
        kind;
        effect = effectFor(kind);
        passedTick = currentTick(state);
      };
      state.resolutions := state.resolutions.concat([resolution]);
      applyEffect(state, kind);
    };

    proposal;
  };

  /// Apply a passed resolution's effect to the player's world state.
  func applyEffect(state : WorldTypes.PlayerState, kind : CouncilTypes.ProposalKind) : () {
    switch (kind) {
      case (#peace) {
        state.rivals := state.rivals.map(
          func(r) { if (r.stance == #war) { { r with stance = #peace } } else { r } }
        );
      };
      case (#tradePact) {
        state.rivals := state.rivals.map(
          func(r) { if (r.stance == #neutral) { { r with stance = #peace } } else { r } }
        );
      };
      case (#sanctions) {
        state.rivals := state.rivals.map(
          func(r) { if (r.stance == #neutral) { { r with strength = subFloor(r.strength, 2) } } else { r } }
        );
      };
      case (#territorialClaim) { () };
      case (#jointSpaceProgram) {
        state.rivals := state.rivals.map(
          func(r) { { r with strength = r.strength + 1 } }
        );
      };
    };
  };

  /// Saturating subtraction: never traps when `b` exceeds `a`.
  func subFloor(a : Nat, b : Nat) : Nat {
    if (a >= b) { a - b } else { 0 };
  };

  /// List every proposal the player has raised.
  public func listProposals(state : WorldTypes.PlayerState) : [CouncilTypes.Proposal] {
    state.proposals;
  };

  /// List every resolution that has passed.
  public func listResolutions(state : WorldTypes.PlayerState) : [CouncilTypes.Resolution] {
    state.resolutions;
  };

  /// The votes cast on a given proposal, with each rival's reason.
  public func listVotes(state : WorldTypes.PlayerState, proposalId : Nat) : [CouncilTypes.Vote] {
    switch (state.proposals.find(func(p) = p.id == proposalId)) {
      case (?p) { tallyVotes(state, p.kind) };
      case null { [] };
    };
  };

  // ------------------------------------------------------------------
  // Discussions
  // ------------------------------------------------------------------

  /// The deterministic rule-based reply used when the AI inference call is
  /// unavailable, so discussions still work offline.
  public func fallbackReply(rival : MilitaryTypes.Rival, message : Text) : Text {
    let stance = switch (rival.stance) {
      case (#war) { "Our armies stand ready; words will not move our borders." };
      case (#neutral) { "We will weigh your words against our own interests." };
      case (#peace) { "We value the peace between us and hear you." };
      case (#alliance) { "As your ally, we stand with you on this." };
    };
    rival.name # " considers your position: \"" # message # "\". " # stance;
  };

  /// Record a message in the discussion thread with a rival.
  public func recordMessage(state : WorldTypes.PlayerState, speaker : Text, nation : Common.RivalId, text : Text) : () {
    let message : SimulationTypes.DiscussionMessage = {
      speaker;
      nation;
      text;
      tick = currentTick(state);
    };
    state.discussions := state.discussions.concat([message]);
  };

  /// The full discussion thread for the player.
  public func listDiscussions(state : WorldTypes.PlayerState) : [SimulationTypes.DiscussionMessage] {
    state.discussions;
  };

  /// Find a rival by id.
  public func findRival(state : WorldTypes.PlayerState, rivalId : Common.RivalId) : ?MilitaryTypes.Rival {
    state.rivals.find(func(r) = r.id == rivalId);
  };
};
