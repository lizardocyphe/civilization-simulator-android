import Iter "mo:core/Iter";
import Principal "mo:core/Principal";
import Common "../types/common";
import WorldTypes "../types/world";
import SettlementTypes "../types/settlements";
import MilitaryTypes "../types/military";
import TechTypes "../types/tech";
import EconomyTypes "../types/economy";
import TradeTypes "../types/trade";
import SpaceTypes "../types/space";
import CouncilTypes "../types/council";
import SimulationTypes "../types/simulation";

/// Row sources for the OQL layer.
///
/// Every queryable collection lives inside a per-player `PlayerState` held in
/// the actor's `world.players` map, keyed by the owner principal. OQL entities
/// need a flat row iterator, so each function here flattens one collection into
/// `(owner, record)` pairs. The owner principal becomes a synthetic `owner`
/// column on the entity, which is what per-user scoping checks against.
///
/// This module is stateless and read-only: it never mutates player state.
module {
  /// A row tagged with the principal that owns it.
  public type Owned<T> = (Principal, T);

  /// Flatten every player's settlements into owned rows.
  public func settlements(state : WorldTypes.WorldState) : Iter.Iter<Owned<SettlementTypes.Settlement>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.settlements.values().map(func(s) = (owner, s))
    );
  };

  /// Flatten every player's units into owned rows.
  public func units(state : WorldTypes.WorldState) : Iter.Iter<Owned<MilitaryTypes.Unit>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.units.values().map(func(u) = (owner, u))
    );
  };

  /// Flatten every player's known rivals into owned rows.
  public func rivals(state : WorldTypes.WorldState) : Iter.Iter<Owned<MilitaryTypes.Rival>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.rivals.values().map(func(r) = (owner, r))
    );
  };

  /// Flatten every player's researched technologies into owned rows.
  public func technologies(state : WorldTypes.WorldState) : Iter.Iter<Owned<TechTypes.Technology>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.technologies.values().map(func(t) = (owner, t))
    );
  };

  /// Flatten every player's crisis events into owned rows.
  public func crises(state : WorldTypes.WorldState) : Iter.Iter<Owned<WorldTypes.CrisisEvent>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.crises.values().map(func(c) = (owner, c))
    );
  };

  /// Flatten every player's trade offers into owned rows.
  public func tradeOffers(state : WorldTypes.WorldState) : Iter.Iter<Owned<TradeTypes.TradeOffer>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.tradeOffers.values().map(func(o) = (owner, o))
    );
  };

  /// Flatten every player's standing trade agreements into owned rows.
  public func tradeAgreements(state : WorldTypes.WorldState) : Iter.Iter<Owned<TradeTypes.StandingAgreement>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.tradeAgreements.values().map(func(a) = (owner, a))
    );
  };

  /// Flatten every player's completed-trade history into owned rows.
  public func tradeHistory(state : WorldTypes.WorldState) : Iter.Iter<Owned<TradeTypes.TradeHistoryEntry>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.tradeHistory.values().map(func(h) = (owner, h))
    );
  };

  /// Flatten every player's charted star systems into owned rows.
  public func spaceSystems(state : WorldTypes.WorldState) : Iter.Iter<Owned<SpaceTypes.StarSystem>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.spaceSystems.values().map(func(s) = (owner, s))
    );
  };

  /// Flatten every player's fleets into owned rows.
  public func fleets(state : WorldTypes.WorldState) : Iter.Iter<Owned<SpaceTypes.Fleet>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.fleets.values().map(func(f) = (owner, f))
    );
  };

  /// Flatten every player's council proposals into owned rows.
  public func proposals(state : WorldTypes.WorldState) : Iter.Iter<Owned<CouncilTypes.Proposal>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.proposals.values().map(func(p) = (owner, p))
    );
  };

  /// Flatten every player's passed resolutions into owned rows.
  public func resolutions(state : WorldTypes.WorldState) : Iter.Iter<Owned<CouncilTypes.Resolution>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.resolutions.values().map(func(r) = (owner, r))
    );
  };

  /// Flatten every player's nation-discussion messages into owned rows.
  public func discussions(state : WorldTypes.WorldState) : Iter.Iter<Owned<SimulationTypes.DiscussionMessage>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.discussions.values().map(func(m) = (owner, m))
    );
  };

  /// Flatten every player's AI activity log into owned rows.
  public func aiLog(state : WorldTypes.WorldState) : Iter.Iter<Owned<SimulationTypes.AiActivity>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.aiLog.values().map(func(a) = (owner, a))
    );
  };

  /// Flatten every player's recorded economic history into owned rows.
  public func economyHistory(state : WorldTypes.WorldState) : Iter.Iter<Owned<EconomyTypes.EconomyTick>> {
    state.players.entries().flatMap(
      func((owner, player)) = player.economy.history.values().map(func(t) = (owner, t))
    );
  };

  /// A sample owner principal used only to seed OQL schema discovery. The value
  /// is never stored or returned; it exists so an empty collection still
  /// materialises a schema.
  public func sampleOwner() : Principal {
    Principal.fromText("aaaaa-aa");
  };

  /// A sample resource pool for schema seeding.
  public func samplePool() : Common.ResourcePool {
    { food = 0; production = 0; gold = 0; science = 0; culture = 0; influence = 0 };
  };
};
