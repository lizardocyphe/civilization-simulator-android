import Common "../types/common";
import WorldTypes "../types/world";
import TradeTypes "../types/trade";
import MilitaryTypes "../types/military";
import EconomyTypes "../types/economy";
import GameTypes "../types/game";
import Time "mo:core/Time";

module {
  // ---------------------------------------------------------------------------
  // Resource bundle helpers
  // ---------------------------------------------------------------------------

  /// An all-zero resource bundle.
  public func emptyBundle() : TradeTypes.ResourceBundle {
    { food = 0; production = 0; gold = 0; science = 0; culture = 0; influence = 0 };
  };

  /// Total units in a bundle, used for value comparison.
  func bundleTotal(b : TradeTypes.ResourceBundle) : Nat {
    b.food + b.production + b.gold + b.science + b.culture + b.influence;
  };

  /// Convert a resource pool into a trade bundle.
  func bundleOf(pool : Common.ResourcePool) : TradeTypes.ResourceBundle {
    {
      food = pool.food;
      production = pool.production;
      gold = pool.gold;
      science = pool.science;
      culture = pool.culture;
      influence = pool.influence;
    };
  };

  /// Convert a trade bundle into a resource pool.
  func poolOf(bundle : TradeTypes.ResourceBundle) : Common.ResourcePool {
    {
      food = bundle.food;
      production = bundle.production;
      gold = bundle.gold;
      science = bundle.science;
      culture = bundle.culture;
      influence = bundle.influence;
    };
  };

  /// Add two bundles.
  func addBundle(a : TradeTypes.ResourceBundle, b : TradeTypes.ResourceBundle) : TradeTypes.ResourceBundle {
    {
      food = a.food + b.food;
      production = a.production + b.production;
      gold = a.gold + b.gold;
      science = a.science + b.science;
      culture = a.culture + b.culture;
      influence = a.influence + b.influence;
    };
  };

  /// Saturating Nat subtraction.
  func satSub(a : Nat, b : Nat) : Nat {
    if (b >= a) { 0 } else { a - b };
  };

  /// Subtract bundle `b` from bundle `a`, clamping each field at zero.
  func subBundle(a : TradeTypes.ResourceBundle, b : TradeTypes.ResourceBundle) : TradeTypes.ResourceBundle {
    {
      food = satSub(a.food, b.food);
      production = satSub(a.production, b.production);
      gold = satSub(a.gold, b.gold);
      science = satSub(a.science, b.science);
      culture = satSub(a.culture, b.culture);
      influence = satSub(a.influence, b.influence);
    };
  };

  /// True when every field of `b` is covered by `a`.
  func bundleCovers(a : TradeTypes.ResourceBundle, b : TradeTypes.ResourceBundle) : Bool {
    a.food >= b.food and a.production >= b.production and a.gold >= b.gold
      and a.science >= b.science and a.culture >= b.culture and a.influence >= b.influence;
  };

  // ---------------------------------------------------------------------------
  // Rival evaluation
  // ---------------------------------------------------------------------------

  /// A rival's deterministic valuation of a proposed exchange.
  public type Evaluation = {
    accepted : Bool;
    countered : Bool;
    counterOffered : TradeTypes.ResourceBundle;
    counterRequested : TradeTypes.ResourceBundle;
    counterGold : Nat;
    note : Text;
  };

  /// Deterministically evaluate a trade offer from the rival's perspective.
  /// The rival weighs the value it receives against the value it gives up,
  /// adjusted by diplomatic stance and by its own inflation and shortages.
  public func evaluate(
    rival : MilitaryTypes.Rival,
    economy : EconomyTypes.EconomyState,
    offered : TradeTypes.ResourceBundle,
    requested : TradeTypes.ResourceBundle,
    gold : Nat,
  ) : Evaluation {
    // Value the rival receives (player's offered bundle plus gold) versus the
    // value it gives up (the requested bundle).
    let receives = bundleTotal(offered) + gold;
    let gives = bundleTotal(requested);

    // Inflation makes the rival value gold less, so it demands more of it.
    let inflationPenalty = if (economy.inflationRate > 0.05) { 2 } else { 0 };
    // A shortage (low money supply relative to spending) makes the rival
    // reluctant to part with resources and more eager for gold.
    let shortageBonus = if (economy.moneySupply < economy.spending) { 1 } else { 0 };

    let adjustedReceives = receives + inflationPenalty;
    let adjustedGives = gives + shortageBonus;

    // Stance shifts the acceptance threshold.
    let (threshold, stanceNote) = switch (rival.stance) {
      case (#alliance) { (0, "As an ally, we accept a fair exchange.") };
      case (#peace) { (1, "We are at peace and open to a balanced deal.") };
      case (#neutral) { (2, "We are neutral; the terms must favour us.") };
      case (#war) { (1000, "We will not trade with an enemy.") };
    };

    if (rival.stance == #war) {
      return {
        accepted = false;
        countered = false;
        counterOffered = emptyBundle();
        counterRequested = emptyBundle();
        counterGold = 0;
        note = stanceNote;
      };
    };

    if (adjustedReceives >= adjustedGives + threshold) {
      return {
        accepted = true;
        countered = false;
        counterOffered = emptyBundle();
        counterRequested = emptyBundle();
        counterGold = 0;
        note = stanceNote;
      };
    };

    // Counter-offer: the rival asks for a bundle that makes the deal worth its
    // while, scaling the requested bundle up to close the value gap.
    let gap = (adjustedGives + threshold) - adjustedReceives;
    let scale = gap + 1;
    let counterRequested = scaleBundle(requested, scale);
    let counterGold = gold + gap;
    {
      accepted = false;
      countered = true;
      counterOffered = offered;
      counterRequested;
      counterGold;
      note = "We cannot accept those terms. Our revised offer follows.";
    };
  };

  /// Scale a bundle's quantities by `factor` (at least 1).
  func scaleBundle(b : TradeTypes.ResourceBundle, factor : Nat) : TradeTypes.ResourceBundle {
    let f = if (factor < 1) { 1 } else { factor };
    {
      food = b.food * f;
      production = b.production * f;
      gold = b.gold * f;
      science = b.science * f;
      culture = b.culture * f;
      influence = b.influence * f;
    };
  };

  // ---------------------------------------------------------------------------
  // Offers
  // ---------------------------------------------------------------------------

  /// Open a trade offer with a known rival. The offer is recorded as pending
  /// and immediately evaluated by the rival.
  public func openOffer(
    state : WorldTypes.PlayerState,
    partnerId : Common.RivalId,
    offered : TradeTypes.ResourceBundle,
    requested : TradeTypes.ResourceBundle,
    gold : Nat,
  ) : Common.ActionResult {
    switch (state.rivals.find(func(r) = r.id == partnerId)) {
      case null { #err("Rival not discovered") };
      case (?rival) {
        if (rival.stance == #war) {
          return #err("Cannot trade with a rival at war");
        };
        let id = state.nextTradeId;
        let tick = state.clock.tick;
        let offer : TradeTypes.TradeOffer = {
          id;
          partner = partnerId;
          offered;
          requested;
          gold;
          status = #pending;
          createdTick = tick;
        };
        state.tradeOffers := state.tradeOffers.concat([offer]);
        state.nextTradeId := id + 1;

        // The rival evaluates immediately and the offer resolves.
        let evaluation = evaluate(rival, state.economy, offered, requested, gold);
        if (evaluation.accepted) {
          state.tradeOffers := state.tradeOffers.map(
            func(o) { if (o.id == id) { { o with status = #accepted } } else { o } }
          );
          settle(state, partnerId, offered, requested, gold, "Trade accepted");
          #ok;
        } else if (evaluation.countered) {
          state.tradeOffers := state.tradeOffers.map(
            func(o) { if (o.id == id) { { o with status = #countered } } else { o } }
          );
          #ok;
        } else {
          state.tradeOffers := state.tradeOffers.map(
            func(o) { if (o.id == id) { { o with status = #rejected } } else { o } }
          );
          #ok;
        };
      };
    };
  };

  /// Cancel a pending trade offer.
  public func cancelOffer(state : WorldTypes.PlayerState, offerId : Nat) : Common.ActionResult {
    switch (state.tradeOffers.find(func(o) = o.id == offerId)) {
      case null { #err("Offer not found") };
      case (?offer) {
        if (offer.status != #pending and offer.status != #countered) {
          return #err("Only pending or countered offers can be cancelled");
        };
        state.tradeOffers := state.tradeOffers.map(
          func(o) { if (o.id == offerId) { { o with status = #cancelled } } else { o } }
        );
        #ok;
      };
    };
  };

  /// Accept a countered offer, transferring the rival's revised terms.
  public func acceptCounter(state : WorldTypes.PlayerState, offerId : Nat) : Common.ActionResult {
    switch (state.tradeOffers.find(func(o) = o.id == offerId)) {
      case null { #err("Offer not found") };
      case (?offer) {
        if (offer.status != #countered) {
          return #err("Offer is not awaiting a counter decision");
        };
        switch (state.rivals.find(func(r) = r.id == offer.partner)) {
          case null { #err("Rival not discovered") };
          case (?rival) {
            let evaluation = evaluate(rival, state.economy, offer.offered, offer.requested, offer.gold);
            // The player accepts the rival's revised bundle.
            let revisedOffered = evaluation.counterOffered;
            let revisedRequested = evaluation.counterRequested;
            let revisedGold = evaluation.counterGold;
            state.tradeOffers := state.tradeOffers.map(
              func(o) { if (o.id == offerId) { { o with status = #accepted } } else { o } }
            );
            settle(state, offer.partner, revisedOffered, revisedRequested, revisedGold, "Counter-offer accepted");
            #ok;
          };
        };
      };
    };
  };

  /// List the player's trade offers.
  public func listOffers(state : WorldTypes.PlayerState) : [TradeTypes.TradeOffer] {
    state.tradeOffers;
  };

  /// List the player's trade history.
  public func listHistory(state : WorldTypes.PlayerState) : [TradeTypes.TradeHistoryEntry] {
    state.tradeHistory;
  };

  // ---------------------------------------------------------------------------
  // Settlement of a completed trade
  // ---------------------------------------------------------------------------

  /// Transfer resources and gold between the player and a rival, and record a
  /// history entry. The player gives `requested` and `gold`, and receives
  /// `offered`.
  func settle(
    state : WorldTypes.PlayerState,
    partnerId : Common.RivalId,
    offered : TradeTypes.ResourceBundle,
    requested : TradeTypes.ResourceBundle,
    gold : Nat,
    summary : Text,
  ) {
    switch (state.game) {
      case null {};
      case (?game) {
        let civ = game.civilization;
        let res = civ.resources;
        // Player pays the requested bundle plus gold, receives the offered bundle.
        let afterPay : Common.ResourcePool = {
          food = satSub(res.food, requested.food);
          production = satSub(res.production, requested.production);
          gold = satSub(res.gold, requested.gold + gold);
          science = satSub(res.science, requested.science);
          culture = satSub(res.culture, requested.culture);
          influence = satSub(res.influence, requested.influence);
        };
        let afterReceive : Common.ResourcePool = {
          food = afterPay.food + offered.food;
          production = afterPay.production + offered.production;
          gold = afterPay.gold + offered.gold;
          science = afterPay.science + offered.science;
          culture = afterPay.culture + offered.culture;
          influence = afterPay.influence + offered.influence;
        };
        let updatedCiv : GameTypes.Civilization = {
          civ with resources = afterReceive;
        };
        state.game := ?{ game with civilization = updatedCiv; updatedAt = Time.now() };
        let entry : TradeTypes.TradeHistoryEntry = {
          tick = state.clock.tick;
          partner = partnerId;
          offered;
          requested;
          gold;
          summary;
        };
        state.tradeHistory := state.tradeHistory.concat([entry]);
      };
    };
  };

  // ---------------------------------------------------------------------------
  // Standing agreements
  // ---------------------------------------------------------------------------

  /// Create a standing agreement that exchanges a bundle every simulation tick.
  public func createAgreement(
    state : WorldTypes.PlayerState,
    partnerId : Common.RivalId,
    perTick : TradeTypes.ResourceBundle,
    goldPerTick : Nat,
  ) : Common.ActionResult {
    switch (state.rivals.find(func(r) = r.id == partnerId)) {
      case null { #err("Rival not discovered") };
      case (?rival) {
        if (rival.stance == #war) {
          return #err("Cannot trade with a rival at war");
        };
        let id = state.nextTradeId;
        let agreement : TradeTypes.StandingAgreement = {
          id;
          partner = partnerId;
          perTick;
          goldPerTick;
          active = true;
          startedTick = state.clock.tick;
        };
        state.tradeAgreements := state.tradeAgreements.concat([agreement]);
        state.nextTradeId := id + 1;
        #ok;
      };
    };
  };

  /// Cancel a standing agreement.
  public func cancelAgreement(state : WorldTypes.PlayerState, agreementId : Nat) : Common.ActionResult {
    switch (state.tradeAgreements.find(func(a) = a.id == agreementId)) {
      case null { #err("Agreement not found") };
      case (?agreement) {
        if (not agreement.active) {
          return #err("Agreement is already inactive");
        };
        state.tradeAgreements := state.tradeAgreements.map(
          func(a) { if (a.id == agreementId) { { a with active = false } } else { a } }
        );
        #ok;
      };
    };
  };

  /// List the player's standing agreements.
  public func listAgreements(state : WorldTypes.PlayerState) : [TradeTypes.StandingAgreement] {
    state.tradeAgreements;
  };

  /// Apply every active standing agreement for one tick: the player pays the
  /// per-tick bundle and gold, and receives the same bundle back from the
  /// partner. Called from the simulation tick.
  public func applyAgreements(state : WorldTypes.PlayerState) {
    for (agreement in state.tradeAgreements.values()) {
      if (agreement.active) {
        settle(
          state,
          agreement.partner,
          agreement.perTick,
          agreement.perTick,
          agreement.goldPerTick,
          "Standing agreement tick",
        );
      };
    };
  };
};
