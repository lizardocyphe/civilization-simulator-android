import Common "../types/common";
import TechTypes "../types/tech";
import WorldTypes "../types/world";
import Progress "../progress";

module {
  /// Begin researching a technology.
  public func researchTechnology(state : WorldTypes.PlayerState, techId : Common.TechId) : Common.ActionResult {
    Progress.researchTechnology(state, techId);
  };

  /// Advance to the next era if the milestone is met.
  public func advanceEra(state : WorldTypes.PlayerState) : Common.ActionResult {
    Progress.advanceEra(state);
  };

  /// List all technologies and their unlock state.
  public func listTechnologies(state : WorldTypes.PlayerState) : [TechTypes.Technology] {
    Progress.listTechnologies(state);
  };

  /// List the era milestone requirements.
  public func listMilestones() : [TechTypes.EraMilestone] {
    Progress.listMilestones();
  };
};
