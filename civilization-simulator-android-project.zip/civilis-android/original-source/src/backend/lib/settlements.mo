import Common "../types/common";
import SettlementTypes "../types/settlements";
import WorldTypes "../types/world";
import WorldLib "world";

module {
  /// Found a new settlement at a coordinate.
  public func foundSettlement(state : WorldTypes.PlayerState, name : Text, position : Common.HexCoord) : Common.ActionResult {
    WorldLib.foundSettlement(state, name, position);
  };

  /// Assign a population unit to work a tile.
  public func assignPopulation(state : WorldTypes.PlayerState, settlementId : Common.SettlementId, tileId : Common.TileId) : Common.ActionResult {
    WorldLib.assignPopulation(state, settlementId, tileId);
  };

  /// Construct a building in a settlement.
  public func constructBuilding(state : WorldTypes.PlayerState, settlementId : Common.SettlementId, kind : Text) : Common.ActionResult {
    WorldLib.constructBuilding(state, settlementId, kind);
  };

  /// List the caller's settlements.
  public func listSettlements(state : WorldTypes.PlayerState) : [SettlementTypes.Settlement] {
    WorldLib.listSettlements(state);
  };
};
