import Common "../types/common";
import MapTypes "../types/map";
import WorldTypes "../types/world";
import WorldLib "world";

module {
  /// Return the current hex map.
  public func getMap(state : WorldTypes.PlayerState) : MapTypes.HexMap {
    WorldLib.getMap(state);
  };

  /// Reveal tiles around a coordinate.
  public func revealAround(state : WorldTypes.PlayerState, coord : Common.HexCoord, radius : Nat) : () {
    WorldLib.revealAround(state, coord, radius);
  };
};
