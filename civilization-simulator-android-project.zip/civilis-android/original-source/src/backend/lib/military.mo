import Common "../types/common";
import MilitaryTypes "../types/military";
import WorldTypes "../types/world";
import Progress "../progress";

module {
  /// Recruit a new unit at a coordinate.
  public func recruitUnit(state : WorldTypes.PlayerState, kind : Text, position : Common.HexCoord) : Common.ActionResult {
    Progress.recruitUnit(state, kind, position);
  };

  /// Resolve combat between two units.
  public func resolveCombat(state : WorldTypes.PlayerState, attackerId : Common.UnitId, defenderId : Common.UnitId) : MilitaryTypes.CombatResult {
    Progress.resolveCombat(state, attackerId, defenderId);
  };

  /// Set the diplomatic stance toward a rival.
  public func setDiplomacy(state : WorldTypes.PlayerState, rivalId : Common.RivalId, stance : MilitaryTypes.DiplomaticStance) : Common.ActionResult {
    Progress.setDiplomacy(state, rivalId, stance);
  };

  /// List the caller's units.
  public func listUnits(state : WorldTypes.PlayerState) : [MilitaryTypes.Unit] {
    Progress.listUnits(state);
  };

  /// List the known rivals.
  public func listRivals(state : WorldTypes.PlayerState) : [MilitaryTypes.Rival] {
    Progress.listRivals(state);
  };
};
