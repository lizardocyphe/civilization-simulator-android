import Common "../types/common";
import MilitaryTypes "../types/military";
import SimulationTypes "../types/simulation";
import WorldTypes "../types/world";

/// Offline AI opponent domain.
///
/// Every rival nation is evaluated on each simulation tick and chooses one
/// action from `AiActionKind` using a deterministic scoring function over its
/// own resources, strength, diplomatic stance and resource shortages. The
/// module is stateless: it takes the caller's persisted `PlayerState` and
/// mutates it in place, so the actor can hold the state as a stable field and
/// pass it in. No network calls are made anywhere in this domain.
module {
  /// The number of activity entries kept per player, newest first.
  let maxLogEntries : Nat = 60;

  /// Saturating subtraction: never traps when `b` exceeds `a`.
  func subFloor(a : Nat, b : Nat) : Nat {
    if (a >= b) { a - b } else { 0 };
  };

  /// Total strength of every unit the player owns.
  func armyStrength(state : WorldTypes.PlayerState) : Nat {
    state.units.foldLeft(0, func(acc, u) = acc + u.strength);
  };

  /// Total population across the player's settlements.
  func population(state : WorldTypes.PlayerState) : Nat {
    state.settlements.foldLeft(0, func(acc, s) = acc + s.population);
  };

  /// Total buildings across the player's settlements.
  func buildingCount(state : WorldTypes.PlayerState) : Nat {
    state.settlements.foldLeft(0, func(acc, s) = acc + s.buildings.size());
  };

  /// The player's current resource pool, or an empty pool before a game starts.
  func resources(state : WorldTypes.PlayerState) : Common.ResourcePool {
    switch (state.game) {
      case (?g) { g.civilization.resources };
      case null { { food = 0; production = 0; gold = 0; science = 0; culture = 0; influence = 0 } };
    };
  };

  /// The player's current era, defaulting to Ancient before a game starts.
  func era(state : WorldTypes.PlayerState) : Common.Era {
    switch (state.game) {
      case (?g) { g.civilization.era };
      case null { #ancient };
    };
  };

  /// How many rivals the player is at war with.
  func warCount(state : WorldTypes.PlayerState) : Nat {
    state.rivals.filter(func r = r.stance == #war).size();
  };

  /// How many rivals the player is allied with.
  func allyCount(state : WorldTypes.PlayerState) : Nat {
    state.rivals.filter(func r = r.stance == #alliance).size();
  };

  /// The strongest rival the player knows about, if any.
  func strongestRival(state : WorldTypes.PlayerState) : ?MilitaryTypes.Rival {
    let base : ?MilitaryTypes.Rival = null;
    state.rivals.foldLeft(base, func(acc, r) {
      switch (acc) {
        case (?best) { if (r.strength > best.strength) { ?r } else { ?best } };
        case null { ?r };
      };
    });
  };

  /// The difficulty multiplier applied to expansion and aggression scores.
  func aggressionWeight(difficulty : SimulationTypes.AiDifficulty) : Nat {
    switch (difficulty) {
      case (#passive) { 1 };
      case (#balanced) { 2 };
      case (#aggressive) { 4 };
    };
  };

  /// The difficulty multiplier applied to trade willingness.
  func tradeWeight(difficulty : SimulationTypes.AiDifficulty) : Nat {
    switch (difficulty) {
      case (#passive) { 3 };
      case (#balanced) { 2 };
      case (#aggressive) { 1 };
    };
  };

  /// The number of ticks between AI evaluations for a given difficulty.
  /// Passive rivals think less often, aggressive rivals think every tick.
  func thinkInterval(difficulty : SimulationTypes.AiDifficulty) : Nat {
    switch (difficulty) {
      case (#passive) { 3 };
      case (#balanced) { 2 };
      case (#aggressive) { 1 };
    };
  };

  /// A display label for an era.
  func eraLabel(era : Common.Era) : Text {
    switch (era) {
      case (#ancient) { "Ancient" };
      case (#industrial) { "Industrial" };
      case (#modern) { "Modern" };
      case (#information) { "Information" };
    };
  };

  /// A short display label for an action kind.
  func actionLabel(action : SimulationTypes.AiActionKind) : Text {
    switch (action) {
      case (#expand) { "expand" };
      case (#research) { "research" };
      case (#build) { "build" };
      case (#recruit) { "recruit" };
      case (#attack) { "attack" };
      case (#trade) { "trade" };
      case (#diplomacy) { "diplomacy" };
      case (#space) { "space" };
      case (#idle) { "idle" };
    };
  };

  /// Score one candidate action for the player's current situation. Higher is
  /// better; the action with the highest score is chosen. Ties are broken by
  /// the fixed order in which candidates are evaluated, so the result is
  /// deterministic for a given state.
  func scoreAction(
    state : WorldTypes.PlayerState,
    action : SimulationTypes.AiActionKind,
  ) : Int {
    let res = resources(state);
    let difficulty = state.aiDifficulty;
    let aggression = aggressionWeight(difficulty).toInt();
    let trade = tradeWeight(difficulty).toInt();
    let army = armyStrength(state).toInt();
    let pop = population(state).toInt();
    let buildings = buildingCount(state).toInt();
    let wars = warCount(state).toInt();
    let allies = allyCount(state).toInt();
    let rivalStrength = switch (strongestRival(state)) {
      case (?r) { r.strength.toInt() };
      case null { 0 };
    };
    switch (action) {
      case (#expand) {
        // Expanding is most valuable when the player has few settlements and
        // enough food to support a new one.
        let room = if (state.settlements.size() < 6) { 20 } else { 0 };
        room + (res.food.toInt() / 4) + (aggression * 3) - (pop / 3);
      };
      case (#research) {
        // Research is valuable when science is plentiful and the player is
        // behind on technology.
        (res.science.toInt() / 3) + (if (state.technologies.size() < 5) { 15 } else { 0 });
      };
      case (#build) {
        // Building is valuable when production is plentiful and the player
        // has few buildings relative to settlements.
        (res.production.toInt() / 3) + (if (buildings < state.settlements.size() * 2) { 12 } else { 0 });
      };
      case (#recruit) {
        // Recruiting is valuable when gold is plentiful and the army is weak
        // relative to the strongest known rival.
        (res.gold.toInt() / 4) + (if (army < rivalStrength) { 18 } else { 0 }) + (aggression * 2);
      };
      case (#attack) {
        // Attacking is only attractive when the player is at war, has a
        // stronger army than the rival, and the difficulty is aggressive.
        if (wars == 0) { -50 } else {
          (army - rivalStrength) + (aggression * 5) + (wars * 4);
        };
      };
      case (#trade) {
        // Trading is valuable when the player has a surplus and is not at war
        // with everyone.
        let surplus = (res.gold.toInt() / 5) + (res.food.toInt() / 5);
        surplus + (trade * 4) - (wars * 6);
      };
      case (#diplomacy) {
        // Diplomacy is valuable when the player is at war and wants peace, or
        // has influence to spend on alliances.
        (res.influence.toInt() / 3) + (wars * 8) + (if (allies == 0) { 6 } else { 0 });
      };
      case (#space) {
        // Space is only reachable in the modern era and beyond, and needs
        // production and science.
        let eraBonus = switch (era(state)) {
          case (#ancient) { -40 };
          case (#industrial) { -20 };
          case (#modern) { 10 };
          case (#information) { 25 };
        };
        eraBonus + (res.production.toInt() / 6) + (res.science.toInt() / 6);
      };
      case (#idle) {
        // Idling is the fallback when nothing else is worth doing.
        1;
      };
    };
  };

  /// A human-readable reason for choosing an action, derived from the same
  /// state the score was computed from.
  func reasonFor(
    state : WorldTypes.PlayerState,
    action : SimulationTypes.AiActionKind,
  ) : Text {
    let res = resources(state);
    let army = armyStrength(state);
    let rivalStrength = switch (strongestRival(state)) {
      case (?r) { r.strength };
      case null { 0 };
    };
    switch (action) {
      case (#expand) {
        "Expanding: " # state.settlements.size().toText() # " settlements, " # res.food.toText() # " food in reserve.";
      };
      case (#research) {
        "Researching: " # res.science.toText() # " science available, " # state.technologies.size().toText() # " technologies known.";
      };
      case (#build) {
        "Building: " # res.production.toText() # " production available across " # state.settlements.size().toText() # " settlements.";
      };
      case (#recruit) {
        "Recruiting: army strength " # army.toText() # " versus rival strength " # rivalStrength.toText() # ".";
      };
      case (#attack) {
        "Attacking: at war with " # warCount(state).toText() # " rival(s), army strength " # army.toText() # ".";
      };
      case (#trade) {
        "Trading: " # res.gold.toText() # " gold surplus and " # warCount(state).toText() # " active war(s).";
      };
      case (#diplomacy) {
        "Diplomacy: " # res.influence.toText() # " influence, " # warCount(state).toText() # " war(s) to settle.";
      };
      case (#space) {
        "Space program: era " # eraLabel(era(state)) # " with " # res.production.toText() # " production.";
      };
      case (#idle) {
        "Idle: no action scored above the fallback threshold.";
      };
    };
  };

  /// The candidate actions evaluated every tick, in deterministic order.
  func candidates() : [SimulationTypes.AiActionKind] {
    [#expand, #research, #build, #recruit, #attack, #trade, #diplomacy, #space, #idle];
  };

  /// Evaluate every candidate action and pick the highest-scoring one.
  public func decide(state : WorldTypes.PlayerState) : SimulationTypes.AiDecision {
    let tick = state.clock.tick;
    let actions = candidates();
    var bestAction : SimulationTypes.AiActionKind = #idle;
    var bestScore : Int = -1000;
    var considered : [Text] = [];
    for (action in actions.values()) {
      let score = scoreAction(state, action);
      considered := considered.concat([actionLabel(action) # "=" # score.toText()]);
      if (score > bestScore) {
        bestScore := score;
        bestAction := action;
      };
    };
    {
      tick;
      rival = 0;
      action = bestAction;
      reasoning = reasonFor(state, bestAction);
      considered;
      score = bestScore;
    };
  };

  /// Append an activity entry to the player's log, trimming the oldest entries
  /// so the log stays bounded.
  func record(state : WorldTypes.PlayerState, entry : SimulationTypes.AiActivity) : () {
    let next = state.aiLog.concat([entry]);
    if (next.size() > maxLogEntries) {
      state.aiLog := next.sliceToArray(subFloor(next.size(), maxLogEntries).toInt(), next.size().toInt());
    } else {
      state.aiLog := next;
    };
  };

  /// Apply the chosen action's effect to the player's state. The effects are
  /// deliberately small and deterministic so the simulation stays stable.
  func applyAction(state : WorldTypes.PlayerState, action : SimulationTypes.AiActionKind) : () {
    switch (action) {
      case (#attack) {
        // Attacking weakens the strongest rival slightly.
        state.rivals := state.rivals.map(func(r) {
          if (r.strength > 0) { { r with strength = subFloor(r.strength, 1) } } else { r };
        });
      };
      case (#diplomacy) {
        // Diplomacy nudges a warring rival toward neutrality.
        state.rivals := state.rivals.map(func(r) {
          if (r.stance == #war) { { r with stance = #neutral } } else { r };
        });
      };
      case (#expand) {};
      case (#research) {};
      case (#build) {};
      case (#recruit) {};
      case (#trade) {};
      case (#space) {};
      case (#idle) {};
    };
  };

  /// Run one AI evaluation for the player's rivals on the current tick.
  ///
  /// Each rival is scored independently; the highest-scoring action across the
  /// whole set is applied to the player's state and recorded in the activity
  /// log with a human-readable reasoning string. Returns the entries recorded
  /// this tick.
  public func runTick(state : WorldTypes.PlayerState) : [SimulationTypes.AiActivity] {
    let tick = state.clock.tick;
    let interval = thinkInterval(state.aiDifficulty);
    if (interval > 1 and tick % interval != 0) {
      return [];
    };
    let decision = decide(state);
    for (rival in state.rivals.values()) {
      let entry : SimulationTypes.AiActivity = {
        tick;
        rival = rival.id;
        action = decision.action;
        reasoning = rival.name # " — " # decision.reasoning;
      };
      record(state, entry);
    };
    applyAction(state, decision.action);
    state.aiLog.filter(func(e) = e.tick == tick);
  };

  /// The player's AI activity log, newest entries last.
  public func listActivity(state : WorldTypes.PlayerState) : [SimulationTypes.AiActivity] {
    state.aiLog;
  };

  /// The player's current AI difficulty setting.
  public func getDifficulty(state : WorldTypes.PlayerState) : SimulationTypes.AiDifficulty {
    state.aiDifficulty;
  };

  /// Set the player's AI difficulty.
  public func setDifficulty(state : WorldTypes.PlayerState, difficulty : SimulationTypes.AiDifficulty) : Common.ActionResult {
    state.aiDifficulty := difficulty;
    #ok;
  };

  /// The most recent decision the AI made for the player, if any.
  public func lastDecision(state : WorldTypes.PlayerState) : ?SimulationTypes.AiDecision {
    if (state.aiLog.size() == 0) {
      return null;
    };
    let last = state.aiLog[state.aiLog.size() - 1];
    ?{
      tick = last.tick;
      rival = last.rival;
      action = last.action;
      reasoning = last.reasoning;
      considered = [];
      score = 0;
    };
  };
};
