import Common "../types/common";
import WorldTypes "../types/world";
import EconomyTypes "../types/economy";
import WorldLib "world";

module {
  /// The fixed catalogue of fiscal and monetary policies a player can adopt.
  /// Each policy trades growth against inflation and stability.
  public func policies() : [EconomyTypes.EconomicPolicy] {
    [
      {
        id = 1;
        name = "Austerity";
        description = "Cut spending and raise interest to cool inflation at the cost of growth.";
        taxRateDelta = 0.02;
        interestRateDelta = 0.02;
        spendingDelta = -5;
      },
      {
        id = 2;
        name = "Stimulus";
        description = "Spend heavily to boost income, accepting higher inflation.";
        taxRateDelta = -0.01;
        interestRateDelta = -0.01;
        spendingDelta = 10;
      },
      {
        id = 3;
        name = "Tax Cut";
        description = "Lower taxes to spur trade and production, widening the deficit.";
        taxRateDelta = -0.03;
        interestRateDelta = 0.0;
        spendingDelta = 0;
      },
      {
        id = 4;
        name = "Public Investment";
        description = "Raise taxes to fund infrastructure, steadying prices.";
        taxRateDelta = 0.03;
        interestRateDelta = 0.0;
        spendingDelta = 5;
      },
      {
        id = 5;
        name = "Tight Money";
        description = "Raise interest rates sharply to defend the currency.";
        taxRateDelta = 0.0;
        interestRateDelta = 0.04;
        spendingDelta = -2;
      },
    ];
  };

  /// Look up a policy by id.
  public func policyById(id : Nat) : ?EconomyTypes.EconomicPolicy {
    policies().find(func(p) = p.id == id);
  };

  /// Apply a policy's deltas to the player's economy, clamping rates to sane
  /// bounds. Returns the updated economy state.
  public func applyPolicy(
    state : WorldTypes.PlayerState,
    policyId : Nat,
  ) : Common.ActionResult {
    switch (policyById(policyId)) {
      case null { #err("Unknown policy") };
      case (?policy) {
        let e = state.economy;
        let nextTax = clampRate(e.taxRate + policy.taxRateDelta);
        let nextInterest = clampRate(e.interestRate + policy.interestRateDelta);
        let nextSpending = applySpending(e.spending, policy.spendingDelta);
        state.economy := {
          e with
          taxRate = nextTax;
          interestRate = nextInterest;
          spending = nextSpending;
        };
        #ok;
      };
    };
  };

  /// Clamp a rate into the [0.0, 0.5] band.
  func clampRate(rate : Float) : Float {
    if (rate < 0.0) { 0.0 } else if (rate > 0.5) { 0.5 } else { rate };
  };

  /// Apply a signed spending delta to a Nat spending value, clamping at zero.
  func applySpending(spending : Nat, delta : Int) : Nat {
    if (delta >= 0) {
      spending + delta.toNat();
    } else {
      let magnitude = (-delta).toNat();
      if (magnitude >= spending) { 0 } else { spending - magnitude };
    };
  };

  /// The current price level, used to scale every cost the player sees.
  public func priceLevel(state : WorldTypes.PlayerState) : Float {
    state.economy.priceLevel;
  };

  /// Scale a base cost by the current price level. Inflation raises costs and
  /// deflation lowers them. Other domains call this so every displayed cost
  /// reflects the current price level.
  public func scaleCost(state : WorldTypes.PlayerState, baseCost : Nat) : Nat {
    let scaled = baseCost.toFloat() * state.economy.priceLevel;
    if (scaled <= 0.0) { 0 } else { scaled.toInt().toNat() };
  };

  /// Advance the economy one tick: recompute income and upkeep from the
  /// civilization, update the money supply, derive the inflation rate from
  /// income, upkeep and trade volume, move the price level, and record a short
  /// trend history entry.
  public func tick(state : WorldTypes.PlayerState) : EconomyTypes.EconomyState {
    let e = state.economy;
    let produced = WorldLib.produce(state);
    let upkeepPool = WorldLib.upkeepFor(state);

    // Income is gold produced plus tax revenue on the money supply.
    let taxRevenue = (e.moneySupply.toFloat() * e.taxRate).toInt().toNat();
    let income = produced.gold + taxRevenue;
    let upkeep = upkeepPool.gold + e.spending;

    // Trade volume is the number of standing agreements, a proxy for how much
    // gold is circulating through trade.
    let tradeVolume = state.tradeAgreements.size();

    // Money supply grows by net fiscal flow and by trade-driven issuance.
    let net = if (income >= upkeep) { income - upkeep } else { 0 };
    let moneySupply = e.moneySupply + net + tradeVolume;

    // Inflation responds to money growth relative to real output. More money
    // chasing the same output raises prices; a surplus (upkeep > income) cools
    // them. Interest rate damps inflation.
    let output = produced.gold + produced.production + 1;
    let moneyGrowth = moneySupply.toFloat() - e.moneySupply.toFloat();
    let rawInflation = (moneyGrowth / output.toFloat()) - (e.interestRate * 0.5);
    let inflationRate = clampInflation(rawInflation);

    // Price level compounds the inflation rate, bounded to a sane band.
    let priceLevel = clampPrice(e.priceLevel * (1.0 + inflationRate));

    let tickIndex = e.history.size();
    let entry : EconomyTypes.EconomyTick = {
      tick = tickIndex;
      moneySupply;
      priceLevel;
      inflationRate;
      income;
      upkeep;
    };

    // Keep only the most recent 12 ticks for the trend display.
    let history = (e.history.concat([entry])).reverse().sliceToArray(0, 12).reverse();

    let next : EconomyTypes.EconomyState = {
      e with
      moneySupply;
      priceLevel;
      inflationRate;
      income;
      upkeep;
      history;
    };
    state.economy := next;
    next;
  };

  /// Clamp inflation into the [-0.25, 0.5] band.
  func clampInflation(rate : Float) : Float {
    if (rate < -0.25) { -0.25 } else if (rate > 0.5) { 0.5 } else { rate };
  };

  /// Clamp the price level into the [0.25, 10.0] band.
  func clampPrice(price : Float) : Float {
    if (price < 0.25) { 0.25 } else if (price > 10.0) { 10.0 } else { price };
  };

  /// Return the player's current economy state.
  public func getEconomy(state : WorldTypes.PlayerState) : EconomyTypes.EconomyState {
    state.economy;
  };

  /// Return the recorded per-tick history for trend display.
  public func history(state : WorldTypes.PlayerState) : [EconomyTypes.EconomyTick] {
    state.economy.history;
  };
};
