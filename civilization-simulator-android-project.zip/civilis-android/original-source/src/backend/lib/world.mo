import Common "../types/common";
import WorldTypes "../types/world";
import GameTypes "../types/game";
import MapTypes "../types/map";
import SettlementTypes "../types/settlements";
import Time "mo:core/Time";

module {
  // ---------------------------------------------------------------------------
  // Weather
  // ---------------------------------------------------------------------------

  /// Build a fresh weather state for a location. Weather is simulated from the
  /// location's latitude so the same coordinates always yield the same climate
  /// band; the caller supplies the real-world location.
  public func weatherFor(location : ?Common.GeoLocation) : WorldTypes.WeatherState {
    let (condition, temp, wind, precip) = switch (location) {
      case (?loc) { climateFor(loc.latitude) };
      case null { ("Clear", 18.0, 8.0, 0.0) };
    };
    {
      location;
      condition;
      temperatureC = temp;
      windKph = wind;
      precipitationMm = precip;
      updatedAt = Time.now();
    };
  };

  /// Derive a climate band from latitude (degrees, -90..90).
  func climateFor(latitude : Float) : (Text, Float, Float, Float) {
    let absLat = if (latitude < 0.0) { -latitude } else { latitude };
    if (absLat >= 66.5) {
      ("Snow", -12.0, 22.0, 4.0);
    } else if (absLat >= 45.0) {
      ("Overcast", 9.0, 16.0, 2.0);
    } else if (absLat >= 23.5) {
      ("Clear", 21.0, 11.0, 0.5);
    } else {
      ("Humid", 30.0, 7.0, 6.0);
    };
  };

  /// Set the player's real-world location and refresh the weather.
  public func setLocation(state : WorldTypes.PlayerState, location : Common.GeoLocation) : Common.ActionResult {
    state.weather := weatherFor(?location);
    #ok;
  };

  /// Return the current weather state.
  public func getWeather(state : WorldTypes.PlayerState) : WorldTypes.WeatherState {
    state.weather;
  };

  // ---------------------------------------------------------------------------
  // Crises
  // ---------------------------------------------------------------------------

  /// List active (unresolved) crisis events.
  public func listCrises(state : WorldTypes.PlayerState) : [WorldTypes.CrisisEvent] {
    state.crises.filter(func(c) = not c.resolved);
  };

  /// Apply a crisis choice: apply its resource and stability deltas, mark the
  /// crisis resolved, and return the outcome.
  public func applyCrisisChoice(
    state : WorldTypes.PlayerState,
    crisisId : Common.CrisisId,
    choiceId : Nat,
  ) : Common.ActionResult {
    switch (state.crises.find(func(c) = c.id == crisisId)) {
      case null { #err("Crisis not found") };
      case (?crisis) {
        if (crisis.resolved) {
          return #err("Crisis already resolved");
        };
        switch (crisis.choices.find(func(ch) = ch.id == choiceId)) {
          case null { #err("Choice not found") };
          case (?choice) {
            applyEffect(state, choice.effect);
            state.crises := state.crises.map(
              func(c) {
                if (c.id == crisisId) { { c with resolved = true } } else { c };
              }
            );
            #ok;
          };
        };
      };
    };
  };

  /// Apply a crisis effect's resource and stability deltas to the player state.
  func applyEffect(state : WorldTypes.PlayerState, effect : WorldTypes.CrisisEffect) {
    switch (state.game) {
      case null {};
      case (?game) {
        let civ = game.civilization;
        let updated : GameTypes.Civilization = {
          civ with
          resources = addPool(civ.resources, effect.resourceDelta);
          stability = applyStability(civ.stability, effect.stabilityDelta);
        };
        state.game := ?{ game with civilization = updated; updatedAt = Time.now() };
      };
    };
  };

  /// Apply a signed stability delta to a Nat stability value, clamping at 0.
  func applyStability(stability : Nat, delta : Int) : Nat {
    if (delta >= 0) {
      stability + delta.toNat();
    } else {
      let magnitude = (-delta).toNat();
      if (magnitude >= stability) { 0 } else { stability - magnitude };
    };
  };

  // ---------------------------------------------------------------------------
  // Map, fog of war and territory
  // ---------------------------------------------------------------------------

  /// Generate a fresh hex map of the given dimensions. Terrain is derived
  /// deterministically from each tile's coordinates so the same map size always
  /// yields the same world.
  public func generateMap(width : Nat, height : Nat) : MapTypes.HexMap {
    var tiles : [MapTypes.Tile] = [];
    var id = 0;
    var r = 0;
    while (r < height) {
      var q = 0;
      while (q < width) {
        let coord : Common.HexCoord = { q = q; r = r };
        let tile : MapTypes.Tile = {
          id;
          coord;
          terrain = terrainFor(q, r);
          resource = resourceFor(q, r);
          pocket = null;
          fog = #unexplored;
          owner = null;
        };
        tiles := tiles.concat([tile]);
        id := id + 1;
        q := q + 1;
      };
      r := r + 1;
    };
    { width; height; tiles };
  };

  /// Deterministic terrain for a coordinate.
  func terrainFor(q : Nat, r : Nat) : MapTypes.Terrain {
    let band = (q * 7 + r * 13) % 10;
    if (band == 0) { #ocean }
    else if (band == 1) { #coast }
    else if (band == 2) { #grassland }
    else if (band == 3) { #plains }
    else if (band == 4) { #forest }
    else if (band == 5) { #hills }
    else if (band == 6) { #mountains }
    else if (band == 7) { #desert }
    else if (band == 8) { #tundra }
    else { #ice };
  };

  /// Deterministic resource node for a coordinate, or null when none.
  func resourceFor(q : Nat, r : Nat) : ?MapTypes.ResourceNode {
    let roll = (q * 3 + r * 5) % 7;
    if (roll == 0) {
      ?{ kind = "iron"; amount = 5; renewable = false };
    } else if (roll == 1) {
      ?{ kind = "wheat"; amount = 4; renewable = true };
    } else if (roll == 2) {
      ?{ kind = "gold"; amount = 3; renewable = false };
    } else {
      null;
    };
  };

  /// Return the current hex map.
  public func getMap(state : WorldTypes.PlayerState) : MapTypes.HexMap {
    state.map;
  };

  /// Reveal tiles within `radius` hex distance of a coordinate, and claim the
  /// revealed tiles for the player's civilization.
  public func revealAround(state : WorldTypes.PlayerState, coord : Common.HexCoord, radius : Nat) : () {
    let ownerId = switch (state.game) {
      case (?g) { ?g.civilization.id };
      case null { null };
    };
    state.map := {
      state.map with
      tiles = state.map.tiles.map(
        func(tile) {
          if (hexDistance(tile.coord, coord) <= radius) {
            {
              tile with
              fog = #visible;
              owner = switch (ownerId) { case (?id) { ?id }; case null { tile.owner } };
            };
          } else {
            tile;
          };
        }
      );
    };
  };

  /// Hex distance between two axial coordinates.
  func hexDistance(a : Common.HexCoord, b : Common.HexCoord) : Nat {
    let dq = a.q - b.q;
    let dr = a.r - b.r;
    let ds = (-dq - dr);
    let absQ = if (dq < 0) { -dq } else { dq };
    let absR = if (dr < 0) { -dr } else { dr };
    let absS = if (ds < 0) { -ds } else { ds };
    let max = if (absQ >= absR and absQ >= absS) { absQ } else if (absR >= absS) { absR } else { absS };
    max.toNat();
  };

  // ---------------------------------------------------------------------------
  // Settlements
  // ---------------------------------------------------------------------------

  /// Found a new settlement at a coordinate, claiming the surrounding tiles.
  public func foundSettlement(
    state : WorldTypes.PlayerState,
    name : Text,
    position : Common.HexCoord,
  ) : Common.ActionResult {
    switch (state.game) {
      case null { #err("No game in progress") };
      case (?game) {
        let tile = state.map.tiles.find(func(t) = t.coord == position);
        switch (tile) {
          case null { #err("Position is off the map") };
          case (?t) {
            if (t.terrain == #ocean or t.terrain == #ice) {
              return #err("Cannot settle on this terrain");
            };
            if (state.settlements.any(func(s) = s.position == position)) {
              return #err("A settlement already occupies this tile");
            };
            let id = state.nextSettlementId;
            let settlement : SettlementTypes.Settlement = {
              id;
              name;
              owner = game.civilization.id;
              position;
              population = 1;
              buildings = [];
              workedTiles = [];
              production = emptyPool();
            };
            state.settlements := state.settlements.concat([settlement]);
            state.nextSettlementId := id + 1;
            // Claim the settlement tile and its immediate neighbours.
            revealAround(state, position, 1);
            #ok;
          };
        };
      };
    };
  };

  /// Assign a population unit to work a tile owned by the settlement's civ.
  public func assignPopulation(
    state : WorldTypes.PlayerState,
    settlementId : Common.SettlementId,
    tileId : Common.TileId,
  ) : Common.ActionResult {
    switch (state.settlements.find(func(s) = s.id == settlementId)) {
      case null { #err("Settlement not found") };
      case (?settlement) {
        switch (state.map.tiles.find(func(t) = t.id == tileId)) {
          case null { #err("Tile not found") };
          case (?tile) {
            if (tile.owner != ?settlement.owner) {
              return #err("Tile is not owned by this civilization");
            };
            if (settlement.workedTiles.contains(tileId)) {
              return #err("Tile is already worked");
            };
            if (settlement.workedTiles.size() >= settlement.population) {
              return #err("No free population to assign");
            };
            state.settlements := state.settlements.map(
              func(s) {
                if (s.id == settlementId) {
                  { s with workedTiles = s.workedTiles.concat([tileId]) };
                } else {
                  s;
                };
              }
            );
            #ok;
          };
        };
      };
    };
  };

  /// Construct a building in a settlement, gated on the treasury.
  public func constructBuilding(
    state : WorldTypes.PlayerState,
    settlementId : Common.SettlementId,
    kind : Text,
  ) : Common.ActionResult {
    switch (state.game) {
      case null { #err("No game in progress") };
      case (?game) {
        switch (state.settlements.find(func(s) = s.id == settlementId)) {
          case null { #err("Settlement not found") };
          case (?settlement) {
            let cost = buildingCost(kind);
            if (game.civilization.resources.production < cost) {
              return #err("Not enough production to build");
            };
            let building : SettlementTypes.Building = {
              id = settlement.buildings.size() + 1;
              name = kind;
              kind;
              level = 1;
              productionBonus = buildingBonus(kind);
            };
            let civ = game.civilization;
            let updatedCiv : GameTypes.Civilization = {
              civ with
              resources = { civ.resources with production = civ.resources.production - cost };
            };
            state.game := ?{ game with civilization = updatedCiv; updatedAt = Time.now() };
            state.settlements := state.settlements.map(
              func(s) {
                if (s.id == settlementId) {
                  { s with buildings = s.buildings.concat([building]) };
                } else {
                  s;
                };
              }
            );
            #ok;
          };
        };
      };
    };
  };

  /// Production cost of a building kind.
  func buildingCost(kind : Text) : Nat {
    if (kind == "Granary") { 10 }
    else if (kind == "Workshop") { 15 }
    else if (kind == "Market") { 20 }
    else if (kind == "Library") { 25 }
    else { 10 };
  };

  /// Per-turn production bonus of a building kind.
  func buildingBonus(kind : Text) : Common.ResourcePool {
    if (kind == "Granary") { { food = 2; production = 0; gold = 0; science = 0; culture = 0; influence = 0 } }
    else if (kind == "Workshop") { { food = 0; production = 3; gold = 0; science = 0; culture = 0; influence = 0 } }
    else if (kind == "Market") { { food = 0; production = 0; gold = 3; science = 0; culture = 0; influence = 0 } }
    else if (kind == "Library") { { food = 0; production = 0; gold = 0; science = 3; culture = 0; influence = 0 } }
    else { emptyPool() };
  };

  /// List the caller's settlements.
  public func listSettlements(state : WorldTypes.PlayerState) : [SettlementTypes.Settlement] {
    state.settlements;
  };

  // ---------------------------------------------------------------------------
  // Economy: production, upkeep, treasury and trade
  // ---------------------------------------------------------------------------

  /// Sum per-turn production across all of the player's settlements, including
  /// worked-tile yields and building bonuses.
  public func produce(state : WorldTypes.PlayerState) : Common.ResourcePool {
    var total = emptyPool();
    for (s in state.settlements.values()) {
      total := addPool(total, settlementYield(state, s));
    };
    total;
  };

  /// Compute a single settlement's per-turn yield from its worked tiles and
  /// buildings.
  func settlementYield(state : WorldTypes.PlayerState, s : SettlementTypes.Settlement) : Common.ResourcePool {
    var pool = emptyPool();
    for (tileId in s.workedTiles.values()) {
      switch (state.map.tiles.find(func(t) = t.id == tileId)) {
        case null {};
        case (?tile) { pool := addPool(pool, tileYield(tile)); };
      };
    };
    for (b in s.buildings.values()) {
      pool := addPool(pool, b.productionBonus);
    };
    pool;
  };

  /// Base yield of a tile by terrain, plus any resource node on it.
  func tileYield(tile : MapTypes.Tile) : Common.ResourcePool {
    let base = switch (tile.terrain) {
      case (#grassland) { { food = 3; production = 0; gold = 0; science = 0; culture = 0; influence = 0 } };
      case (#plains) { { food = 2; production = 1; gold = 0; science = 0; culture = 0; influence = 0 } };
      case (#forest) { { food = 1; production = 2; gold = 0; science = 0; culture = 0; influence = 0 } };
      case (#hills) { { food = 0; production = 3; gold = 0; science = 0; culture = 0; influence = 0 } };
      case (#mountains) { { food = 0; production = 2; gold = 1; science = 0; culture = 0; influence = 0 } };
      case (#desert) { { food = 0; production = 0; gold = 2; science = 0; culture = 0; influence = 0 } };
      case (#coast) { { food = 2; production = 0; gold = 1; science = 0; culture = 0; influence = 0 } };
      case (#ocean) { { food = 1; production = 0; gold = 1; science = 0; culture = 0; influence = 0 } };
      case (#tundra) { { food = 1; production = 0; gold = 0; science = 0; culture = 0; influence = 0 } };
      case (#ice) { { food = 0; production = 0; gold = 0; science = 0; culture = 0; influence = 0 } };
      case (#jungle) { { food = 2; production = 1; gold = 0; science = 0; culture = 0; influence = 0 } };
      case (#savanna) { { food = 2; production = 1; gold = 0; science = 0; culture = 0; influence = 0 } };
      case (#wetlands) { { food = 2; production = 0; gold = 1; science = 0; culture = 0; influence = 0 } };
      case (#volcanic) { { food = 0; production = 3; gold = 0; science = 0; culture = 0; influence = 0 } };
      case (#reef) { { food = 2; production = 0; gold = 1; science = 0; culture = 0; influence = 0 } };
      case (#mesa) { { food = 0; production = 2; gold = 1; science = 0; culture = 0; influence = 0 } };
    };
    switch (tile.resource) {
      case null { base };
      case (?node) {
        let bonus = if (node.amount > 0) { 1 } else { 0 };
        { base with production = base.production + bonus };
      };
    };
  };

  /// Per-turn upkeep: each settlement and unit costs gold and food.
  public func upkeepFor(state : WorldTypes.PlayerState) : Common.ResourcePool {
    let settlementCount = state.settlements.size();
    let unitCount = state.units.size();
    {
      food = unitCount;
      production = 0;
      gold = settlementCount + unitCount;
      science = 0;
      culture = 0;
      influence = 0;
    };
  };

  /// Trade resources with one of the player's own settlements or a discovered
  /// rival. Positive `amount` sends resources out; negative receives them.
  public func trade(
    state : WorldTypes.PlayerState,
    partnerId : Common.RivalId,
    resource : Text,
    amount : Nat,
  ) : Common.ActionResult {
    switch (state.game) {
      case null { #err("No game in progress") };
      case (?game) {
        switch (state.rivals.find(func(r) = r.id == partnerId)) {
          case null { #err("Rival not discovered") };
          case (?rival) {
            if (rival.stance == #war) {
              return #err("Cannot trade with a rival at war");
            };
            let civ = game.civilization;
            let res = civ.resources;
            let updated = switch (resource) {
              case "food" {
                if (res.food < amount) { return #err("Not enough food") };
                { res with food = satSub(res.food, amount) };
              };
              case "production" {
                if (res.production < amount) { return #err("Not enough production") };
                { res with production = satSub(res.production, amount) };
              };
              case "gold" {
                if (res.gold < amount) { return #err("Not enough gold") };
                { res with gold = satSub(res.gold, amount) };
              };
              case _ { return #err("Unknown resource") };
            };
            // Trade converts the sent resource into gold at a fixed rate.
            let gained = { updated with gold = updated.gold + amount };
            state.game := ?{
              game with
              civilization = { civ with resources = gained };
              updatedAt = Time.now();
            };
            #ok;
          };
        };
      };
    };
  };

  // ---------------------------------------------------------------------------
  // Turn progression
  // ---------------------------------------------------------------------------

  /// Advance one turn: produce resources from settlements, pay upkeep, gate on
  /// the treasury, advance the world (weather, crises) and return a summary.
  public func endTurn(state : WorldTypes.PlayerState) : GameTypes.TurnSummary {
    switch (state.game) {
      case null {
        { turn = 0; resourcesGained = emptyPool(); events = ["No game in progress"]; stabilityDelta = 0 };
      };
      case (?game) {
        let gained = produce(state);
        let upkeep = upkeepFor(state);
        let net = subtractPool(gained, upkeep);
        let civ = game.civilization;
        let updatedCiv : GameTypes.Civilization = {
          civ with
          resources = addPool(civ.resources, net);
          researchPoints = civ.researchPoints + net.science;
        };
        let nextTurn = game.turn + 1;
        state.game := ?{ game with civilization = updatedCiv; turn = nextTurn; updatedAt = Time.now() };

        // Advance the world: refresh weather and roll a crisis.
        state.weather := weatherFor(state.weather.location);
        let events = advanceWorld(state, nextTurn);

        {
          turn = nextTurn;
          resourcesGained = net;
          events;
          stabilityDelta = 0;
        };
      };
    };
  };

  /// Advance the world one turn: refresh rival strength and roll a crisis.
  func advanceWorld(state : WorldTypes.PlayerState, turn : Nat) : [Text] {
    var events : [Text] = [];
    state.rivals := state.rivals.map(
      func(r) { { r with strength = r.strength + 1 } }
    );
    if (turn % 3 == 0) {
      let crisis = makeCrisis(state.nextCrisisId, state.weather);
      state.nextCrisisId := state.nextCrisisId + 1;
      state.crises := state.crises.concat([crisis]);
      events := events.concat(["Crisis: " # crisis.title]);
    };
    events;
  };

  /// Build a crisis event appropriate to the current weather.
  func makeCrisis(id : Common.CrisisId, weather : WorldTypes.WeatherState) : WorldTypes.CrisisEvent {
    let (kind, title, description) = if (weather.precipitationMm >= 4.0) {
      ("flood", "Flooding", "Heavy rain has flooded farmland and roads.");
    } else if (weather.temperatureC <= 0.0) {
      ("blizzard", "Blizzard", "A severe blizzard has halted production.");
    } else if (weather.temperatureC >= 30.0) {
      ("drought", "Drought", "A drought is withering the harvest.");
    } else {
      ("unrest", "Civil Unrest", "Citizens are protesting the government.");
    };
    {
      id;
      kind;
      title;
      description;
      choices = [
        {
          id = 1;
          name = "Spend gold on relief";
          effect = {
            resourceDelta = { food = 5; production = 0; gold = 0; science = 0; culture = 0; influence = 0 };
            stabilityDelta = 5;
            summary = "Relief restored order.";
          };
        },
        {
          id = 2;
          name = "Ignore it";
          effect = {
            resourceDelta = { food = 0; production = 0; gold = 0; science = 0; culture = 0; influence = 0 };
            stabilityDelta = -10;
            summary = "The people remember being ignored.";
          };
        },
      ];
      resolved = false;
    };
  };

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  /// An all-zero resource pool.
  func emptyPool() : Common.ResourcePool {
    { food = 0; production = 0; gold = 0; science = 0; culture = 0; influence = 0 };
  };

  /// Add two resource pools.
  func addPool(a : Common.ResourcePool, b : Common.ResourcePool) : Common.ResourcePool {
    {
      food = a.food + b.food;
      production = a.production + b.production;
      gold = a.gold + b.gold;
      science = a.science + b.science;
      culture = a.culture + b.culture;
      influence = a.influence + b.influence;
    };
  };

  /// Subtract pool `b` from pool `a`, clamping each field at zero so the
  /// treasury can never go negative.
  func subtractPool(a : Common.ResourcePool, b : Common.ResourcePool) : Common.ResourcePool {
    {
      food = satSub(a.food, b.food);
      production = satSub(a.production, b.production);
      gold = satSub(a.gold, b.gold);
      science = satSub(a.science, b.science);
      culture = satSub(a.culture, b.culture);
      influence = satSub(a.influence, b.influence);
    };
  };

  /// Saturating Nat subtraction.
  func satSub(a : Nat, b : Nat) : Nat {
    if (b >= a) { 0 } else { a - b };
  };
};
