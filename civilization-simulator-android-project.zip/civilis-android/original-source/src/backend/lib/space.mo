import Int "mo:core/Int";
import Common "../types/common";
import SpaceTypes "../types/space";
import WorldTypes "../types/world";

/// Space exploration, colonization and combat domain.
///
/// Stateless module: every function takes the caller's persisted
/// `WorldTypes.PlayerState` and mutates it in place. The whole space layer is
/// gated behind technology: a nation must have researched the "Spaceflight"
/// technology (catalog id 16) and reached the modern or information era before
/// any mission can launch.
module {
  /// The technology that unlocks spaceflight.
  let spaceflightTechId : Common.TechId = 16;

  // ---------------------------------------------------------------------------
  // Gate
  // ---------------------------------------------------------------------------

  /// Whether the player has satisfied the spaceflight gate: the spaceflight
  /// technology is researched and the civilization is in the modern or
  /// information era.
  public func hasSpaceflight(state : WorldTypes.PlayerState) : Bool {
    switch (state.game) {
      case null { false };
      case (?game) {
        let eraOk = switch (game.civilization.era) {
          case (#modern) { true };
          case (#information) { true };
          case _ { false };
        };
        let techOk = state.technologies.any(
          func(t) = t.id == spaceflightTechId and t.unlocked
        );
        eraOk and techOk;
      };
    };
  };

  /// The player's civilization id, or null when no game is in progress.
  func civId(state : WorldTypes.PlayerState) : ?Common.GameId {
    switch (state.game) {
      case (?g) { ?g.civilization.id };
      case null { null };
    };
  };

  /// The player's current era index (0 ancient .. 3 information), used as the
  /// technology level multiplier in battle resolution.
  func techLevel(state : WorldTypes.PlayerState) : Nat {
    switch (state.game) {
      case (?g) {
        switch (g.civilization.era) {
          case (#ancient) { 1 };
          case (#industrial) { 2 };
          case (#modern) { 3 };
          case (#information) { 4 };
        };
      };
      case null { 1 };
    };
  };

  // ---------------------------------------------------------------------------
  // Exploration
  // ---------------------------------------------------------------------------

  /// Launch an exploration mission to a coordinate, discovering the star system
  /// there and revealing it on the space map. Gated behind spaceflight.
  public func launchMission(state : WorldTypes.PlayerState, coord : Common.HexCoord) : Common.ActionResult {
    if (not hasSpaceflight(state)) {
      return #err("Spaceflight technology and the modern era are required");
    };
    if (state.spaceSystems.any(func(s) = s.coord == coord)) {
      return #err("A star system is already charted at this coordinate");
    };
    let id = nextSystemId(state);
    let sys = generateSystem(id, coord);
    state.spaceSystems := state.spaceSystems.concat([sys]);
    #ok;
  };

  /// List every star system the player has charted.
  public func listSystems(state : WorldTypes.PlayerState) : [SpaceTypes.StarSystem] {
    state.spaceSystems;
  };

  // ---------------------------------------------------------------------------
  // Claim and colonize
  // ---------------------------------------------------------------------------

  /// Claim a discovered star system for the player's civilization, spending
  /// gold. Claiming extends territory and grants the system's resource income.
  public func claimSystem(state : WorldTypes.PlayerState, systemId : Nat) : Common.ActionResult {
    if (not hasSpaceflight(state)) {
      return #err("Spaceflight technology and the modern era are required");
    };
    let owner = switch (civId(state)) {
      case (?id) { id };
      case null { return #err("No game in progress") };
    };
    switch (state.spaceSystems.find(func(s) = s.id == systemId)) {
      case null { #err("Star system not found") };
      case (?sys) {
        if (not sys.discovered) {
          return #err("Star system has not been discovered");
        };
        if (sys.claimed) {
          return #err("Star system is already claimed");
        };
        let cost = claimCost();
        switch (state.game) {
          case null { return #err("No game in progress") };
          case (?game) {
            if (game.civilization.resources.gold < cost) {
              return #err("Not enough gold to claim this system");
            };
            let civ = game.civilization;
            state.game := ?{
              game with
              civilization = {
                civ with
                resources = { civ.resources with gold = satSub(civ.resources.gold, cost) };
              };
            };
          };
        };
        state.spaceSystems := state.spaceSystems.map(
          func(s) {
            if (s.id == systemId) {
              { s with claimed = true; owner = ?owner };
            } else {
              s;
            };
          }
        );
        #ok;
      };
    };
  };

  /// Colonize a claimed star system, spending production and gold to establish
  /// a permanent colony that increases the system's resource yield.
  public func colonizeSystem(state : WorldTypes.PlayerState, systemId : Nat) : Common.ActionResult {
    if (not hasSpaceflight(state)) {
      return #err("Spaceflight technology and the modern era are required");
    };
    let owner = switch (civId(state)) {
      case (?id) { id };
      case null { return #err("No game in progress") };
    };
    switch (state.spaceSystems.find(func(s) = s.id == systemId)) {
      case null { #err("Star system not found") };
      case (?sys) {
        if (not sys.claimed or sys.owner != ?owner) {
          return #err("You must claim this system before colonizing it");
        };
        let (prodCost, goldCost) = colonizeCost();
        switch (state.game) {
          case null { return #err("No game in progress") };
          case (?game) {
            let res = game.civilization.resources;
            if (res.production < prodCost or res.gold < goldCost) {
              return #err("Not enough production and gold to colonize");
            };
            let civ = game.civilization;
            state.game := ?{
              game with
              civilization = {
                civ with
                resources = {
                  res with
                  production = satSub(res.production, prodCost);
                  gold = satSub(res.gold, goldCost);
                };
              };
            };
          };
        };
        state.spaceSystems := state.spaceSystems.map(
          func(s) {
            if (s.id == systemId) {
              { s with planets = s.planets + 1; resourceYield = scalePool(s.resourceYield, 2) };
            } else {
              s;
            };
          }
        );
        #ok;
      };
    };
  };

  // ---------------------------------------------------------------------------
  // Fleets
  // ---------------------------------------------------------------------------

  /// Build a fleet of `ships` at a star system the player owns, spending
  /// production and gold. Gated behind spaceflight.
  public func buildFleet(state : WorldTypes.PlayerState, systemId : Nat, ships : Nat) : Common.ActionResult {
    if (not hasSpaceflight(state)) {
      return #err("Spaceflight technology and the modern era are required");
    };
    if (ships == 0) {
      return #err("A fleet needs at least one ship");
    };
    let owner = switch (civId(state)) {
      case (?id) { id };
      case null { return #err("No game in progress") };
    };
    switch (state.spaceSystems.find(func(s) = s.id == systemId)) {
      case null { #err("Star system not found") };
      case (?sys) {
        if (not sys.claimed or sys.owner != ?owner) {
          return #err("You can only build fleets at a system you own");
        };
        let (prodCost, goldCost) = fleetCost(ships);
        switch (state.game) {
          case null { return #err("No game in progress") };
          case (?game) {
            let res = game.civilization.resources;
            if (res.production < prodCost or res.gold < goldCost) {
              return #err("Not enough production and gold to build this fleet");
            };
            let civ = game.civilization;
            state.game := ?{
              game with
              civilization = {
                civ with
                resources = {
                  res with
                  production = satSub(res.production, prodCost);
                  gold = satSub(res.gold, goldCost);
                };
              };
            };
          };
        };
        let id = state.nextFleetId;
        state.nextFleetId := id + 1;
        let fleet : SpaceTypes.Fleet = {
          id;
          owner;
          systemId;
          ships;
          strength = ships * 10 * techLevel(state);
          movement = 1 + (ships / 5);
        };
        state.fleets := state.fleets.concat([fleet]);
        #ok;
      };
    };
  };

  /// Move a fleet to another discovered star system within its movement range.
  public func moveFleet(state : WorldTypes.PlayerState, fleetId : Nat, targetSystemId : Nat) : Common.ActionResult {
    if (not hasSpaceflight(state)) {
      return #err("Spaceflight technology and the modern era are required");
    };
    let owner = switch (civId(state)) {
      case (?id) { id };
      case null { return #err("No game in progress") };
    };
    let fleet = switch (state.fleets.find(func(f) = f.id == fleetId)) {
      case (?f) { f };
      case null { return #err("Fleet not found") };
    };
    if (fleet.owner != owner) {
      return #err("You do not command this fleet");
    };
    let target = switch (state.spaceSystems.find(func(s) = s.id == targetSystemId)) {
      case (?s) { s };
      case null { return #err("Star system not found") };
    };
    if (not target.discovered) {
      return #err("Star system has not been discovered");
    };
    let origin = switch (state.spaceSystems.find(func(s) = s.id == fleet.systemId)) {
      case (?s) { s };
      case null { return #err("Fleet origin system not found") };
    };
    if (hexDistance(origin.coord, target.coord) > fleet.movement) {
      return #err("Target system is out of range");
    };
    state.fleets := state.fleets.map(
      func(f) { if (f.id == fleetId) { { f with systemId = targetSystemId } } else { f } }
    );
    #ok;
  };

  /// List the player's fleets.
  public func listFleets(state : WorldTypes.PlayerState) : [SpaceTypes.Fleet] {
    let owner = switch (civId(state)) {
      case (?id) { id };
      case null { return [] };
    };
    state.fleets.filter(func(f) = f.owner == owner);
  };

  // ---------------------------------------------------------------------------
  // Combat
  // ---------------------------------------------------------------------------

  /// Engage a hostile fleet or a defended star system with one of the player's
  /// fleets. The outcome is resolved from fleet strength, the player's tech
  /// level and fleet composition, and reported as a SpaceBattleResult.
  public func resolveSpaceBattle(
    state : WorldTypes.PlayerState,
    fleetId : Nat,
    targetSystemId : Nat,
  ) : SpaceTypes.SpaceBattleResult {
    if (not hasSpaceflight(state)) {
      return {
        attackerWon = false;
        attackerLosses = 0;
        defenderLosses = 0;
        capturedSystem = null;
        summary = "Spaceflight technology and the modern era are required";
      };
    };
    let owner = switch (civId(state)) {
      case (?id) { id };
      case null {
        return {
          attackerWon = false;
          attackerLosses = 0;
          defenderLosses = 0;
          capturedSystem = null;
          summary = "No game in progress";
        };
      };
    };
    let fleet = switch (state.fleets.find(func(f) = f.id == fleetId)) {
      case (?f) { f };
      case null {
        return {
          attackerWon = false;
          attackerLosses = 0;
          defenderLosses = 0;
          capturedSystem = null;
          summary = "Fleet not found";
        };
      };
    };
    if (fleet.owner != owner) {
      return {
        attackerWon = false;
        attackerLosses = 0;
        defenderLosses = 0;
        capturedSystem = null;
        summary = "You do not command this fleet";
      };
    };
    if (fleet.systemId != targetSystemId) {
      return {
        attackerWon = false;
        attackerLosses = 0;
        defenderLosses = 0;
        capturedSystem = null;
        summary = "Fleet is not at the target system";
      };
    };
    let target = switch (state.spaceSystems.find(func(s) = s.id == targetSystemId)) {
      case (?s) { s };
      case null {
        return {
          attackerWon = false;
          attackerLosses = 0;
          defenderLosses = 0;
          capturedSystem = null;
          summary = "Star system not found";
        };
      };
    };
    // Identify a hostile fleet defending the system, if any.
    let hostile = state.fleets.find(
      func(f) = f.systemId == targetSystemId and f.owner != owner
    );
    let attackerPower = fleet.strength + (fleet.ships * techLevel(state));
    let (defenderPower, defenderName) = switch (hostile) {
      case (?h) { (h.strength + (h.ships * 2), "hostile fleet") };
      case null { (target.defense, "system defenses") };
    };
    let attackerWon = attackerPower >= defenderPower;
    let attackerLosses = if (attackerWon) { defenderPower / 4 } else { fleet.ships };
    let defenderLosses = if (attackerWon) {
      switch (hostile) { case (?h) { h.ships }; case null { target.defense } };
    } else {
      attackerPower / 4;
    };
    // Apply losses to the attacker fleet.
    if (attackerWon) {
      let survivingShips = satSub(fleet.ships, attackerLosses);
      if (survivingShips == 0) {
        state.fleets := state.fleets.filter(func(f) = f.id != fleetId);
      } else {
        state.fleets := state.fleets.map(
          func(f) {
            if (f.id == fleetId) {
              { f with ships = survivingShips; strength = survivingShips * 10 * techLevel(state) };
            } else {
              f;
            };
          }
        );
      };
    } else {
      state.fleets := state.fleets.filter(func(f) = f.id != fleetId);
    };
    // Apply losses to the defender.
    switch (hostile) {
      case (?h) {
        let surviving = satSub(h.ships, defenderLosses);
        if (surviving == 0) {
          state.fleets := state.fleets.filter(func(f) = f.id != h.id);
        } else {
          state.fleets := state.fleets.map(
            func(f) { if (f.id == h.id) { { f with ships = surviving; strength = surviving * 10 } } else { f } }
          );
        };
      };
      case null {};
    };
    // Capture the system when the attacker wins and does not already own it.
    var captured : ?Nat = null;
    if (attackerWon and target.owner != ?owner) {
      captured := ?targetSystemId;
      state.spaceSystems := state.spaceSystems.map(
        func(s) {
          if (s.id == targetSystemId) {
            { s with claimed = true; owner = ?owner; defense = satSub(s.defense, defenderLosses) };
          } else {
            s;
          };
        }
      );
    };
    let summary = if (attackerWon) {
      "Fleet " # fleetId.toText() # " defeated " # defenderName # " at " # target.name
      # (if (captured != null) { " and captured the system" } else { "" });
    } else {
      "Fleet " # fleetId.toText() # " was repelled by " # defenderName # " at " # target.name;
    };
    {
      attackerWon;
      attackerLosses;
      defenderLosses;
      capturedSystem = captured;
      summary;
    };
  };

  // ---------------------------------------------------------------------------
  // Generation and helpers
  // ---------------------------------------------------------------------------

  /// The next free star-system id.
  func nextSystemId(state : WorldTypes.PlayerState) : Nat {
    state.spaceSystems.foldLeft(0, func(acc, s) = if (s.id >= acc) { s.id + 1 } else { acc });
  };

  /// Deterministically generate a star system from its coordinate, so the same
  /// coordinate always yields the same system.
  func generateSystem(id : Nat, coord : Common.HexCoord) : SpaceTypes.StarSystem {
    let qn = absNat(coord.q);
    let rn = absNat(coord.r);
    let planets = ((qn * 3 + rn * 7) % 5) + 1;
    let defense = 5 + ((qn * 2 + rn * 3) % 20);
    {
      id;
      name = "System " # coord.q.toText() # ":" # coord.r.toText();
      coord;
      discovered = true;
      claimed = false;
      owner = null;
      planets;
      resourceYield = {
        food = (qn + rn) % 4;
        production = (qn * 2 + rn) % 5;
        gold = (qn + rn * 3) % 6;
        science = planets;
        culture = 0;
        influence = (qn + rn) % 3;
      };
      defense;
    };
  };

  /// Gold cost to claim a star system.
  func claimCost() : Nat { 20 };

  /// Production and gold cost to colonize a star system.
  func colonizeCost() : (Nat, Nat) { (30, 20) };

  /// Production and gold cost to build a fleet of `ships`.
  func fleetCost(ships : Nat) : (Nat, Nat) { (ships * 15, ships * 5) };

  /// Scale every field of a resource pool by `factor`.
  func scalePool(pool : Common.ResourcePool, factor : Nat) : Common.ResourcePool {
    {
      food = pool.food * factor;
      production = pool.production * factor;
      gold = pool.gold * factor;
      science = pool.science * factor;
      culture = pool.culture * factor;
      influence = pool.influence * factor;
    };
  };

  /// Absolute value of an Int as a Nat.
  func absNat(i : Int) : Nat {
    if (i < 0) { (-i).toNat() } else { i.toNat() };
  };

  /// Saturating Nat subtraction.
  func satSub(a : Nat, b : Nat) : Nat {
    if (b >= a) { 0 } else { a - b };
  };

  /// Hex distance between two axial coordinates.
  func hexDistance(a : Common.HexCoord, b : Common.HexCoord) : Nat {
    let dq = a.q - b.q;
    let dr = a.r - b.r;
    let ds = (-dq - dr);
    let absQ = if (dq < 0) { -dq } else { dq };
    let absR = if (dr < 0) { -dr } else { dr };
    let absS = if (ds < 0) { -ds } else { ds };
    let max = if (absQ >= absR and absQ >= absS) { absQ } else if (absR >= absS) { absR } else { absS };
    max.toNat();
  };
};
