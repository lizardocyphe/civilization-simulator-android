import Principal "mo:core/Principal";
import WorldTypes "../types/world";
import WorldLib "world";

module {
  /// Resolve a caller's player record, creating an empty one on first use.
  public func playerFor(state : WorldTypes.WorldState, caller : Principal) : WorldTypes.PlayerState {
    switch (state.players.get(caller)) {
      case (?p) { p };
      case null {
        let fresh : WorldTypes.PlayerState = {
          var game = null;
          var map = { width = 0; height = 0; tiles = [] };
          var settlements = [];
          var units = [];
          var rivals = [];
          var technologies = [];
          var weather = WorldLib.weatherFor(null);
          var crises = [];
          var nextSettlementId = 1;
          var nextUnitId = 1;
          var nextCrisisId = 1;
          var economy = {
            moneySupply = 0;
            priceLevel = 1.0;
            inflationRate = 0.0;
            taxRate = 0.1;
            interestRate = 0.05;
            spending = 0;
            income = 0;
            upkeep = 0;
            history = [];
          };
          var tradeOffers = [];
          var tradeAgreements = [];
          var tradeHistory = [];
          var clock = {
            tick = 0;
            date = "4000 BCE";
            speed = #paused;
            running = false;
            lastAdvanced = 0;
          };
          var queuedOrders = [];
          var spaceSystems = [];
          var fleets = [];
          var proposals = [];
          var resolutions = [];
          var discussions = [];
          var aiDifficulty = #balanced;
          var aiLog = [];
          var nextTradeId = 1;
          var nextOrderId = 1;
          var nextFleetId = 1;
          var nextProposalId = 1;
        };
        state.players.add(caller, fresh);
        fresh;
      };
    };
  };
};
