import AccessControl "mo:caffeineai-authorization/access-control";
import Map "mo:core/Map";
import Principal "mo:core/Principal";

module {
  // ---------------------------------------------------------------------------
  // Old stable shapes (the NewActor of 00000000_000000.mo, inlined).
  // ---------------------------------------------------------------------------

  type OldTile = {
    id : Nat;
    coord : { q : Int; r : Int };
    terrain : {
      #ocean; #coast; #grassland; #plains; #desert;
      #forest; #hills; #mountains; #tundra; #ice;
    };
    resource : ?{ kind : Text; amount : Nat; renewable : Bool };
    fog : { #unexplored; #explored; #visible };
    owner : ?Nat;
  };

  type OldPlayerState = {
    var game : ?{
      id : Nat;
      civilization : {
        id : Nat;
        name : Text;
        era : { #ancient; #industrial; #modern; #information };
        resources : {
          food : Nat;
          production : Nat;
          gold : Nat;
          science : Nat;
          culture : Nat;
          influence : Nat;
        };
        stability : Nat;
        researchPoints : Nat;
        policies : [{ id : Nat; name : Text; description : Text; effect : Text }];
        isPlayer : Bool;
      };
      turn : Nat;
      createdAt : Int;
      updatedAt : Int;
    };
    var map : {
      width : Nat;
      height : Nat;
      tiles : [OldTile];
    };
    var settlements : [{
      id : Nat;
      name : Text;
      owner : Nat;
      position : { q : Int; r : Int };
      population : Nat;
      buildings : [{
        id : Nat;
        name : Text;
        kind : Text;
        level : Nat;
        productionBonus : {
          food : Nat;
          production : Nat;
          gold : Nat;
          science : Nat;
          culture : Nat;
          influence : Nat;
        };
      }];
      workedTiles : [Nat];
      production : {
        food : Nat;
        production : Nat;
        gold : Nat;
        science : Nat;
        culture : Nat;
        influence : Nat;
      };
    }];
    var units : [{
      id : Nat;
      owner : Nat;
      kind : Text;
      strength : Nat;
      movement : Nat;
      position : { q : Int; r : Int };
    }];
    var rivals : [{
      id : Nat;
      name : Text;
      era : { #ancient; #industrial; #modern; #information };
      stance : { #war; #neutral; #peace; #alliance };
      strength : Nat;
    }];
    var technologies : [{
      id : Nat;
      name : Text;
      era : { #ancient; #industrial; #modern; #information };
      cost : Nat;
      prerequisites : [Nat];
      unlocked : Bool;
    }];
    var weather : {
      location : ?{ latitude : Float; longitude : Float; name : Text };
      condition : Text;
      temperatureC : Float;
      windKph : Float;
      precipitationMm : Float;
      updatedAt : Int;
    };
    var crises : [{
      id : Nat;
      kind : Text;
      title : Text;
      description : Text;
      choices : [{
        id : Nat;
        name : Text;
        effect : {
          resourceDelta : {
            food : Nat;
            production : Nat;
            gold : Nat;
            science : Nat;
            culture : Nat;
            influence : Nat;
          };
          stabilityDelta : Int;
          summary : Text;
        };
      }];
      resolved : Bool;
    }];
    var nextSettlementId : Nat;
    var nextUnitId : Nat;
    var nextCrisisId : Nat;
  };

  type OldWeatherRecord = {
    var location : ?{ latitude : Float; longitude : Float; name : Text };
    var condition : Text;
    var temperatureC : Float;
    var windKph : Float;
    var precipitationMm : Float;
    var updatedAt : Int;
  };

  type OldCrisisRecord = {
    id : Nat;
    kind : Text;
    title : Text;
    description : Text;
    choices : [{
      id : Nat;
      name : Text;
      effect : {
        resourceDelta : {
          food : Nat;
          production : Nat;
          gold : Nat;
          science : Nat;
          culture : Nat;
          influence : Nat;
        };
        stabilityDelta : Int;
        summary : Text;
      };
    }];
    var resolved : Bool;
  };

  type OldWeatherWorldState = {
    var weather : OldWeatherRecord;
    var crises : [OldCrisisRecord];
    var nextCrisisId : Nat;
  };

  type OldWorldState = {
    var players : Map.Map<Principal, OldPlayerState>;
    var weather : Map.Map<Principal, OldWeatherWorldState>;
  };

  public type OldActor = {
    accessControlState : AccessControl.AccessControlState;
    world : OldWorldState;
  };

  // ---------------------------------------------------------------------------
  // New stable shapes (must match the current actor body, inlined).
  // ---------------------------------------------------------------------------

  type ResourcePool = {
    food : Nat;
    production : Nat;
    gold : Nat;
    science : Nat;
    culture : Nat;
    influence : Nat;
  };

  type NewTile = {
    id : Nat;
    coord : { q : Int; r : Int };
    terrain : {
      #ocean; #coast; #grassland; #plains; #desert;
      #forest; #hills; #mountains; #tundra; #ice;
      #jungle; #savanna; #wetlands; #volcanic; #reef; #mesa;
    };
    resource : ?{ kind : Text; amount : Nat; renewable : Bool };
    pocket : ?{
      kind : { #food; #production; #gold; #science; #culture; #influence };
      remaining : Nat;
      initial : Nat;
      renewalRate : Nat;
      renewable : Bool;
    };
    fog : { #unexplored; #explored; #visible };
    owner : ?Nat;
  };

  type NewPlayerState = {
    var game : ?{
      id : Nat;
      civilization : {
        id : Nat;
        name : Text;
        era : { #ancient; #industrial; #modern; #information };
        resources : ResourcePool;
        stability : Nat;
        researchPoints : Nat;
        policies : [{ id : Nat; name : Text; description : Text; effect : Text }];
        isPlayer : Bool;
      };
      turn : Nat;
      createdAt : Int;
      updatedAt : Int;
    };
    var map : {
      width : Nat;
      height : Nat;
      tiles : [NewTile];
    };
    var settlements : [{
      id : Nat;
      name : Text;
      owner : Nat;
      position : { q : Int; r : Int };
      population : Nat;
      buildings : [{
        id : Nat;
        name : Text;
        kind : Text;
        level : Nat;
        productionBonus : ResourcePool;
      }];
      workedTiles : [Nat];
      production : ResourcePool;
    }];
    var units : [{
      id : Nat;
      owner : Nat;
      kind : Text;
      strength : Nat;
      movement : Nat;
      position : { q : Int; r : Int };
    }];
    var rivals : [{
      id : Nat;
      name : Text;
      era : { #ancient; #industrial; #modern; #information };
      stance : { #war; #neutral; #peace; #alliance };
      strength : Nat;
    }];
    var technologies : [{
      id : Nat;
      name : Text;
      era : { #ancient; #industrial; #modern; #information };
      cost : Nat;
      prerequisites : [Nat];
      unlocked : Bool;
    }];
    var weather : {
      location : ?{ latitude : Float; longitude : Float; name : Text };
      condition : Text;
      temperatureC : Float;
      windKph : Float;
      precipitationMm : Float;
      updatedAt : Int;
    };
    var crises : [{
      id : Nat;
      kind : Text;
      title : Text;
      description : Text;
      choices : [{
        id : Nat;
        name : Text;
        effect : {
          resourceDelta : ResourcePool;
          stabilityDelta : Int;
          summary : Text;
        };
      }];
      resolved : Bool;
    }];
    var nextSettlementId : Nat;
    var nextUnitId : Nat;
    var nextCrisisId : Nat;
    var economy : {
      moneySupply : Nat;
      priceLevel : Float;
      inflationRate : Float;
      taxRate : Float;
      interestRate : Float;
      spending : Nat;
      income : Nat;
      upkeep : Nat;
      history : [{
        tick : Nat;
        moneySupply : Nat;
        priceLevel : Float;
        inflationRate : Float;
        income : Nat;
        upkeep : Nat;
      }];
    };
    var tradeOffers : [{
      id : Nat;
      partner : Nat;
      offered : ResourcePool;
      requested : ResourcePool;
      gold : Nat;
      status : { #pending; #accepted; #rejected; #countered; #cancelled };
      createdTick : Nat;
    }];
    var tradeAgreements : [{
      id : Nat;
      partner : Nat;
      perTick : ResourcePool;
      goldPerTick : Nat;
      active : Bool;
      startedTick : Nat;
    }];
    var tradeHistory : [{
      tick : Nat;
      partner : Nat;
      offered : ResourcePool;
      requested : ResourcePool;
      gold : Nat;
      summary : Text;
    }];
    var clock : {
      tick : Nat;
      date : Text;
      speed : { #paused; #x1; #x2; #x4 };
      running : Bool;
      lastAdvanced : Int;
    };
    var queuedOrders : [{
      id : Nat;
      kind : Text;
      payload : Text;
      issuedAt : Int;
    }];
    var spaceSystems : [{
      id : Nat;
      name : Text;
      coord : { q : Int; r : Int };
      discovered : Bool;
      claimed : Bool;
      owner : ?Nat;
      planets : Nat;
      resourceYield : ResourcePool;
      defense : Nat;
    }];
    var fleets : [{
      id : Nat;
      owner : Nat;
      systemId : Nat;
      ships : Nat;
      strength : Nat;
      movement : Nat;
    }];
    var proposals : [{
      id : Nat;
      sponsor : Nat;
      kind : { #tradePact; #peace; #sanctions; #territorialClaim; #jointSpaceProgram };
      description : Text;
      status : { #open; #passed; #failed; #withdrawn };
      votesFor : Nat;
      votesAgainst : Nat;
    }];
    var resolutions : [{
      id : Nat;
      proposalId : Nat;
      kind : { #tradePact; #peace; #sanctions; #territorialClaim; #jointSpaceProgram };
      effect : Text;
      passedTick : Nat;
    }];
    var discussions : [{
      speaker : Text;
      nation : Nat;
      text : Text;
      tick : Nat;
    }];
    var aiDifficulty : { #passive; #balanced; #aggressive };
    var aiLog : [{
      tick : Nat;
      rival : Nat;
      action : {
        #expand; #research; #build; #recruit; #attack;
        #trade; #diplomacy; #space; #idle;
      };
      reasoning : Text;
    }];
    var nextTradeId : Nat;
    var nextOrderId : Nat;
    var nextFleetId : Nat;
    var nextProposalId : Nat;
  };

  type NewWeatherRecord = {
    var location : ?{ latitude : Float; longitude : Float; name : Text };
    var condition : Text;
    var temperatureC : Float;
    var windKph : Float;
    var precipitationMm : Float;
    var updatedAt : Int;
  };

  type NewCrisisRecord = {
    id : Nat;
    kind : Text;
    title : Text;
    description : Text;
    choices : [{
      id : Nat;
      name : Text;
      effect : {
        resourceDelta : ResourcePool;
        stabilityDelta : Int;
        summary : Text;
      };
    }];
    var resolved : Bool;
  };

  type NewWeatherWorldState = {
    var weather : NewWeatherRecord;
    var crises : [NewCrisisRecord];
    var nextCrisisId : Nat;
  };

  type NewWorldState = {
    var players : Map.Map<Principal, NewPlayerState>;
    var weather : Map.Map<Principal, NewWeatherWorldState>;
  };

  public type NewActor = {
    accessControlState : AccessControl.AccessControlState;
    world : NewWorldState;
  };

  // ---------------------------------------------------------------------------
  // Migration
  // ---------------------------------------------------------------------------

  func migrateTile(tile : OldTile) : NewTile {
    {
      id = tile.id;
      coord = tile.coord;
      terrain = tile.terrain;
      resource = tile.resource;
      pocket = null;
      fog = tile.fog;
      owner = tile.owner;
    };
  };

  func migratePlayer(p : OldPlayerState) : NewPlayerState {
    {
      var game = p.game;
      var map = {
        width = p.map.width;
        height = p.map.height;
        tiles = p.map.tiles.map(func(t) = migrateTile(t));
      };
      var settlements = p.settlements;
      var units = p.units;
      var rivals = p.rivals;
      var technologies = p.technologies;
      var weather = p.weather;
      var crises = p.crises;
      var nextSettlementId = p.nextSettlementId;
      var nextUnitId = p.nextUnitId;
      var nextCrisisId = p.nextCrisisId;
      var economy = {
        moneySupply = 0;
        priceLevel = 1.0;
        inflationRate = 0.0;
        taxRate = 0.1;
        interestRate = 0.05;
        spending = 0;
        income = 0;
        upkeep = 0;
        history = [];
      };
      var tradeOffers = [];
      var tradeAgreements = [];
      var tradeHistory = [];
      var clock = {
        tick = 0;
        date = "4000 BCE";
        speed = #paused;
        running = false;
        lastAdvanced = 0;
      };
      var queuedOrders = [];
      var spaceSystems = [];
      var fleets = [];
      var proposals = [];
      var resolutions = [];
      var discussions = [];
      var aiDifficulty = #balanced;
      var aiLog = [];
      var nextTradeId = 1;
      var nextOrderId = 1;
      var nextFleetId = 1;
      var nextProposalId = 1;
    };
  };

  public func migration(old : OldActor) : NewActor {
    {
      accessControlState = old.accessControlState;
      world = {
        var players = old.world.players.map(
          func(_k, p) = migratePlayer(p)
        );
        var weather = old.world.weather;
      };
    };
  };
};
