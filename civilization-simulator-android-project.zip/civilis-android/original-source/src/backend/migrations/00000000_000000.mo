import AccessControl "mo:caffeineai-authorization/access-control";
import Map "mo:core/Map";
import Principal "mo:core/Principal";

module {
  // Inlined stable shapes (migrations may not import project modules).
  type PlayerState = {
    var game : ?{
      id : Nat;
      civilization : {
        id : Nat;
        name : Text;
        era : { #ancient; #industrial; #modern; #information };
        resources : {
          food : Nat;
          production : Nat;
          gold : Nat;
          science : Nat;
          culture : Nat;
          influence : Nat;
        };
        stability : Nat;
        researchPoints : Nat;
        policies : [{ id : Nat; name : Text; description : Text; effect : Text }];
        isPlayer : Bool;
      };
      turn : Nat;
      createdAt : Int;
      updatedAt : Int;
    };
    var map : {
      width : Nat;
      height : Nat;
      tiles : [{
        id : Nat;
        coord : { q : Int; r : Int };
        terrain : {
          #ocean; #coast; #grassland; #plains; #desert;
          #forest; #hills; #mountains; #tundra; #ice;
        };
        resource : ?{ kind : Text; amount : Nat; renewable : Bool };
        fog : { #unexplored; #explored; #visible };
        owner : ?Nat;
      }];
    };
    var settlements : [{
      id : Nat;
      name : Text;
      owner : Nat;
      position : { q : Int; r : Int };
      population : Nat;
      buildings : [{
        id : Nat;
        name : Text;
        kind : Text;
        level : Nat;
        productionBonus : {
          food : Nat;
          production : Nat;
          gold : Nat;
          science : Nat;
          culture : Nat;
          influence : Nat;
        };
      }];
      workedTiles : [Nat];
      production : {
        food : Nat;
        production : Nat;
        gold : Nat;
        science : Nat;
        culture : Nat;
        influence : Nat;
      };
    }];
    var units : [{
      id : Nat;
      owner : Nat;
      kind : Text;
      strength : Nat;
      movement : Nat;
      position : { q : Int; r : Int };
    }];
    var rivals : [{
      id : Nat;
      name : Text;
      era : { #ancient; #industrial; #modern; #information };
      stance : { #war; #neutral; #peace; #alliance };
      strength : Nat;
    }];
    var technologies : [{
      id : Nat;
      name : Text;
      era : { #ancient; #industrial; #modern; #information };
      cost : Nat;
      prerequisites : [Nat];
      unlocked : Bool;
    }];
    var weather : {
      location : ?{ latitude : Float; longitude : Float; name : Text };
      condition : Text;
      temperatureC : Float;
      windKph : Float;
      precipitationMm : Float;
      updatedAt : Int;
    };
    var crises : [{
      id : Nat;
      kind : Text;
      title : Text;
      description : Text;
      choices : [{
        id : Nat;
        name : Text;
        effect : {
          resourceDelta : {
            food : Nat;
            production : Nat;
            gold : Nat;
            science : Nat;
            culture : Nat;
            influence : Nat;
          };
          stabilityDelta : Int;
          summary : Text;
        };
      }];
      resolved : Bool;
    }];
    var nextSettlementId : Nat;
    var nextUnitId : Nat;
    var nextCrisisId : Nat;
  };

  type WeatherRecord = {
    var location : ?{ latitude : Float; longitude : Float; name : Text };
    var condition : Text;
    var temperatureC : Float;
    var windKph : Float;
    var precipitationMm : Float;
    var updatedAt : Int;
  };

  type CrisisRecord = {
    id : Nat;
    kind : Text;
    title : Text;
    description : Text;
    choices : [{
      id : Nat;
      name : Text;
      effect : {
        resourceDelta : {
          food : Nat;
          production : Nat;
          gold : Nat;
          science : Nat;
          culture : Nat;
          influence : Nat;
        };
        stabilityDelta : Int;
        summary : Text;
      };
    }];
    var resolved : Bool;
  };

  type WeatherWorldState = {
    var weather : WeatherRecord;
    var crises : [CrisisRecord];
    var nextCrisisId : Nat;
  };

  type WorldState = {
    var players : Map.Map<Principal, PlayerState>;
    var weather : Map.Map<Principal, WeatherWorldState>;
  };

  public type OldActor = {};

  public type NewActor = {
    accessControlState : AccessControl.AccessControlState;
    world : WorldState;
  };

  public func migration(_ : OldActor) : NewActor {
    {
      accessControlState = AccessControl.initState();
      world = {
        var players = Map.empty();
        var weather = Map.empty();
      };
    };
  };
};
