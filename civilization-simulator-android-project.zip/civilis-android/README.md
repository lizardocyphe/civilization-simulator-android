# Civilization Simulator — Android wrapper

This Android Studio project bundles the supplied frontend's built web assets inside the APK. The UI assets are stored locally, so they do not need to be downloaded at launch and the WebView can open the bundled UI without a connection.

## Build an APK
1. Install Android Studio and its Android SDK (API 35 or newer).
2. Open this folder (`civilis-android`) in Android Studio.
3. Allow Gradle sync to finish.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, typically `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitation: offline gameplay is not yet supported by the supplied source
The supplied ZIP is a Caffeine/Internet Computer application. Its `env.json` contains `backend_host`, `backend_canister_id`, `project_id`, `ii_derivation_origin`, and `storage_gateway_url` all set to `"undefined"`. Game actions and game state use backend query/mutation hooks and Internet Identity. Bundling the frontend makes the UI assets available offline, but it does **not** replace the remote backend or authentication service. Therefore the complete game cannot be honestly described as fully playable offline from this source alone.

To make all gameplay work offline, the app needs a local game engine/data store (for example, a Kotlin/JavaScript simulation layer persisted in local storage/SQLite) and changes to the frontend hooks to use it instead of canister calls. Alternatively, configure and deploy the existing Internet Computer backend for online play. No APK binary is included because this build environment has no Android SDK/Gradle installation; this is the complete Android Studio project scaffold with the supplied frontend assets bundled.
